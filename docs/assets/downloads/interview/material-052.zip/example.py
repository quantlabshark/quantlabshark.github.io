# -*- coding: utf-8 -*-

# 示例 1
from itertools import product
from fractions import Fraction
from collections import Counter
ways = {n:Counter(map(sum,product(range(1,7),repeat=n))) for n in range(4)}
count = 0
for dice in product(range(1,7),repeat=3):
    options = []
    for mask in range(8):
        n = mask.bit_count()
        kept = sum(dice[i] for i in range(3) if not (mask>>i)&1)
        options.append((Fraction(ways[n][7-kept],6**n),n))
    best = max(p for p,n in options)
    optimal_n = {n for p,n in options if p==best}
    if 2 in optimal_n:
        assert optimal_n=={2}
        count += 1
assert Fraction(count,216)==Fraction(7,36)


# 示例 2
from itertools import permutations
from math import hypot,sqrt
xy=[(0,0),(1,0),(2,0),(0,1),(1,1),(2,1),(0,2),(2,2)]
def length(p):
    return sum(hypot(xy[a][0]-xy[b][0],xy[a][1]-xy[b][1]) for a,b in zip(p,p[1:]))
best=max(length(p) for p in permutations(range(8)))
assert abs(best-(3*sqrt(5)+2*sqrt(8)+sqrt(2)+2))<1e-12

