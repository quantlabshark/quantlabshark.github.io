# -*- coding: utf-8 -*-

# 示例 1
import numpy as np
rng = np.random.default_rng(17)
T,N,K = 300,2001,40
F = rng.normal(size=(T,K))
B = np.zeros((N,K))
sectors = []
for i in range(N):
    pair = [2*(i%20),2*(i%20)+1]
    w = rng.uniform(.1,.9)
    B[i,pair] = [w,1-w]
    sectors.append(pair)
Y = F@B.T+rng.normal(scale=.01,size=(T,N))
Bhat = np.zeros_like(B)
for i,idx in enumerate(sectors):
    reference = F[:,idx[-1]]
    design = F[:,idx[:-1]]-reference[:,None]
    beta = np.linalg.lstsq(design,Y[:,i]-reference,rcond=None)[0]
    Bhat[i,idx[:-1]] = beta
    Bhat[i,idx[-1]] = 1-beta.sum()
assert np.max(np.abs(Bhat.sum(axis=1)-1))<1e-12
assert np.mean(np.abs(Bhat-B))<.002
# 行业1与2互换：归属集合、暴露和以及观测拟合不变。
perm = np.arange(K)
perm[0],perm[1] = 1,0
F2,B2 = F[:,perm],B[:,perm]
assert np.allclose(F@B.T,F2@B2.T)
assert not np.allclose(B,B2)

