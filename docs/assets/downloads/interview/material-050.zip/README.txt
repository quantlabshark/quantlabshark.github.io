行业暴露估计与潜变量识别

环境：Python 3.10 或更新版本。
先安装依赖：python -m pip install -r requirements.txt
运行：python example.py

脚本按文章顺序包含 1 段示例，后面的示例可能使用前面的定义。
断言检查失败会报错；没有打印内容的示例以正常退出表示断言通过。
