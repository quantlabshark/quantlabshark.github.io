# -*- coding: utf-8 -*-

# 示例 1
from math import isfinite

def max_profit_with_fee(prices, fee):
    if not isfinite(fee) or fee < 0:
        raise ValueError("fee must be finite and nonnegative")
    cash, hold = 0.0, float("-inf")
    for p in prices:
        if not isfinite(p) or p <= 0:
            raise ValueError("prices must be finite and positive")
        old_cash, old_hold = cash, hold
        cash = max(old_cash, old_hold + p - fee)
        hold = max(old_hold, old_cash - p)
    return cash

assert max_profit_with_fee([1, 3, 2, 8, 4, 9], 2) == 8
assert max_profit_with_fee([9, 7, 4], 1) == 0
assert max_profit_with_fee([], 1) == 0
assert max_profit_with_fee([4], 0) == 0


# 示例 2
from collections import Counter
from math import gcd, isqrt

def recover(values):
    n = isqrt(len(values))
    if n*n != len(values):
        raise ValueError('条目数必须为平方数')
    counts = Counter(values)
    answer = []
    for x in sorted(values, reverse=True):
        if counts[x] <= 0:
            continue
        counts[x] -= 1
        for y in answer:
            counts[gcd(x, y)] -= 2
        answer.append(x)
        if len(answer) == n:
            break
    if len(answer) != n or any(v != 0 for v in counts.values()):
        raise ValueError('输入不是有效的完整 GCD 矩阵')
    return sorted(answer)

assert recover([1,4,2,6,3,3,9,2,1]) == [4,6,9]
assert recover([2,2,2,2]) == [2,2]


# 示例 3
import numpy as np

def fish_value(n=80):
    x = (np.arange(n) + 0.5) / n
    i, j, k = np.ogrid[:n, :n, :n]
    hi = np.maximum(np.maximum(i, j), k)
    lo = np.minimum(np.minimum(i, j), k)
    mid = i + j + k - hi - lo
    total = x[i] + x[j] + x[k]
    value = total.copy()
    for _ in range(7):
        continuation = value.mean(axis=2)
        value = np.maximum(total, continuation[mid, hi])
    return float(value.mean())

assert 2.3587 < fish_value(80) < 2.3589

