# -*- coding: utf-8 -*-

# 示例 1
def getMissingLetters(sentence):
    seen = {c.lower() for c in sentence
            if "a" <= c <= "z" or "A" <= c <= "Z"}
    return "".join(c for c in "abcdefghijklmnopqrstuvwxyz" if c not in seen)
assert getMissingLetters("A quick brown fox jumps over the lazy dog") == ""
assert getMissingLetters("A slow yellow fox crawls under the proactive dog") == "bjkmqz"
assert getMissingLetters("") == "abcdefghijklmnopqrstuvwxyz"


# 示例 2
def bestTrader(price):
    low, best = float("inf"), 0
    for p in price:
        best = max(best, p-low)
        low = min(low, p)
    return best
assert bestTrader([7,1,5,3,6,4]) == 5
assert bestTrader([7,6,4,3,1]) == 0
assert bestTrader([]) == 0

