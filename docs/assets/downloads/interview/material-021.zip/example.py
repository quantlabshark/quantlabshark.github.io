# -*- coding: utf-8 -*-

# 示例 1
from functools import lru_cache

def largest_join(values, k):
    @lru_cache(None)
    def solve(state, budget):
        best = ''.join(map(str, state))  # 允许少于 k 次
        if budget == 0:
            return best
        for i in range(len(state)):
            for j in range(i+1, len(state)):
                nxt = list(state)
                nxt[i], nxt[j] = nxt[j], nxt[i]
                best = max(best, solve(tuple(nxt), budget-1))
        return best
    return solve(tuple(values), k)

assert largest_join([1, 3, 2, 4], 1) == '4321'
assert largest_join([10, 9], 1) == '910'
assert largest_join([1, 2, 3], 0) == '123'


# 示例 2
def lcs_length(a, b):
    if len(a) < len(b):
        a, b = b, a
    previous = [0] * (len(b)+1)
    for ca in a:
        current = [0]
        for j, cb in enumerate(b, 1):
            current.append(previous[j-1]+1 if ca == cb
                           else max(previous[j], current[j-1]))
        previous = current
    return previous[-1]

assert lcs_length('ABCDE', 'FBDAN') == 2
assert lcs_length('', 'ABC') == 0
assert lcs_length('AAAA', 'AA') == 2

