# -*- coding: utf-8 -*-

# 示例 1
def finish_time(p, d):
    if len(p) != len(d):
        raise ValueError('长度不一致')
    jobs = sorted(zip(d, p), reverse=True)
    total = 0
    best = jobs[0][0] if jobs else 0
    for i, (_, pickup) in enumerate(jobs):
        total += pickup
        remaining = jobs[i+1][0] if i+1 < len(jobs) else 0
        best = min(best, max(total, remaining))
    return best

assert finish_time([1,2,3,2,1],[4,8,5,6,3]) == 5
assert finish_time([],[]) == 0

