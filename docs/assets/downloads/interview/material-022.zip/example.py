# -*- coding: utf-8 -*-

# 示例 1
class Node:
    def __init__(self, value, nxt=None):
        self.value, self.next = value, nxt

def reverse_list(head):
    previous, current = None, head
    while current is not None:
        following = current.next
        current.next = previous
        previous, current = current, following
    return previous

head = Node(1, Node(2, Node(3)))
head = reverse_list(head)
values = []
while head is not None:
    values.append(head.value)
    head = head.next
assert values == [3, 2, 1]
assert reverse_list(None) is None

