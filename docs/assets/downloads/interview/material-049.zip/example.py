# -*- coding: utf-8 -*-

# 示例 1
import math

class MovingAverage:
    def __init__(self, num_bin: int, window: float):
        if num_bin < 1 or not math.isfinite(window) or window <= 0:
            raise ValueError('桶数与窗口必须为正')
        self.B, self.W = int(num_bin), float(window)
        self.h = self.W/self.B
        self.bins = {}
        self.first = self.t = self.value = None
    def Update(self, timestamp: float, value: float):
        t, value = float(timestamp), float(value)
        if not math.isfinite(t) or not math.isfinite(value):
            raise ValueError('输入必须有限')
        if self.t is None:
            self.first = self.t = t
            self.value = value
            return
        if t < self.t:
            raise ValueError('时间必须非递减')
        left = t-self.W
        self.bins = {k:v for k,v in self.bins.items() if v[1] > left}
        a = max(self.t,left)
        while a < t:
            k = math.floor(a/self.h)
            edge = (k+1)*self.h
            if edge <= a:
                k += 1
                edge = (k+1)*self.h
            b = min(t,edge)
            if b <= a:
                raise ValueError('时间精度不足以划分该窗口')
            area = (b-a)*self.value
            if k in self.bins:
                rec = self.bins[k]
                self.bins[k] = (rec[0],b,rec[2]+area)
            else:
                self.bins[k] = (a,b,area)
            a = b
        self.t, self.value = t,value
    def Get(self) -> float:
        if self.t is None or self.t-self.first < self.W:
            return float('nan')
        left = self.t-self.W
        area = 0.0
        for a,b,s in self.bins.values():
            overlap = max(0.0,min(b,self.t)-max(a,left))
            if b > a:
                area += s*overlap/(b-a)
        return area/self.W

ma = MovingAverage(2,4)
ma.Update(0,10); ma.Update(2,20); ma.Update(4,30)
assert abs(ma.Get()-15)<1e-12
ma.Update(5,40)
assert abs(ma.Get()-20)<1e-12
ma.Update(1000,8)
assert abs(ma.Get()-40)<1e-12
assert len(ma.bins)<=4

