# -*- coding: utf-8 -*-

# 示例 1
def best_same_ends(a):
    prefix = 0
    min_before = {}
    best = None
    for x in a:
        after = prefix+x
        if x in min_before:
            value = after-min_before[x]
            best = value if best is None else max(best,value)
        min_before[x] = min(min_before.get(x,prefix),prefix)
        prefix = after
    return best

assert best_same_ends([1,2,3,1,3,2,1]) == 13
assert best_same_ends([-2,-5,-2]) == -9
assert best_same_ends([1,2,3]) is None

