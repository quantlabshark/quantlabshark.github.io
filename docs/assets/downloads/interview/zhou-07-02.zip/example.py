# -*- coding: utf-8 -*-

# 示例 1
def is_power_of_two(x):
    return x > 0 and (x & (x - 1)) == 0


# 示例 2
def multiply_by_seven(x):
    return (x << 3) - x


# 示例 3
from fractions import Fraction
import random

def bernoulli_from_fair_coin(p, rng=None):
    p = Fraction(p)
    if not 0 <= p <= 1:
        raise ValueError('p must lie in [0, 1]')
    if p == 0 or p == 1:
        return p == 1
    rng = random if rng is None else rng
    while True:
        p *= 2
        target_bit = int(p)
        p -= target_bit
        coin_bit = rng.randrange(2)
        if coin_bit < target_bit:
            return True
        if coin_bit > target_bit or p == 0:
            return False

