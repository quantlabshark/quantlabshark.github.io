# -*- coding: utf-8 -*-

# 示例 1
import heapq

def shortest(n, roads):
    graph = [[] for _ in range(n + 1)]
    for a, b, c in roads:
        graph[a].append((b, c))
        graph[b].append((a, c))
    dist = [float('inf')] * (n + 1)
    dist[1] = 0
    heap = [(0, 1)]
    while heap:
        d, u = heapq.heappop(heap)
        if d != dist[u]:
            continue
        if u == n:
            return d
        for v, cost in graph[u]:
            nd = d + cost
            if nd < dist[v]:
                dist[v] = nd
                heapq.heappush(heap, (nd, v))
    return dist[n]

assert shortest(3, [(1, 2, 4), (2, 3, 2), (1, 3, 9)]) == 6


# 示例 2
def solve(text):
    tokens = iter(map(int, text.split()))
    output = []
    while True:
        n = next(tokens, None)
        if n is None:
            break
        m = next(tokens)
        if n == 0 and m == 0:
            break
        roads = [(next(tokens), next(tokens), next(tokens)) for _ in range(m)]
        distance = shortest(n, roads)
        output.append('-1' if distance == float('inf') else str(distance))
    return '\n'.join(output)

assert solve('3 3 1 2 4 2 3 2 1 3 9 2 0 0 0') == '6\n-1'

if __name__ == '__main__':
    import sys
    print(solve(sys.stdin.buffer.read()))

