# -*- coding: utf-8 -*-

# 示例 1
def trace(n):
    if n == 0:
        print("base")
        return 1
    print("enter", n)
    left = trace(n - 1)
    print("leave", n, left)
    return left + n

result = trace(3)
print("result", result)

