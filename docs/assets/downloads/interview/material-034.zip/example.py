# -*- coding: utf-8 -*-

# 示例 1
from fractions import Fraction

value = {(0, 0): Fraction(0)}
forced = {}
for total in range(1, 101):
    for red in range(total + 1):
        white = total - red
        play = Fraction(0)
        if red:
            play += Fraction(red, total) * (1 + value[red-1, white])
        if white:
            play += Fraction(white, total) * (-1 + value[red, white-1])
        forced[red, white] = play
        value[red, white] = max(Fraction(0), play)

assert forced[3, 4] == Fraction(12, 35)
assert min(r for r in range(101) if forced[r, 100-r] > 0) == 47

