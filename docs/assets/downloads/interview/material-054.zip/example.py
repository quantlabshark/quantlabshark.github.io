# -*- coding: utf-8 -*-

# 示例 1
from collections import defaultdict

def auction_price(orders):
    buy,sell = defaultdict(int),defaultdict(int)
    for price,volume,side in orders:
        if price <= 0 or price%100 or volume <= 0 or side not in (-1,1):
            raise ValueError('委托格式不合法')
        (buy if side==1 else sell)[price] += volume
    demand,supply = sum(buy.values()),0
    best,low,high = 0,None,None
    for p in sorted(set(buy)|set(sell)):
        supply += sell[p]
        volume = min(demand,supply)
        if volume>best:
            best,low,high = volume,p,p
        elif volume==best and volume>0:
            high = p
        demand -= buy[p]
    return -1 if best==0 else (low+high)/2

assert auction_price([(300,10,1),(100,10,-1)])==200
assert auction_price([(100,1,1),(200,1,-1)])==-1


# 示例 2
from math import isqrt
from functools import lru_cache

@lru_cache(None)
def is_prime(x):
    if x<2:return False
    if x%2==0:return x==2
    return all(x%d for d in range(3,isqrt(x)+1,2))

def prime_substrings(n):
    if not 0<=n<10**10:
        raise ValueError('要求零至一百亿之间整数')
    s=str(n); answer=0
    for i,ch in enumerate(s):
        if ch=='0':continue
        value=0
        for j in range(i,len(s)):
            value=10*value+int(s[j])
            answer += is_prime(value)
    return answer

assert prime_substrings(1303)==4
assert prime_substrings(22)==2
assert prime_substrings(0)==0


# 示例 3
from dataclasses import dataclass

@dataclass
class Rect:
    x:float; y:float; w:float; h:float
    @property
    def right(self):return self.x+self.w
    @property
    def bottom(self):return self.y+self.h

@dataclass
class Tank:
    box:Rect
    speed:float=10
    skin:str='blue'
    health:int=100
    hidden:bool=False

class World:
    def __init__(self,stones=(),grass=()):
        self.width=self.height=2000
        self.stones=list(stones);self.grass=list(grass)
    def move(self,tank,direction,seconds):
        if direction not in ('L','R','U','D') or seconds<0 or tank.speed<0:
            raise ValueError('运动参数不合法')
        r=tank.box
        if r.w<=0 or r.h<=0 or not (0<=r.x<=self.width-r.w and 0<=r.y<=self.height-r.h):
            raise ValueError('坦克初始范围不合法')
        if any(r.x<s.right and s.x<r.right and r.y<s.bottom and s.y<r.bottom for s in self.stones):
            raise ValueError('坦克初始位置与石块重叠')
        distance=tank.speed*seconds
        if direction=='R':
            distance=min(distance,self.width-r.right)
            for s in self.stones:
                if r.y<s.bottom and s.y<r.bottom and s.x>=r.right:
                    distance=min(distance,s.x-r.right)
            r.x+=distance
        elif direction=='L':
            distance=min(distance,r.x)
            for s in self.stones:
                if r.y<s.bottom and s.y<r.bottom and s.right<=r.x:
                    distance=min(distance,r.x-s.right)
            r.x-=distance
        elif direction=='D':
            distance=min(distance,self.height-r.bottom)
            for s in self.stones:
                if r.x<s.right and s.x<r.right and s.y>=r.bottom:
                    distance=min(distance,s.y-r.bottom)
            r.y+=distance
        else:
            distance=min(distance,r.y)
            for s in self.stones:
                if r.x<s.right and s.x<r.right and s.bottom<=r.y:
                    distance=min(distance,r.y-s.bottom)
            r.y-=distance
        tank.hidden=any(g.x<=r.x and r.right<=g.right and g.y<=r.y and r.bottom<=g.bottom for g in self.grass)
        return distance

world=World([Rect(40,0,10,30)],[Rect(10,40,30,30)])
tank=Tank(Rect(10,10,10,10),speed=10,skin='shark',health=100)
assert world.move(tank,'R',10)==20 and tank.box.x==30
assert world.move(tank,'R',1)==0
world.move(tank,'D',4)
assert tank.hidden and tank.box.y==50
world.move(tank,'L',100)
assert tank.box.x==0 and not tank.hidden
world.move(tank,'U',100)
assert tank.box.y==0
print(tank.box.x, tank.box.y, tank.hidden)

