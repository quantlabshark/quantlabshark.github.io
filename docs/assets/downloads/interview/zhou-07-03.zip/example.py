# -*- coding: utf-8 -*-

# 示例 1
import math
import random
from statistics import mean, stdev

def european_call_mc(s, k, r, sigma, tau, paths=100000, seed=2026):
    if s <= 0 or k < 0 or sigma < 0 or tau < 0:
        raise ValueError('invalid pricing inputs')
    if paths < 2:
        raise ValueError('at least two paths are required')
    rng = random.Random(seed)
    discount = math.exp(-r * tau)
    drift = (r - sigma * sigma / 2) * tau
    scale = sigma * math.sqrt(tau)
    payoffs = [discount * max(s * math.exp(drift + scale * rng.gauss(0, 1)) - k, 0)
               for _ in range(paths)]
    return mean(payoffs), stdev(payoffs) / math.sqrt(paths)


# 示例 2
import math
import random

def normal_from_uniform(mu=0.0, sigma=1.0, rng=None):
    if sigma < 0:
        raise ValueError('sigma must be nonnegative')
    if sigma == 0:
        return mu
    rng = random if rng is None else rng
    while True:
        y = -math.log1p(-rng.random())
        if rng.random() <= math.exp(-0.5 * (y - 1) ** 2):
            z = y if rng.random() < 0.5 else -y
            return mu + sigma * z


# 示例 3
import random

def estimate_pi(points=1000000, seed=2026):
    if points <= 0:
        raise ValueError('points must be positive')
    rng = random.Random(seed)
    inside = 0
    for _ in range(points):
        x, y = rng.random(), rng.random()
        inside += x * x + y * y <= 1.0
    return 4 * inside / points


# 示例 4
import math

def explicit_heat(intervals=50, steps=500, horizon=0.1):
    if intervals < 2 or steps < 1 or horizon < 0:
        raise ValueError('invalid grid')
    dx, dt = 1 / intervals, horizon / steps
    alpha = dt / (dx * dx)
    if alpha > 0.5:
        raise ValueError('explicit scheme is unstable for this grid')
    u = [math.sin(math.pi * j * dx) for j in range(intervals + 1)]
    u[0] = u[-1] = 0.0
    for _ in range(steps):
        v = [0.0] * (intervals + 1)
        for j in range(1, intervals):
            v[j] = alpha * u[j - 1] + (1 - 2 * alpha) * u[j] + alpha * u[j + 1]
        u = v
    exact = [math.exp(-math.pi ** 2 * horizon) * math.sin(math.pi * j * dx)
             for j in range(intervals + 1)]
    return max(abs(a - b) for a, b in zip(u, exact))

