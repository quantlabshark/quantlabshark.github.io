# -*- coding: utf-8 -*-

# 示例 1
def lottery(n):
    # 以0.5元为单位，避免浮点比较
    cost=[0]*(n+1); choice=[0]*(n+1)
    for size in range(1,n+1):
        options=[]
        for m in range(1,size+1):
            branches=[4]
            if m>1: branches.append(2+cost[m-1])
            if m<size: branches.append(3+cost[size-m])
            options.append((max(branches),m))
        cost[size],choice[size]=min(options)
    return cost[n]/2,choice[n]
assert lottery(100)==(9.5,52)


# 示例 2
def palindrome(x):
    if x<0 or (x%10==0 and x!=0): return False
    reverse=0
    while x>reverse:
        reverse=reverse*10+x%10
        x//=10
    return x==reverse or x==reverse//10
assert palindrome(121) and palindrome(0)
assert not palindrome(-121) and not palindrome(10)


# 示例 3
def max_profit(prices):
    low=float('inf'); best=0
    for p in prices:
        best=max(best,p-low)
        low=min(low,p)
    return best
assert max_profit([7,1,5,3,6,4])==5
assert max_profit([7,6,4,3,1])==0


# 示例 4
def max_profit_trade(prices):
    if len(prices) < 2:
        return 0, None
    low, buy = prices[0], 0
    best, dates = 0, None
    for sell in range(1, len(prices)):
        profit = prices[sell] - low
        if profit > best:
            best, dates = profit, (buy, sell)
        if prices[sell] < low:
            low, buy = prices[sell], sell
    return best, dates

assert max_profit_trade([7, 1, 5, 3, 6, 4]) == (5, (1, 4))
assert max_profit_trade([7, 6, 4]) == (0, None)


# 示例 5
def knight_probability(n,k,r,c):
    moves=[(1,2),(1,-2),(-1,2),(-1,-2),(2,1),(2,-1),(-2,1),(-2,-1)]
    p=[[0.0]*n for _ in range(n)];p[r][c]=1.0
    for _ in range(k):
        q=[[0.0]*n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for di,dj in moves:
                    a,b=i+di,j+dj
                    if 0<=a<n and 0<=b<n:q[a][b]+=p[i][j]/8
        p=q
    return sum(map(sum,p))
assert knight_probability(3,2,0,0)==0.0625
assert knight_probability(1,0,0,0)==1

