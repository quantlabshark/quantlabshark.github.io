# -*- coding: utf-8 -*-

# 示例 1
def increasing_subsequences(values, limit, threshold):
    answer = []
    def visit(start, path, total):
        if path and total < threshold:
            answer.append(tuple(path))
        if len(path) == limit:
            return
        used = set()
        for i in range(start, len(values)):
            x = values[i]
            if x in used or (path and x <= path[-1]):
                continue
            used.add(x)
            path.append(x)
            visit(i+1, path, total+x)
            path.pop()
    if limit < 0:
        raise ValueError('长度上限非负')
    visit(0, [], 0)
    return answer

assert set(increasing_subsequences([1,2,2,3],2,5)) == {(1,),(2,),(3,),(1,2),(1,3)}
assert increasing_subsequences([-5, -4], 2, -6) == [(-5, -4)]


# 示例 2
from collections.abc import MutableMapping, Mapping

class SlashDict(MutableMapping):
    def __init__(self, data=None):
        self._data = {}
        for k, v in (data or {}).items():
            self[k] = v
    @staticmethod
    def _parts(key):
        if not isinstance(key, str) or any(not p for p in key.split('/')):
            raise KeyError(key)
        return key.split('/')
    def _parent(self, key, create=False):
        parts = self._parts(key)
        node = self
        for p in parts[:-1]:
            if p not in node._data:
                if not create:
                    raise KeyError(key)
                node._data[p] = SlashDict()
            node = node._data[p]
            if not isinstance(node, SlashDict):
                raise TypeError('路径中间节点不是字典')
        return node, parts[-1]
    def __getitem__(self, key):
        node, leaf = self._parent(key)
        return node._data[leaf]
    def __setitem__(self, key, value):
        node, leaf = self._parent(key, True)
        node._data[leaf] = SlashDict(value) if isinstance(value, Mapping) and not isinstance(value, SlashDict) else value
    def __delitem__(self, key):
        node, leaf = self._parent(key)
        del node._data[leaf]
    def __iter__(self):
        return iter(self._data)
    def __len__(self):
        return len(self._data)
    def deep_keys(self):
        for k, v in self._data.items():
            if isinstance(v, SlashDict):
                for child in v.deep_keys():
                    yield k+'/'+child
            else:
                yield k

sd = SlashDict({'a': {'b': {'x': 1, 'y': 2}}})
assert sd.pop('a/b/y') == 2
sd['e/f/g'] = 5
assert sd.get('missing', 9) == 9
assert list(sd.deep_keys()) == ['a/b/x', 'e/f/g']

