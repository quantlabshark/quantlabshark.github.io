# -*- coding: utf-8 -*-

# 示例 1
import numpy as np
import pandas as pd
def order_features(frame):
    x=frame.copy().sort_values(['stock_id','time_id','seconds_in_bucket'])
    keys=['stock_id','time_id']
    if x.duplicated(keys+['seconds_in_bucket']).any():
        raise ValueError('同股票同时间段存在重复时点，需要先核查')
    values=x[['bid1','ask1','bsize1','asize1','seconds_in_bucket']].to_numpy(dtype=float)
    if not np.isfinite(values).all() or not x.seconds_in_bucket.between(0,600,inclusive='left').all():
        raise ValueError('报价须有限，段内秒数须在[0,600)')
    valid=(x.bid1>0)&(x.ask1>=x.bid1)&(x.bsize1>=0)&(x.asize1>=0)
    if not valid.all(): raise ValueError('发现无效报价或数量')
    den=x.asize1+x.bsize1
    x['spread']=x.ask1/x.bid1-1
    x['imbalance']=(x.asize1-x.bsize1)/(0.5*den.replace(0,np.nan))
    x['wap']=(x.bid1*x.asize1+x.ask1*x.bsize1)/den.replace(0,np.nan)
    x['log_wap']=np.log(x.wap)
    x['log_return']=x.groupby(keys).log_wap.diff()
    x['spread_change']=x.groupby(keys).spread.diff()
    x['imbalance_change']=x.groupby(keys).imbalance.diff()
    x['half']=np.where(x.seconds_in_bucket<300,'first','last')
    def rv(v):
        z=v.dropna().to_numpy()
        return np.sqrt(z@z) if len(z) else np.nan
    features=x.groupby(keys).agg(
        rv=('log_return',rv), spread_mean=('spread','mean'),
        spread_std=('spread','std'), imbalance_mean=('imbalance','mean'),
        imbalance_std=('imbalance','std'), observations=('wap','count'))
    halves=x.groupby(keys+['half']).log_return.agg(rv).unstack('half').add_prefix('rv_')
    features=features.join(halves)
    return x,features.reset_index()

toy=pd.DataFrame({'stock_id':[0,0,0,0], 'time_id':[1,1,2,2],
    'seconds_in_bucket':[0,3,0,3], 'bid1':[99,100,109,110],
    'ask1':[101,102,111,112], 'asize1':[1,1,1,1], 'bsize1':[1,1,1,1]})
ticks,features=order_features(toy)
assert np.isclose(features.loc[0,'rv'],np.log(101/100))
assert np.isclose(features.loc[1,'rv'],np.log(111/110))


# 示例 2
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_squared_error,mean_absolute_error

def evaluate_features(features,labels):
    keys=['stock_id','time_id']
    d=features.merge(labels[keys+['target']],on=keys,validate='one_to_one')
    d=d[d.target.notna() & (d.target>=0)].reset_index(drop=True)
    cols=[c for c in features if c not in keys]
    splitter=GroupShuffleSplit(n_splits=1,test_size=.2,random_state=17)
    train,test=next(splitter.split(d,groups=d.time_id))
    X,y=d[cols],d.target
    models={
        'ridge':make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=1)),
        'tree':make_pipeline(SimpleImputer(strategy='median'),HistGradientBoostingRegressor(
            max_iter=100,max_leaf_nodes=7,l2_regularization=1,random_state=17,early_stopping=False))}
    predictions={'persistence':d.rv.to_numpy()}
    for name,model in models.items():
        model.fit(X.iloc[train],y.iloc[train])
        predictions[name]=np.maximum(model.predict(X),0)
    common=np.logical_and.reduce([np.isfinite(v) for v in predictions.values()])
    rows=[]
    for name,pred in predictions.items():
        for split,ix in [('train',train),('test',test)]:
            ok=common[ix]; a=y.iloc[ix].to_numpy()[ok];b=pred[ix][ok]
            if not len(a):
                raise ValueError('该分组没有所有模型共同可评价的样本')
            positive=a>0
            rows.append({'model':name,'split':split,'count':len(a),'split_count':len(ix),'positive_count':int(positive.sum()),
                'rmse':np.sqrt(mean_squared_error(a,b)), 'mae':mean_absolute_error(a,b),
                'rmspe_positive':np.sqrt(np.mean(((a[positive]-b[positive])/a[positive])**2))
                    if positive.any() else np.nan})
    return pd.DataFrame(rows)

