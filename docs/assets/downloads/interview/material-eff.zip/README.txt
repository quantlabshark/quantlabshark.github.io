订单簿特征与波动率预测

环境：Python 3.10 或更新版本。
先安装依赖：python -m pip install -r requirements.txt
运行：python example.py

脚本按文章顺序包含 2 段示例，后面的示例可能使用前面的定义。
断言检查失败会报错；没有打印内容的示例以正常退出表示断言通过。
order_features 处理逐笔表；evaluate_features 需要包含 target 的标签表。脚本内的小表用于检查分组边界，真实预测结果需另传入对应数据。
