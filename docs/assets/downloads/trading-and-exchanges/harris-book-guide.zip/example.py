# -*- coding: utf-8 -*-
# 报价、订单簿与交易成本基础
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟静态订单簿：立即买入 600 股，手续费 12 元。
from math import isclose

asks = [(100.10, 400), (100.12, 600), (100.15, 900)]
quantity, remaining, notional = 600, 600, 0.0
for price, available in asks:
    filled = min(remaining, available)
    notional += filled * price
    remaining -= filled
    if remaining == 0:
        break
assert remaining == 0
midpoint, fees = 100.0, 12.0
average = notional / quantity
cost = notional - quantity * midpoint + fees
cost_bps = cost / (quantity * midpoint) * 10000
assert isclose(cost, 76.0, abs_tol=1e-8)
print(f"平均成交价：{average:.6f}")
print(f"总成本：{cost:.2f} 元，{cost_bps:.4f} bp")
