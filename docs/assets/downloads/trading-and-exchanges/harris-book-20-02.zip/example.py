# -*- coding: utf-8 -*-
# 20.2 用 Roll 模型理解价差与波动测量
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import random
from statistics import mean, pvariance
from math import sqrt
rng = random.Random(20)
spread, value = 0.20, 100.0
prices = []
for _ in range(50000):
    value += rng.gauss(0, 0.03)
    direction = rng.choice((-1, 1))
    prices.append(value + spread * direction / 2)
changes = [b-a for a, b in zip(prices, prices[1:])]
x, y = changes[1:], changes[:-1]
mx, my = mean(x), mean(y)
covariance = mean((a-mx)*(b-my) for a, b in zip(x, y))
if covariance >= 0:
    raise ValueError('样本协方差非负，不能套用实数 Roll 估计')
estimated_spread = 2 * sqrt(-covariance)
fundamental_variance = pvariance(changes) + 2 * covariance
print('价差:', round(estimated_spread, 5))
print('价值创新方差:', round(fundamental_variance, 6))
assert abs(estimated_spread - spread) < 0.01
