# -*- coding: utf-8 -*-
# 26.2 分散市场怎样形成共同价格
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟静态卖盘。费用为每股费用，数量均可即时取得。
venues = [('A', 20.00, 0.02, 100), ('B', 20.01, 0.005, 200)]
target = 250
remaining, total = target, 0.0
for name, price, fee, available in sorted(venues, key=lambda x: x[1] + x[2]):
    qty = min(remaining, available)
    total += qty * (price + fee)
    remaining -= qty
    print(name, qty, '股，含费单价', price + fee)
    if remaining == 0:
        break
assert remaining == 0
print('平均成本:', round(total / target, 6))
assert abs(total / target - 20.016) < 1e-9
