# -*- coding: utf-8 -*-
# 16.2 估值误差与赢家诅咒
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import random
from statistics import mean
rng = random.Random(16)
true_value, trials = 100.0, 10000
for bidders in (2, 5, 20):
    errors, winner_errors = [], []
    for _ in range(trials):
        estimates = [true_value + rng.gauss(0, 5)
                     for _ in range(bidders)]
        errors.extend(x - true_value for x in estimates)
        winner_errors.append(max(estimates) - true_value)
    print(bidders, round(mean(errors), 3),
          round(mean(winner_errors), 3))
