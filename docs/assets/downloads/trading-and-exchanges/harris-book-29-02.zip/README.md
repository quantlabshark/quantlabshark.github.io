# 29.2 内幕交易、逆向选择与公司治理

解压后，在此文件夹打开终端，运行：

```text
python -m pip install -r requirements.txt
python example.py
```

`example.py` 按正文顺序包含本节的 1 段 Python 示例。代码中的价格、收益和参数均为课内教学数据，无需行情账号。

`expected-output.txt` 保存实际运行得到的终端输出，可逐项与运行结果比较。涉及随机模拟的例子在代码中固定种子；浮点数末位可能随计算环境略有差异。

验证环境：Python 3.14.6。第三方依赖版本见 `requirements.txt`；仅使用标准库的课程可以直接运行第二条命令。

课程地址：https://quantlabshark.github.io/read/?slug=harris-book-29-02
