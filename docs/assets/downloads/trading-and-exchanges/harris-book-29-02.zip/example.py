# -*- coding: utf-8 -*-
# 29.2 内幕交易、逆向选择与公司治理
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟二点价值、知情者与随机客户的教学模型
high, low = 101.0, 99.0
for informed_share in [0.0, 0.1, 0.3, 0.5]:
    prob_high_given_buy = (1 + informed_share) / 2
    ask = prob_high_given_buy * high + (1 - prob_high_given_buy) * low
    bid = (1 - prob_high_given_buy) * high + prob_high_given_buy * low
    print(informed_share, '买价', round(bid, 3), '卖价', round(ask, 3), '价差', round(ask-bid, 3))
    assert abs((ask - bid) - 2 * informed_share) < 1e-10
