# -*- coding: utf-8 -*-
# 7.1 经纪服务与交易信用
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
n, b = 10_000, 20
direct = n * (n - 1)
intermediated = 2 * n + b * (b - 1)
print("逐一核验的关系数：", direct)
print("经纪结构下的关系数：", intermediated)
print(f"前者约为后者的 {direct / intermediated:.1f} 倍")
assert intermediated == 20_380
