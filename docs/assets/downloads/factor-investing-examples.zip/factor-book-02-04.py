# 2.4 异象检验与稳健标准误
# https://quantlabshark.github.io/read/?slug=factor-book-02-04

import numpy as np
rng = np.random.default_rng(18)
T = 600
f = rng.normal(0, .04, T)
e = np.zeros(T)
shock = rng.normal(0, .02, T)
for t in range(1, T):
    e[t] = .65*e[t-1] + shock[t]
y = .003 + .7*f + e
X = np.column_stack([np.ones(T), f])
b = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y-X@b
inverse = np.linalg.inv(X.T@X)
ordinary = inverse*(resid@resid)/(T-X.shape[1])
v = X*resid[:,None]
M = v.T@v
J = int(4*(T/100)**(2/9))
for j in range(1,J+1):
    cross = v[j:].T@v[:-j]
    M += (1-j/(J+1))*(cross+cross.T)
hac = inverse@M@inverse
assert np.allclose(hac,hac.T)
assert np.linalg.eigvalsh(hac).min() > 0
print('alpha:', round(b[0],6))
print('standard errors:', np.sqrt([ordinary[0,0],hac[0,0]]))
