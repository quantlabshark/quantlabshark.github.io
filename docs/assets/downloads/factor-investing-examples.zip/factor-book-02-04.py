# -*- coding: utf-8 -*-
# 怎样检验模型解释不了的收益
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(2026)
T, L = 240, 4
u = np.zeros(T)
for t in range(1, T):
    u[t] = 0.6 * u[t-1] + rng.normal(0, 0.02)
returns = 0.004 + u
residual = returns - returns.mean()
long_run_variance = np.dot(residual, residual) / T
for lag in range(1, L + 1):
    covariance = np.dot(residual[lag:], residual[:-lag]) / T
    long_run_variance += 2 * (1 - lag / (L + 1)) * covariance
se_hac = np.sqrt(long_run_variance / T)
se_iid = returns.std(ddof=1) / np.sqrt(T)
print(f"均值 {returns.mean():.4%}，独立样本标准误 {se_iid:.4%}")
print(f"NW 标准误 {se_hac:.4%}，t 值 {returns.mean()/se_hac:.3f}")
assert se_hac > 0 and se_iid > 0
