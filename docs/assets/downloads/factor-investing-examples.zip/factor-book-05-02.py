# 5.2 基本面锚定反转的构造与检验
# https://quantlabshark.github.io/read/?slug=factor-book-05-02

import numpy as np
far = 0.03 - (-0.01)
fur = 0.01 - 0.02
assert np.isclose(far, 0.04)
assert np.isclose(fur, -0.01)
print(far, fur)
