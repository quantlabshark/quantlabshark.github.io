# 6.3 行为金融学与因子收益
# https://quantlabshark.github.io/read/?slug=factor-book-06-03

def value(x):
    return x ** 0.5 if x >= 0 else -2 * (-x) ** 0.5
assert value(100) == 10
assert value(-100) == -20
assert 0.5 * value(100) + 0.5 * value(-100) == -5
