# -*- coding: utf-8 -*-
# 动量比较的是哪些过去收益
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from math import prod
monthly_returns = [0.01] * 11 + [0.30]
momentum = prod(1+r for r in monthly_returns[:-1]) - 1
including_latest = prod(1+r for r in monthly_returns) - 1
print(f"跳过最近月：{momentum:.4%}")
print(f"若错误加入最近月：{including_latest:.4%}")
assert abs(momentum - (1.01**11 - 1)) < 1e-12
assert including_latest > momentum
