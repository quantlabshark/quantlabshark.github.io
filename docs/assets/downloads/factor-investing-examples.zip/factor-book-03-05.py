# 3.5 动量因子
# https://quantlabshark.github.io/read/?slug=factor-book-03-05

import pandas as pd
dates = pd.date_range('2018-01-31',periods=13,freq='ME')
price = pd.Series([100,102,103,104,103,105,107,106,108,110,112,120,90],index=dates)
momentum = price.shift(1)/price.shift(12)-1
assert abs(momentum.iloc[-1]-.2) < 1e-12
print(momentum.iloc[-1])
