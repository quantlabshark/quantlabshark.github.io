# -*- coding: utf-8 -*-
# 5.3 特质性波动率与低波动异象
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(17)
f = rng.normal(0, 0.01, (21, 3))
X = np.column_stack([np.ones(21), f])
y = 0.0002 + f @ np.array([1.1, 0.3, -0.2]) + rng.normal(0, 0.004, 21)
b = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ b
ivol = np.sqrt(resid @ resid / (len(y) - X.shape[1]))
assert np.allclose(X.T @ resid, 0, atol=1e-10)
assert ivol > 0
print(f'日特质性波动率：{ivol:.4%}')
