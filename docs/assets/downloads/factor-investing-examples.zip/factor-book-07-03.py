# 7.3 组合优化：目标函数、模型一致性与交易约束
# https://quantlabshark.github.io/read/?slug=factor-book-07-03

# 模拟：年收益、年协方差，允许两资产自由配置。
import numpy as np
S = np.array([[.04,.01],[.01,.09]])
mu = np.array([.08,.12])
one = np.ones(2)
a = np.linalg.solve(S, one)
w_min = a / a.sum()
zeta = 3.
b = np.linalg.solve(S, mu)
eta = (b.sum() - zeta) / a.sum()
w_mvo = (b - eta*a) / zeta
assert np.isclose(w_min.sum(),1)
assert np.isclose(w_mvo.sum(),1)
assert np.allclose(mu-zeta*S@w_mvo, eta*one)
print(w_min, np.sqrt(w_min@S@w_min), w_mvo)
