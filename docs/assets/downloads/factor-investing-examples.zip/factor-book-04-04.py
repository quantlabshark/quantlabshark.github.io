# -*- coding: utf-8 -*-
# 4.4 因子模型的复杂度与样本外表现
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
factors = [set(), {'A', 'B', 'C'}, {'B', 'D'}]
p1 = -sum(len(items) for items in factors)
unique = set().union(*factors)
p2 = -(len(factors) + len(unique))
assert (p1, p2) == (-5, -7)
print('简约指数I：', p1, '简约指数II：', p2)
