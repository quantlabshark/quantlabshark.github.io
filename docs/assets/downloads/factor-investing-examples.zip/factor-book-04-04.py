# 4.4 模型简约性与复杂度控制
# https://quantlabshark.github.io/read/?slug=factor-book-04-04

factors = [set(), {"A", "B", "C"}, {"B", "D"}]
p1 = -sum(len(x) for x in factors)
p2 = -(len(factors) + len(set().union(*factors)))
assert (p1, p2) == (-5, -7)
print(p1, p2)
