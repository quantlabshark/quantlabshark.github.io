因子投资：方法与实践 — QuantLab 配套示例

各文件对应网站同名阅读单元。安装 numpy pandas scipy scikit-learn 后运行相应 .py 文件。
示例使用文中给定数值或模拟样本；原书实证的样本、变量和结论见各节来源说明。
所有收益率在代码中使用小数表示，例如 1% 写作 0.01。
课程目录：https://quantlabshark.github.io/theory/factor-investing/
