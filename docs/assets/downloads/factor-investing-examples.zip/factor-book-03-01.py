# 3.1 数据和流程
# https://quantlabshark.github.io/read/?slug=factor-book-03-01

import pandas as pd
versions = pd.DataFrame({'ann_date': pd.to_datetime([
    '2020-04-01','2020-05-10','2021-04-01']), 'profit':[10.,8.,9.]})
def known_value(day):
    available = versions[versions.ann_date <= pd.Timestamp(day)]
    return available.sort_values('ann_date').iloc[-1].profit
assert known_value('2020-04-30') == 10
assert known_value('2020-05-31') == 8
assert 90+100-60 == 130
print('April:',known_value('2020-04-30'),'May:',known_value('2020-05-31'))
