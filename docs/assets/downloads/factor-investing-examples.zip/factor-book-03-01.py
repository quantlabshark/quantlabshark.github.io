# -*- coding: utf-8 -*-
# 财务数据怎样按真实时间进入因子计算
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from datetime import date
events = [
    (date(2019, 3, 20), 100),
    (date(2019, 8, 10), 90),
    (date(2020, 3, 25), 95),
]
def value_known_on(day):
    available = [event for event in events if event[0] <= day]
    return max(available, key=lambda event: event[0])[1] if available else None
assert value_known_on(date(2019, 1, 31)) is None
assert value_known_on(date(2019, 6, 30)) == 100
assert value_known_on(date(2019, 12, 31)) == 90
print([value_known_on(date(y, m, d)) for y, m, d in
       [(2019, 1, 31), (2019, 6, 30), (2019, 12, 31), (2020, 4, 30)]])
