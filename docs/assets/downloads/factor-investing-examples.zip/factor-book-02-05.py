# -*- coding: utf-8 -*-
# 新增因子是否改善了定价与组合机会
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
T, N, K = 120, 2, 1
old_sharpe, expanded_sharpe = 0.20, 0.30
grs = (T-N-K)/N * ((1+expanded_sharpe**2)/(1+old_sharpe**2)-1)
print(f"GRS 统计量：{grs:.4f}；F 分布自由度：({N}, {T-N-K})")
assert abs(grs - 2.8125) < 1e-12
