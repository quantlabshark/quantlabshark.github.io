# 5.1 估值、基本面与预期差
# https://quantlabshark.github.io/read/?slug=factor-book-05-01

signals = [True, True, True, False, True, True, False, True, False]
score = sum(signals)
assert score == 6
print(score)
