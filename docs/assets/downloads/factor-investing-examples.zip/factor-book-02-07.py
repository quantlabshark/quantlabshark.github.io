# -*- coding: utf-8 -*-
# 用平均关系估计价格模型：广义矩估计
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
means = [0.006, 0.010]
standard_errors = [0.002, 0.006]
precision = [1 / se**2 for se in standard_errors]
weights = [p / sum(precision) for p in precision]
estimate = sum(w * mean for w, mean in zip(weights, means))
combined_se = (1 / sum(precision)) ** 0.5
print("权重：", weights)
print(f"共同均值估计：{estimate:.3%}；标准误：{combined_se:.3%}")
assert abs(estimate - 0.0064) < 1e-12
assert abs(weights[0] - 0.9) < 1e-12
