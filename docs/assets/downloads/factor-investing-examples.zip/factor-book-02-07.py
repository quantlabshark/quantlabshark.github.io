# 2.7 广义矩估计
# https://quantlabshark.github.io/read/?slug=factor-book-02-07

import numpy as np
rng = np.random.default_rng(19)
T = 20000
x = np.column_stack([rng.normal(2,1,T),rng.normal(2,3,T)])
means = x.mean(axis=0)
b_first = means.mean()
moments = x-b_first
S = np.cov(moments,rowvar=False,bias=True)
W = np.linalg.inv(S)
one = np.ones(2)
b_second = (one@W@means)/(one@W@one)
g = means-b_second
J = T*(g@W@g)
assert abs(b_second-2) < .04 and J >= 0
print(round(b_first,5),round(b_second,5),round(J,5))
