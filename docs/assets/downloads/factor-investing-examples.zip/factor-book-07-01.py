# 7.1 收益率模型：从选股指标到收益预测
# https://quantlabshark.github.io/read/?slug=factor-book-07-01

# 模拟：检查标准化得分和预测单位。
import numpy as np
z = np.array([-1., 0., 1.])
z = (z - z.mean()) / z.std(ddof=0)
forecast = 0.05 * 0.04 * z
assert np.isclose(z.std(), 1)
assert np.isclose(forecast.mean(), 0)
print(np.round(forecast * 100, 4))  # 百分数
