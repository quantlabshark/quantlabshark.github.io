# -*- coding: utf-8 -*-
# 相关指标怎样分离出各自的增量信息
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
x1 = np.array([-1., 0., 1., 2.])
x2 = np.array([0., 2., 1., 4.])
y = 0.5 + 2 * x1 + 3 * x2
controls = np.column_stack([np.ones(4), x1])
z2 = x2 - controls @ np.linalg.lstsq(controls, x2, rcond=None)[0]
b2 = np.dot(z2, y) / np.dot(z2, z2)
X = np.column_stack([controls, x2])
full = np.linalg.lstsq(X, y, rcond=None)[0]
print("完整回归 [截距, x1, x2]：", full)
print("残差化得到的 x2 系数：", b2)
assert np.allclose(full, [0.5, 2, 3])
assert np.isclose(b2, full[-1])
assert np.allclose(controls.T @ z2, 0)
