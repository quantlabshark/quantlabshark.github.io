# 2.6 因子正交化
# https://quantlabshark.github.io/read/?slug=factor-book-02-06

import numpy as np
x1 = np.array([1.,2,3,4,5,6])
x2 = np.array([2.,5,5,9,9,13])
y = np.array([.02,.04,.035,.08,.07,.12])
C = np.column_stack([np.ones(len(x1)),x1])
z = x2-C@np.linalg.lstsq(C,x2,rcond=None)[0]
y_resid = y-C@np.linalg.lstsq(C,y,rcond=None)[0]
partial = (z@y_resid)/(z@z)
full = np.linalg.lstsq(np.column_stack([C,x2]),y,rcond=None)[0][-1]
assert np.allclose(C.T@z,0,atol=1e-12)
assert np.isclose(partial,full)
print(round(partial,8))
