# -*- coding: utf-8 -*-
# 6.7 财务比率背后的经营与会计含义
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
roa_a = 0.10 * 0.5
roa_b = 0.025 * 2.0
assert abs(roa_a - roa_b) < 1e-12
profit = 10
print(f'两家公司ROA均为{roa_a:.1%}')
print(f'调整前ROE：{profit/50:.0%}；调整后：{profit/100:.0%}')
