# 6.7 基本面分析与量化指标的结合
# https://quantlabshark.github.io/read/?slug=factor-book-06-07

import numpy as np
roa_a = 0.10 * 0.5
roa_b = 0.025 * 2.0
assert np.isclose(roa_a, roa_b)
profit = 10.0
reported_equity, adjusted_equity = 50.0, 100.0
print(profit / reported_equity, profit / adjusted_equity)
