# -*- coding: utf-8 -*-
# 一个收益规律如何成为研究证据
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
tests, false_positive_rate = 100, 0.05
probability = 1 - (1 - false_positive_rate) ** tests
print(f"至少一次误报的概率：{probability:.2%}")
assert 0.994 < probability < 0.995
