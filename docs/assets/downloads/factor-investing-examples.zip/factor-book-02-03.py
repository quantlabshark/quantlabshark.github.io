# 2.3 因子暴露和因子收益率
# https://quantlabshark.github.io/read/?slug=factor-book-02-03

import numpy as np
rng = np.random.default_rng(17)
n = 100000
x = rng.normal(size=n)
x_observed = x + rng.normal(size=n)
z = x + rng.normal(size=n)
y = 2*x + rng.normal(size=n)
X = np.column_stack([np.ones(n), x_observed])
Z = np.column_stack([np.ones(n), z])
ols = np.linalg.lstsq(X, y, rcond=None)[0][1]
iv = np.linalg.solve(Z.T @ X, Z.T @ y)[1]
assert .95 < ols < 1.05 and 1.95 < iv < 2.05
print(round(ols,4), round(iv,4))
