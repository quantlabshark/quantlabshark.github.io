# 6.6 因子样本外失效与交易成本
# https://quantlabshark.github.io/read/?slug=factor-book-06-06

import numpy as np
observed, group_mean = 0.01, 0.002
se, tau = 0.008, 0.004
weight = tau**2 / (tau**2 + se**2)
estimate = weight * observed + (1 - weight) * group_mean
assert np.isclose(weight, 0.2)
assert np.isclose(estimate, 0.0036)
print(estimate)
