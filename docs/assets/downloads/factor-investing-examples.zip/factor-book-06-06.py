# -*- coding: utf-8 -*-
# 6.6 因子衰减、拥挤与成本后的收益
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
observed, group_mean = 0.01, 0.002
se, tau = 0.008, 0.004
weight = tau**2 / (tau**2 + se**2)
estimate = weight * observed + (1-weight) * group_mean
assert abs(weight - 0.2) < 1e-12
assert abs(estimate - 0.0036) < 1e-12
print(f'保留样本估计的权重：{weight:.0%}，收缩后均值：{estimate:.2%}')
