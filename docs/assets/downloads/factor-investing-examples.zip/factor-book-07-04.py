# 7.4 Smart Beta：因子指数的设计与评价
# https://quantlabshark.github.io/read/?slug=factor-book-07-04

# 模拟：两只股票均已通过筛选，未加入权重上限。
import numpy as np
size = np.array([100.,200.])
z = np.array([1.,-.5])
quality = np.where(z>=0, 1+z, 1/(1-z))
w = size*quality
w = w/w.sum()
assert np.allclose(w, [.6,.4])
print(w)
