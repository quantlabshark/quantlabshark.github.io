# -*- coding: utf-8 -*-
# 7.4 因子指数的构建与评价
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟两股票质量指数：假定两只股票均已入选。
size = [100.0, 200.0]
z = [1.0, -0.5]
quality = [1+x if x >= 0 else 1/(1-x) for x in z]
raw = [s*q for s,q in zip(size,quality)]
weight = [x/sum(raw) for x in raw]
print(quality, weight)
assert all(abs(a-b)<1e-12 for a,b in zip(weight,[.6,.4]))
