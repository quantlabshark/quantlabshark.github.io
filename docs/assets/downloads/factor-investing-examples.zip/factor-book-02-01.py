# 2.1 投资组合排序法
# https://quantlabshark.github.io/read/?slug=factor-book-02-01

import pandas as pd
d = pd.DataFrame({
    'size': [1,2,3,4,5,6,7,8],
    'bm': [1,4,2,3,1,4,2,3],
    'next_return': [.01,.03,.02,.02,0,.02,.01,.01]})
d['size_group'] = pd.qcut(d['size'], 2, labels=False)
d['value_group'] = d.groupby('size_group')['bm'].transform(
    lambda x: pd.qcut(x, 2, labels=False))
cells = d.groupby(['size_group','value_group'])['next_return'].mean().unstack()
spread = (cells[1]-cells[0]).mean()
assert abs(spread-.01) < 1e-12
print(spread)
