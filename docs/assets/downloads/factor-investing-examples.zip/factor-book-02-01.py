# -*- coding: utf-8 -*-
# 怎样用股票分组计算因子收益
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
stocks = [
    ("A", 0.2, -0.01), ("B", 0.3, 0.01),
    ("C", 0.5, 0.02), ("D", 0.7, 0.00),
    ("E", 0.9, 0.03), ("F", 1.1, 0.05),
]
ordered = sorted(stocks, key=lambda x: x[1])
low, high = ordered[:2], ordered[-2:]
low_return = sum(x[2] for x in low) / len(low)
high_return = sum(x[2] for x in high) / len(high)
spread = high_return - low_return
print(f"低组 {low_return:.2%}，高组 {high_return:.2%}，价差 {spread:.2%}")
assert abs(spread - 0.04) < 1e-12
