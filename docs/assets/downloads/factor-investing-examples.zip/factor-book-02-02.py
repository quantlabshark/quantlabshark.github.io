# -*- coding: utf-8 -*-
# 回归怎样区分因子暴露与风险溢价
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
factor = np.array([-0.02, 0.00, 0.02, -0.01, 0.01, 0.03])
noise = np.array([0.001, -0.002, 0.001, -0.001, 0.002, -0.001])
asset = 0.003 + 1.2 * factor + noise
X = np.column_stack([np.ones(len(factor)), factor])
alpha, beta = np.linalg.lstsq(X, asset, rcond=None)[0]
residual = asset - X @ np.array([alpha, beta])
print(f"月截距 {alpha:.4%}，市场暴露 {beta:.4f}")
assert abs(residual.mean()) < 1e-12
assert abs(np.dot(factor, residual)) < 1e-12
