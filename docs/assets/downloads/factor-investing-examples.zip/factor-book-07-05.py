# -*- coding: utf-8 -*-
# 7.5 因子择时的信号与验证
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟：波动预测在上月末产生，用于下一月配置。
vol = [.10,.20]
raw = [1/x for x in vol]
w = [x/sum(raw) for x in raw]
next_return = [.02,-.01]
result = sum(a*b for a,b in zip(w,next_return))
print(w, 'next month return:', result)
assert abs(result-.01)<1e-12
