# 7.5 因子择时：预测条件收益与控制交易误差
# https://quantlabshark.github.io/read/?slug=factor-book-07-05

# 模拟：使用上月末已经估计的波动率，确定下一月权重。
import numpy as np
past_vol = np.array([.10,.20])
weight = 1/past_vol
weight = weight/weight.sum()
next_return = np.array([.02,-.01])
portfolio_return = weight@next_return
assert np.allclose(weight,[2/3,1/3])
assert np.isclose(portfolio_return,.01)
print(weight, portfolio_return)
