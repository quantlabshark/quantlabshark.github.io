# 7.8 因子投资的发展：另类数据与跨资产配置
# https://quantlabshark.github.io/read/?slug=factor-book-07-08

# 模拟：固定测试月份，比较同一目标的预测均方误差。
import numpy as np
y = np.array([.02,.04,.01,.03])
base = np.array([.01,.03,.02,.02])
new = np.array([.02,.03,.01,.03])
mse_base = np.mean((y-base)**2)
mse_new = np.mean((y-new)**2)
assert np.isclose(mse_new/mse_base,.25)
print(mse_base,mse_new)
