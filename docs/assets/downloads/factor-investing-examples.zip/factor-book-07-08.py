# -*- coding: utf-8 -*-
# 7.8 另类数据与跨资产风险配置
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟测试集；所有预测均假定在对应月份之前产生。
y = [.02,.04,.01,.03]
base = [.01,.03,.02,.02]
extra = [.02,.03,.01,.03]
def mse(prediction):
    return sum((a-b)**2 for a,b in zip(y,prediction))/len(y)
print(mse(base), mse(extra), mse(extra)/mse(base))
assert abs(mse(extra)/mse(base)-.25)<1e-12
