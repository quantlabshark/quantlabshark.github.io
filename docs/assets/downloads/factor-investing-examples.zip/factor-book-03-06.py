# -*- coding: utf-8 -*-
# 盈利能力怎样转化为可比较的选股指标
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
current_ytd, previous_annual, previous_ytd = 90, 120, 80
equity = [900, 1000, 1100, 1200]
profit_ttm = current_ytd + previous_annual - previous_ytd
average_equity = sum(equity) / len(equity)
roe = profit_ttm / average_equity
print(f"TTM 营业利润 {profit_ttm} 百万元，平均权益 {average_equity} 百万元")
print(f"营业利润口径 ROE：{roe:.4%}")
assert abs(roe - 13/105) < 1e-12
