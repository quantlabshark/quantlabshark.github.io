# -*- coding: utf-8 -*-
# 7.2 风险模型与纯因子组合
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟四股票截面，依次为国家、行业A、行业B、风格列。
import numpy as np
B = np.array([[1,1,0,-1], [1,1,0,1],
              [1,0,1,-1], [1,0,1,1]], dtype=float)
C = np.array([[1,0,0], [0,1,0], [0,-1,0], [0,0,1]], dtype=float)
Omega = C @ np.linalg.inv(C.T@B.T@B@C) @ C.T@B.T
r = np.array([.01,.03,-.01,.01])
f = Omega@r
print('factor returns:', f)
print('portfolio weights:\n', Omega)
assert np.allclose(f, [.01,.01,-.01,.01])
assert np.allclose(B@f, r)
