# 7.2 Barra 风险模型：共同风险、约束回归与协方差
# https://quantlabshark.github.io/read/?slug=factor-book-07-02

# 模拟：列顺序为国家、行业甲、行业乙、风格。
import numpy as np
B = np.array([[1,1,0,-1],[1,1,0,1],
              [1,0,1,-1],[1,0,1,1]], dtype=float)
C = np.array([[1,0,0],[0,1,0],[0,-1,0],[0,0,1]], dtype=float)
r = np.array([.01,.03,-.01,.01])
g = np.linalg.lstsq(B @ C, r, rcond=None)[0]
f = C @ g
assert np.allclose(f, [.01,.01,-.01,.01])
assert np.allclose(B @ f, r)
print(f)
