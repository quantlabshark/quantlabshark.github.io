# 阅读导引与基础知识
# https://quantlabshark.github.io/read/?slug=factor-book-guide

import numpy as np

r = np.array([0.01, -0.01, 0.03])
print("平均收益、样本标准差:", r.mean(), r.std(ddof=1))
print("先涨10%再跌10%:", np.prod(1 + np.array([0.1, -0.1])) - 1)

factor = np.array([-0.02, -0.01, 0.0, 0.01, 0.02])
asset = 0.002 + 1.2 * factor
design = np.column_stack([np.ones(factor.size), factor])
alpha, beta = np.linalg.lstsq(design, asset, rcond=None)[0]
print("截距、斜率:", alpha, beta)
assert np.allclose([alpha, beta], [0.002, 1.2])
