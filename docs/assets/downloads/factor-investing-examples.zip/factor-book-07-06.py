# 7.6 风格分析：从基金收益识别因子暴露
# https://quantlabshark.github.io/read/?slug=factor-book-07-06

# 模拟：构造基金月收益，检查回归能否恢复已知参数。
import numpy as np
rng = np.random.default_rng(17)
market = rng.normal(0,.04,60)
value = rng.normal(0,.03,60)
X = np.column_stack([np.ones(60),market,value])
fund_excess = .002 + .8*market + .3*value
coef = np.linalg.lstsq(X,fund_excess,rcond=None)[0]
assert np.allclose(coef,[.002,.8,.3])
print(coef)
