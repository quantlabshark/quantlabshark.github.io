# 3.8 换手率因子
# https://quantlabshark.github.io/read/?slug=factor-book-03-08

import numpy as np
turn = np.r_[np.full(231,.01),np.full(21,.02)]
ato = turn[-21:].mean()/turn[-252:].mean()
assert np.isclose(ato,24/13)
print(round(ato,6))
