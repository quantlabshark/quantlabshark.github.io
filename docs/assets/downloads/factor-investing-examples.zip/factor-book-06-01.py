# 6.1 显著性、多重检验与研究偏差
# https://quantlabshark.github.io/read/?slug=factor-book-06-01

import numpy as np
prob = 1 - 0.95 ** 100
p = np.array([0.001, 0.012, 0.03, 0.04, 0.20])
cutoffs = np.arange(1, 6) * 0.05 / 5
valid = np.flatnonzero(p <= cutoffs)
k = 0 if len(valid) == 0 else int(valid[-1] + 1)
assert k == 4
assert 0.994 < prob < 0.995
print(prob, k)
