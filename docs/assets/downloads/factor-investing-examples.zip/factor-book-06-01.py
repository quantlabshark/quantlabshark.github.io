# -*- coding: utf-8 -*-
# 6.1 多重检验、发表偏差与先验证据
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
pvalues = [0.001, 0.012, 0.03, 0.04, 0.20]
q = 0.05
k = max([j for j, p in enumerate(pvalues, 1)
         if p <= j * q / len(pvalues)] + [0])
false_alarm = 1 - 0.95 ** 100
assert k == 4
print(f'100次独立检验至少一次误报：{false_alarm:.2%}')
print('BH拒绝前', k, '项')
