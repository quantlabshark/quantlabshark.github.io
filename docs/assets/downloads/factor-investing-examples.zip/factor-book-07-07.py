# 7.7 风险归因：把组合波动分配到资产和因子
# https://quantlabshark.github.io/read/?slug=factor-book-07-07

# 模拟：资产不相关，年波动分别为20%与10%，资金等权。
import numpy as np
S = np.diag([.2**2,.1**2])
w = np.array([.5,.5])
vol = np.sqrt(w@S@w)
marginal = S@w/vol
contribution = w*marginal
share = contribution/vol
assert np.isclose(contribution.sum(),vol)
assert np.allclose(share,[.8,.2])
print(vol,contribution,share)
