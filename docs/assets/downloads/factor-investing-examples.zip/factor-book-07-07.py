# -*- coding: utf-8 -*-
# 7.7 组合风险的分解与归因
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
S = np.diag([.2**2,.1**2])
w = np.array([.5,.5])
vol = np.sqrt(w@S@w)
marginal = S@w/vol
contribution = w*marginal
share = contribution/vol
print('volatility:', vol)
print('contributions:', contribution)
print('risk shares:', share)
assert np.isclose(contribution.sum(),vol)
assert np.allclose(share,[.8,.2])
