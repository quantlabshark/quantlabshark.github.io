# 3.2 市场因子
# https://quantlabshark.github.io/read/?slug=factor-book-03-02

import numpy as np
rng = np.random.default_rng(20)
market = rng.normal(.0002,.01,5000)
stock = .0001 + 1.2*market + rng.normal(0,.015,5000)
X = np.column_stack([np.ones(len(market)),market])
alpha,beta = np.linalg.lstsq(X,stock,rcond=None)[0]
residual = stock-X@np.array([alpha,beta])
r2 = 1-(residual@residual)/np.sum((stock-stock.mean())**2)
assert 1.1 < beta < 1.3 and 0 < r2 < 1
print(round(beta,4),round(r2,4))
