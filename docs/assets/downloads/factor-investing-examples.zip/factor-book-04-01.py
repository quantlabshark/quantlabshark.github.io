# 4.1 主流多因子模型的结构与构造
# https://quantlabshark.github.io/read/?slug=factor-book-04-01

import numpy as np
small = np.array([0.03, 0.02, 0.01])
big = np.array([0.02, 0.01, 0.00])
smb = small.mean() - big.mean()
hml = (small[0] + big[0] - small[2] - big[2]) / 2
assert np.isclose(smb, 0.01)
assert np.isclose(hml, 0.02)
print(smb, hml)
