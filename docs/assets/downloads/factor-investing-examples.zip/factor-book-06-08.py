# -*- coding: utf-8 -*-
# 6.8 机器学习的预测、降维与样本外检验
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
rng = np.random.default_rng(17)
X = rng.normal(size=(180, 6))
y = 0.01*X[:, 0] - 0.006*X[:, 1] + rng.normal(0, 0.01, 180)
model = make_pipeline(StandardScaler(), Ridge(alpha=10))
model.fit(X[:120], y[:120])
pred = model.predict(X[120:])
r2 = 1 - np.sum((y[120:]-pred)**2) / np.sum(y[120:]**2)
assert np.isfinite(r2)
print(f'相对零预测的样本外R²：{r2:.4f}')
