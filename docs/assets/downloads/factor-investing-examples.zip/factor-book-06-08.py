# 6.8 机器学习在因子研究中的作用
# https://quantlabshark.github.io/read/?slug=factor-book-06-08

import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
rng = np.random.default_rng(17)
X = rng.normal(size=(180, 6))
y = 0.01 * X[:, 0] - 0.006 * X[:, 1] + rng.normal(0, 0.01, 180)
model = make_pipeline(StandardScaler(), Ridge(alpha=10))
model.fit(X[:120], y[:120])
pred = model.predict(X[120:])
r2 = 1 - np.sum((y[120:] - pred)**2) / np.sum(y[120:]**2)
assert np.isfinite(r2)
print(r2)
