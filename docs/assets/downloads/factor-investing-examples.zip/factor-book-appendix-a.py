# -*- coding: utf-8 -*-
# 资产价格、消费风险与市场有效性
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np

prob = np.array([0.5, 0.5])
m = np.array([0.9, 1.1])
payoffs = np.array([[120., 80.], [80., 120.]])
prices = payoffs @ (prob * m)
gross = payoffs / prices[:, None]
print("价格:", prices)
print("预期净收益:", gross @ prob - 1)
assert np.allclose(prices, [98., 102.])
assert np.allclose(gross @ (prob * m), 1.)
print("消费下降或上升10%时的m:", 0.98 / np.array([0.9, 1.1])**2)
