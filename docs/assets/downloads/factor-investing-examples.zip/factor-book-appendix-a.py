# 附录 A：理解资产价格
# https://quantlabshark.github.io/read/?slug=factor-book-appendix-a

import numpy as np
prob = np.array([0.5, 0.5])
m = np.array([0.9, 1.1])
payoffs = np.array([[120., 80.], [80., 120.]])
prices = payoffs @ (prob * m)
gross = payoffs / prices[:, None]
expected_net = gross @ prob - 1
assert np.allclose(prices, [98., 102.])
assert np.allclose(gross @ (prob * m), 1.)
print(prices, expected_net)
