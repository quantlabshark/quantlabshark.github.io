# 4.2 A股因子定价的截面检验
# https://quantlabshark.github.io/read/?slug=factor-book-04-02

import numpy as np
impact = -0.0052 * 1.02
assert np.isclose(impact, -0.005304)
print(f"{impact:.4%}")
