from pathlib import Path
import numpy as np, pandas as pd, json
from scipy.linalg import solve
w=Path(__file__).resolve().parent
p=w/'features.csv'
d=pd.read_csv(p); names=list(d.columns[1:]); X=d[names].to_numpy()[:-1]; price=d.vwap.to_numpy(); y=np.diff(price)
n=len(y); a=int(n*.6); b=int(n*.8)
tr=np.arange(a-1); va=np.arange(a,b-1); te=np.arange(b,n)
def fit_predict(train,test,ix,alpha):
 x=X[train][:,ix]; z=X[test][:,ix]; mu=x.mean(0); sd=x.std(0); sd[sd<1e-12]=1
 x=(x-mu)/sd; z=(z-mu)/sd; ym=y[train].mean(); beta=np.linalg.lstsq(np.vstack([x, np.sqrt(alpha)*np.eye(len(ix))]),np.r_[y[train]-ym,np.zeros(len(ix))],rcond=None)[0]
 return ym+z@beta
xc=X[tr]-X[tr].mean(0); yc=y[tr]-y[tr].mean(); cor=xc.T@yc/np.sqrt((xc*xc).sum(0)*(yc*yc).sum()); cor=np.nan_to_num(cor)
order=np.argsort(-np.abs(cor),kind='stable'); trials=[]
for k in [5,10,20,50,100,200]:
 for alpha in [1.,10.,100.,1000.]:
  pred=fit_predict(tr,va,order[:k],alpha)
  trials.append({'N':k,'alpha':alpha,'validation_rmse':float(np.sqrt(np.mean((y[va]-pred)**2)))})
best=min(trials,key=lambda t:t['validation_rmse']); ix=order[:best['N']]
fit_idx=np.arange(b-1); pred=fit_predict(fit_idx,te,ix,best['alpha'])
def metrics(target,prediction):
 return {'rmse':float(np.sqrt(np.mean((target-prediction)**2))),'mae':float(np.mean(np.abs(target-prediction)))}
out={'rows':len(d),'columns':len(d.columns),'missing':int(d.isna().sum().sum()),'target':'vwap[t+1], modeled as vwap[t] plus predicted delta','split_zero_based':{'training':[0,a-2],'validation':[a,b-2],'test':[b,n-1]},'selected':best,'signals':[names[i] for i in ix],'training_correlations':{names[i]:float(cor[i]) for i in ix},'validation_baseline':metrics(y[va],np.zeros(len(va))),'test_baseline':metrics(y[te],np.zeros(len(te))),'test_selected':metrics(y[te],pred),'trials':trials,'assumptions':['Rows are chronological; no timestamp supplied','Features at row t are available by t; definitions absent','No transaction cost or tradability claim']}
(w/'features-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8');print(json.dumps({k:v for k,v in out.items() if k not in ['trials','training_correlations']},ensure_ascii=False))
