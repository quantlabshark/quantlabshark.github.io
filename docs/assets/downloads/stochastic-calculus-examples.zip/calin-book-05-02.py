"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

T=1;n=1024;reps=12000;h=T/n
dw=rng.normal(scale=np.sqrt(h),size=(reps,n));w=np.cumsum(dw,axis=1)
left=np.sum(np.c_[np.zeros(reps),w[:,:-1]]*dw,axis=1)
right=np.sum(w*dw,axis=1);q=np.sum(dw*dw,axis=1);target=(w[:,-1]**2-T)/2
assert np.allclose(right-left,q) and np.allclose(left,(w[:,-1]**2-q)/2)
assert np.mean((left-target)**2)<.001
report(left_mean=float(left.mean()),left_variance=float(left.var()),analytic_variance=.5,mean_square_approximation_error=float(np.mean((left-target)**2)),probability_negative=float(2*stats.norm.cdf(1)-1))
