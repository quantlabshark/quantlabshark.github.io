"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-07-02'

x=np.linspace(-4,4,501);fig,ax=plt.subplots(figsize=(7,3.7))
for tau in [.15,.5,1.5]:
    p=np.exp(-x*x/(2*tau))/np.sqrt(2*np.pi*tau);ax.plot(x,p,label=f'Remaining time = {tau}')
    z=.7;eps=1e-5
    f=lambda s,y:np.exp(-y*y/(2*s))/np.sqrt(2*np.pi*s)
    dt=-(f(tau+eps,z)-f(tau-eps,z))/(2*eps)
    dxx=(f(tau,z+eps)-2*f(tau,z)+f(tau,z-eps))/eps**2
    check(f'backward heat residual {tau}',dt+.5*dxx,0,1e-5)
ax.set(xlabel='Position',ylabel='Gaussian density');ax.legend();finish(fig)
