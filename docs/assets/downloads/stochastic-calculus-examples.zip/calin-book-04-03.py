"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

t=np.linspace(.005,12,800)
fig,axs=plt.subplots(1,2,figsize=(9,3.8))
for a,c in [(1,BLUE),(2,GREEN)]:
 density=a/np.sqrt(2*np.pi*t**3)*np.exp(-a*a/(2*t))
 axs[0].plot(t,density,color=c,label=f"a = {a}")
 axs[1].plot(t,2*stats.norm.cdf(a/np.sqrt(t))-1,color=c,label=f"a = {a}")
axs[0].set(xlabel="Time",ylabel="First-passage density")
axs[1].set(xlabel="Time",ylabel="Survival probability",yscale="log")
for ax in axs:ax.legend(frameon=False)
save(fig,"first-passage")
report(probability_hit_2_by_4=float(2*stats.norm.sf(1)),median_a1=float(1/stats.norm.ppf(.75)**2))
