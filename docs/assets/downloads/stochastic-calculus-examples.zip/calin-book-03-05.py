"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

lam=2;T=4;arr=np.cumsum(rng.exponential(1/lam,size=100));arr=arr[arr<T]
t=np.unique(np.r_[0,arr,T,np.linspace(0,T,500)])
n=np.searchsorted(arr,t,side="right");m=n-lam*t
fig,axs=plt.subplots(2,1,figsize=(8,5),sharex=True)
axs[0].step(t,n,where="post",color=BLUE);axs[0].plot(t,lam*t,ls="--",color=GREEN);axs[0].set(ylabel="Count")
axs[1].plot(t,m,color=ORANGE);axs[1].axhline(0,color="#94a3b8",lw=.7);axs[1].set(xlabel="Time",ylabel="Compensated count")
save(fig,"poisson-path")
report(no_event_half_hour=float(np.exp(-2)),conditional_wait=float(np.exp(-1)))
