"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-07-01'

t=2.;n=1000;m=20000;h=t/n;w=np.zeros(m);left=np.zeros(m);area=np.zeros(m);iw=np.zeros(m)
for k in range(n):
    dw=rng.normal(0,np.sqrt(h),m);left+=k*h*dw;area+=w*h;iw+=w*dw;w+=dw
check('integration by parts discretization',np.max(abs(left+area-(t-h)*w)),0,2e-12)
check('variance time-weighted integral',left.var(),t**3/3,.09)
check('covariance',np.cov(left,area,ddof=0)[0,1],t**3/6,.08)
fig,ax=plt.subplots(figsize=(5.8,4.5));ax.scatter(left[:1800],area[:1800],s=5,alpha=.2);ax.set(xlabel='Integral of t dW',ylabel='Integral of W dt',aspect='equal');finish(fig)
