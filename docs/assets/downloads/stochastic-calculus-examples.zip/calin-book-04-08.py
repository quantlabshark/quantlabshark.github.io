"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

lam=3;T=2;reps=60000;ns=[20,80,320];results=[]
for n in ns:
 h=T/n;dN=rng.poisson(lam*h,size=(reps,n));M=dN-lam*h
 err=(M*M).sum(axis=1)-dN.sum(axis=1)
 mse=float(np.mean(err*err));theory=2*lam**2*T*T/n
 assert abs(mse-theory)<.07*theory
 results.append(dict(n=n,mse=mse,theory=theory))
report(poisson_quadratic_variation_errors=results)
