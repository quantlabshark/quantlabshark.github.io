"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-06-01'

n=4096;dw=rng.normal(0,np.sqrt(1/n),n);w=np.r_[0,np.cumsum(dw)]
ns=2**np.arange(3,13);q=[];ito=[]
for k in ns:
    ww=w[::n//k];d=np.diff(ww);q.append(np.sum(d*d));ito.append(np.dot(ww[:-1],d))
check('discrete product identity',w[-1]**2,2*ito[-1]+q[-1])
paths=10000;h=1/128;sq=rng.normal(0,np.sqrt(h),(paths,128))**2
check('quadratic variation mean',sq.sum(1).mean(),1,.01)
check('quadratic variation variance',sq.sum(1).var(),2/128,.001)
fig,ax=plt.subplots(figsize=(7,3.7));ax.semilogx(ns,q,'o-',label='Squared increments',base=2);ax.axhline(1,color='#d99a39',linestyle='--',label='Time = 1');ax.set(xlabel='Number of intervals',ylabel='Quadratic variation');ax.legend();finish(fig)
