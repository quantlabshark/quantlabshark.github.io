"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

fig,ax=plt.subplots(figsize=(8,4.2))
for n,c in [(2,BLUE),(5,GREEN),(10,ORANGE)]:
 ax.plot([0,1/n,1/n,1],[n,n,0,0],color=c,lw=1.8,label=f"n = {n}; area = 1")
ax.set(xlabel="Sample point",ylabel="Random-variable value",xlim=(0,1),ylim=(0,11));ax.legend(frameon=False)
save(fig,"convergence-spikes")
for n in [2,5,10,100]:assert np.isclose(n*(1/n),1)
report(spike_expectation=1,pointwise_limit=0)
