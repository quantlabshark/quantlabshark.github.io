"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-10-03'

t=np.linspace(0,1,501);h=t[1];dw=rng.normal(size=(16,500))*np.sqrt(h);w=np.column_stack([np.zeros(16),np.cumsum(dw,axis=1)]);bridge=w-t*w[:,-1,None]
check('bridge terminal',np.max(abs(bridge[:,-1])),0)
s=.2;u=.8;true=s*(1-u);wrong=min(s*(1-s),u*(1-u));check('true covariance',true,.04);check('wrong clock covariance',wrong,.16)
fig,ax=plt.subplots(figsize=(7,3.7));ax.plot(t,bridge.T,lw=.9,alpha=.55);band=1.96*np.sqrt(t*(1-t));ax.plot(t,band,'k--',lw=1);ax.plot(t,-band,'k--',lw=1);ax.set(xlabel='Time',ylabel='Brownian bridge');finish(fig)
