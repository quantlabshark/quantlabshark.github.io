"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-06'

a=.5;cbar=1.;input_= .1;sigma=.2;c0=1.;t=np.linspace(.001,12,500);m_inf=cbar+input_/a;mean=m_inf+(c0-m_inf)*np.exp(-a*t);var=sigma*sigma*(1-np.exp(-2*a*t))/(2*a);p=norm.sf((1.5-mean)/np.sqrt(var))
check('stationary exceedance',norm.sf((1.5-m_inf)/(sigma/np.sqrt(2*a))),.0668072012688581)
fig,axs=plt.subplots(1,2,figsize=(9,3.7));axs[0].fill_between(t,mean-1.96*np.sqrt(var),mean+1.96*np.sqrt(var),alpha=.17);axs[0].plot(t,mean,label='Mean');axs[0].axhline(1.5,ls='--',color='#d99a39',label='Threshold');axs[0].set(xlabel='Time',ylabel='Level');axs[0].legend();axs[1].plot(t,p);axs[1].set(xlabel='Time',ylabel='Exceedance probability');finish(fig)
