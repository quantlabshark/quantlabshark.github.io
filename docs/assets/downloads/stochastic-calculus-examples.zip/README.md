# 随机微积分及其应用：Python 示例

安装依赖：

    python -m pip install numpy scipy pandas matplotlib scikit-learn

各脚本可单独运行，例如：

    python calin-book-01-01.py

代码使用模拟数据或教学例题给出的数据。
