"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

lam=2;T=1;arr=np.array([.2,.7,.9]);N=len(arr);M=N-lam*T
area=np.sum(T-arr);N_dN=N*(N-1)/2;N_dM=N_dN-lam*area
M_dM=(M*M-N)/2
event_contribution=np.sum(np.arange(N)-lam*arr)
direct=event_contribution-lam*(area-lam*T*T/2)
assert np.isclose(N_dN,3) and np.isclose(N_dM,.6) and np.isclose(M_dM,-1) and np.isclose(direct,M_dM)
report(N_dN=float(N_dN),N_dM=float(N_dM),M_dM=float(M_dM),jump_sum_crosscheck=float(direct))
