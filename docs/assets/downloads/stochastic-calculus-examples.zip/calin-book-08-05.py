"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-08-05'

k=2.;level=1.;alpha=.5;lam=4.;T=5.;t=np.linspace(0,T,1001);fig,ax=plt.subplots(figsize=(7,3.7))
for j in range(5):
    events=np.sort(rng.uniform(0,T,rng.poisson(lam*T)));x=np.full_like(t,level)
    for u in events:x+=alpha*np.where(t>=u,np.exp(-k*np.maximum(t-u,0)),0)
    ax.plot(t,x,lw=1,alpha=.65)
expected=level+alpha*lam/k*(1-np.exp(-k*t));ax.plot(t,expected,'k--',label='Mean',lw=2)
terminal=[]
for _ in range(12000):
    e=rng.uniform(0,T,rng.poisson(lam*T));terminal.append(level+alpha*np.exp(-k*(T-e)).sum())
check('Poisson OU mean',np.mean(terminal),expected[-1],.02);check('Poisson OU variance',np.var(terminal),lam*alpha**2*(1-np.exp(-2*k*T))/(2*k),.015)
ax.set(xlabel='Time',ylabel='State');ax.legend();finish(fig)
