"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

mean=np.exp(.5*.5**2);var=np.exp(.5**2)*(np.exp(.5**2)-1)
conv=integrate.quad(lambda x:2*np.exp(-2*x)*2*np.exp(-2*(1-x)),0,1)[0]
assert np.isclose(conv,4*np.exp(-2))
assert np.isclose(stats.gamma.mean(a=2,scale=2),4)
report(lognormal_mean=float(mean),lognormal_variance=float(var),gamma_convolution_at_1=float(conv),chi_square_variance=8)
