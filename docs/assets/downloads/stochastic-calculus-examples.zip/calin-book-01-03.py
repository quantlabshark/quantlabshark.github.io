"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

n=2**15;T=1;dw=rng.normal(scale=np.sqrt(T/n),size=n);w=np.r_[0,np.cumsum(dw)]
ns=2**np.arange(3,16);q=[];tv=[]
for k in ns:
 d=np.diff(w[::n//k]);q.append(np.sum(d*d));tv.append(np.sum(abs(d)))
fig,axs=plt.subplots(1,2,figsize=(9,3.8))
axs[0].plot(ns,q,"o-",color=BLUE,label="Brownian squared increments")
axs[0].plot(ns,1/ns,color=GREEN,label="Linear path squared increments")
axs[0].axhline(1,color="#94a3b8",ls="--",lw=1);axs[0].set(xscale="log",xlabel="Number of intervals",ylabel="Squared-increment sum")
axs[1].plot(ns,tv,"o-",color=BLUE,label="Brownian absolute increments")
axs[1].axhline(1,color=GREEN,label="Linear path total variation")
axs[1].set(xscale="log",xlabel="Number of intervals",ylabel="Absolute-increment sum")
for ax in axs:ax.legend(frameon=False,fontsize=8)
save(fig,"variation")
assert abs(q[-1]-1)<.04
report(finest_quadratic_variation=float(q[-1]),finest_total_variation=float(tv[-1]))
