"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

t=np.linspace(0,15,400); exp=100*np.exp(.2*t); logistic=1000/(1+9*np.exp(-.2*t))
fig,ax=plt.subplots(figsize=(8,4.2))
ax.plot(t,exp,color=BLUE,label="Exponential");ax.plot(t,logistic,color=GREEN,label="Logistic")
ax.axhline(1000,color="#94a3b8",ls="--",lw=1,label="Capacity")
ax.set(xlabel="Time",ylabel="Population",ylim=(0,1800));ax.legend(frameon=False)
save(fig,"growth")
pv=50*(np.exp(-.02)+np.exp(-.06))
assert pv>100*np.exp(-.04)
report(logistic_t5=float(1000/(1+9*np.exp(-1))),discount_value=float(pv),constant_rate_value=float(100*np.exp(-.04)))
