"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

def hit_lt(s,a,mu,sigma):return np.exp(a*(mu-np.sqrt(mu*mu+2*sigma*sigma*s))/(sigma*sigma))
def hit_pdf(t,a,mu,sigma):return a/(sigma*np.sqrt(2*np.pi*t**3))*np.exp(-(a-mu*t)**2/(2*sigma*sigma*t))
checks=[]
for mu in [-1,0,1]:
 a=1.;sigma=.5;s=.3
 val=integrate.quad(lambda t:np.exp(-s*t)*hit_pdf(t,a,mu,sigma),0,np.inf)[0]
 assert np.isclose(val,hit_lt(s,a,mu,sigma),rtol=2e-6,atol=1e-10)
 checks.append([mu,val])
def double_lt(s,a,b,mu,sigma):
 k=np.sqrt(mu*mu+2*sigma*sigma*s)/(sigma*sigma)
 if k<1e-12:return 1.
 return (np.exp(-mu*b/sigma**2)*np.sinh(k*a)+np.exp(mu*a/sigma**2)*np.sinh(k*b))/np.sinh(k*(a+b))
assert np.isclose(double_lt(.4,1,1,0,1),1/np.cosh(np.sqrt(.8)))
a,b,mu,sigma=1.3,.7,.4,.9;s=.3
k=np.sqrt(mu**2+2*sigma**2*s)/sigma**2
# Independently solve two exponential boundary equations.
r1=-mu/sigma**2+k;r2=-mu/sigma**2-k
c=np.linalg.solve([[np.exp(-b*r1),np.exp(-b*r2)],[np.exp(a*r1),np.exp(a*r2)]],[1,1])
assert np.isclose(c.sum(),double_lt(s,a,b,mu,sigma))
report(single_barrier_laplace_checks=checks,double_barrier_transform=float(c.sum()),negative_drift_hit_probability=float(np.exp(-8)))
