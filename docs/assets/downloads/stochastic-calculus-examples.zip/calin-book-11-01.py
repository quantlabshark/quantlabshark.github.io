"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-01'

k=1.;sigma=1.;h=.02;N=250;M=10000;vel=np.zeros(M);pos=np.zeros(M);t=np.arange(N+1)*h;vp=[vel[:5].copy()];xp=[pos[:5].copy()]
e=np.exp(-k*h);vv=sigma*sigma*(1-e*e)/(2*k);xx=sigma*sigma/k**2*(h-2*(1-e)/k+(1-e*e)/(2*k));vx=sigma*sigma*(1-e)**2/(2*k*k);L=np.linalg.cholesky([[vv,vx],[vx,xx]])
for _ in range(N):
    noise=rng.normal(size=(M,2))@L.T;pos+=vel*(1-e)/k+noise[:,1];vel=e*vel+noise[:,0];vp.append(vel[:5].copy());xp.append(pos[:5].copy())
T=t[-1];expected=sigma*sigma/k**2*(T-2*(1-np.exp(-k*T))/k+(1-np.exp(-2*k*T))/(2*k));check('position variance',pos.var(),expected,.15)
check('short example variance',1-2*(1-np.exp(-1))+(1-np.exp(-2))/2,.1680912407245783)
fig,axs=plt.subplots(1,2,figsize=(10,3.7));axs[0].plot(t,vp,lw=.8);axs[0].set(xlabel='Time',ylabel='Velocity');axs[1].plot(t,xp,lw=1);axs[1].set(xlabel='Time',ylabel='Position');finish(fig)
