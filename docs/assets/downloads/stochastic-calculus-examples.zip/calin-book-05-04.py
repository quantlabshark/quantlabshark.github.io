"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

T=2;n=1000;h=T/n;t=(np.arange(n)+.5)*h
varj=np.sum((t-1)**2)*h;cov=np.sum(t-1)*h
assert abs(varj-2/3)<1e-5 and abs(cov)<1e-12
s,t1=1,2
kernel_cov=integrate.quad(lambda u:(np.sqrt(3)*u/s)*(np.sqrt(3)*u/t1),0,s)[0]
assert np.isclose(kernel_cov,s*s/t1) and not np.isclose(kernel_cov,s)
report(orthogonal_integral_variance=float(varj),covariance=float(cov),non_brownian_covariance=float(kernel_cov),brownian_covariance=s)
