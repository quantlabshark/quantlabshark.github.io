from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

def load_market(directory):
    directory=Path(directory)
    codes=pd.read_csv(directory/'universe-20180102.csv').ts_code.tolist()
    calendar=pd.to_datetime(pd.read_csv(directory/'000300.SH-index.csv',dtype={'trade_date':str}).trade_date).sort_values().unique()
    series=[]
    for code in codes:
        d=pd.read_csv(directory/(code+'-daily.csv'),dtype={'trade_date':str})
        a=pd.read_csv(directory/(code+'-adj_factor.csv'),dtype={'trade_date':str})
        d=d.merge(a,on=['ts_code','trade_date'],validate='one_to_one').sort_values('trade_date')
        adjustment=d.adj_factor/d.adj_factor.iloc[0]
        d['adj_close']=d.close*adjustment;d['adj_open']=d.open*adjustment
        d['cash_amount']=d.amount*1000
        d['date']=pd.to_datetime(d.trade_date)
        series.append(d)
    long=pd.concat(series,ignore_index=True)
    return {k:long.pivot(index='date',columns='ts_code',values=k).reindex(index=calendar,columns=codes) for k in ['adj_close','adj_open','cash_amount']}

def simulate_panel(seed=20261018,T=1500,N=60):
    rng=np.random.default_rng(seed);dates=pd.bdate_range('2018-01-03',periods=T)
    returns=rng.normal(0,.009,(T,1))+rng.normal(0,.018,(T,N))
    close=20*np.exp(np.cumsum(returns,axis=0))
    op=close*np.exp(rng.normal(0,.003,(T,N)))
    return {k:pd.DataFrame(v,index=dates) for k,v in {'adj_close':close,'adj_open':op,'cash_amount':np.exp(rng.normal(np.log(2e8),.8,(T,N)))}.items()}

def signals(panel):
    p=panel['adj_close'];ret=p.pct_change(fill_method=None)
    return {'momentum':p.shift(5)/p.shift(65)-1,
            'reversal':-(p/p.shift(5)-1),
            'lowvol':-ret.rolling(20,min_periods=20).std(ddof=1),
            'liquidity':-(ret.abs()/panel['cash_amount'].where(panel['cash_amount']>0)).rolling(20,min_periods=20).mean()*1e8}

def daily_ic(x,y,minimum=30):
    valid=x.notna()&y.notna();a=x.where(valid).rank(axis=1,method='average');b=y.where(valid).rank(axis=1,method='average')
    return a.corrwith(b,axis=1).where(valid.sum(axis=1)>=minimum)

def hac_mean(values,lags):
    a=np.asarray(values,dtype=float)
    if not np.isfinite(a).all():raise ValueError('HAC requires a consecutive, nonmissing time sequence')
    T=len(a);u=a-a.mean();longvar=u@u/T
    for k in range(1,min(lags,T-1)+1):longvar+=2*(1-k/(lags+1))*(u[k:]@u[:-k])/T
    se=np.sqrt(max(longvar,0)/T)
    return {'days':T,'mean':float(a.mean()),'se':float(se),'t':float(a.mean()/se) if se else None,'lags':lags}

parser=argparse.ArgumentParser();parser.add_argument('--market-dir');args=parser.parse_args()
p=load_market(args.market_dir) if args.market_dir else simulate_panel();all_signals=signals(p)
label=p['adj_open'].shift(-6)/p['adj_open'].shift(-1)-1
mask=(label.index>=pd.Timestamp('2018-01-03'))&(label.index<=pd.Timestamp('2025-12-31'))
rows=[];ic_table={}
for name,x in all_signals.items():
    ic=daily_ic(x,label).loc[mask]
    # Remove endpoint NaNs only; never collapse interior missing calendar days for HAC.
    ic=ic.loc[ic.first_valid_index():ic.last_valid_index()]
    if ic.isna().any():raise ValueError(f'{name}: interior missing IC day; change estimator explicitly')
    ic_table[name]=ic
    stats_by_lag={str(L):hac_mean(ic,L) for L in [4,10,20]}
    rows.append({'factor':name,'observations':int((x.loc[ic.index].notna()&label.loc[ic.index].notna()).sum().sum()),'first':str(ic.index[0].date()),'last':str(ic.index[-1].date()),'hac':stats_by_lag,'annual_mean':{str(y):float(a.mean()) for y,a in ic.groupby(ic.index.year)}})
frame=pd.DataFrame(ic_table);frame.to_csv(OUT/'daily-aggregate-ic.csv')
fig,axs=plt.subplots(1,2,figsize=(10,3.7))
for i,r in enumerate(rows):
    m=r['hac']['10'];axs[0].errorbar(m['mean'],i,xerr=1.96*m['se'],fmt='o',capsize=4,color=C[i])
axs[0].set_yticks(range(4),[r['factor'] for r in rows]);axs[0].axvline(0,color='.4',lw=.9);axs[0].set(xlabel='Mean RankIC and HAC interval')
for name,color in zip(frame,C):axs[1].plot(range(1,21),[frame[name].autocorr(k) for k in range(1,21)],color=color,label=name)
axs[1].set(xlabel='Trading-day lag',ylabel='RankIC autocorrelation');axs[1].legend(fontsize=8);save(fig,'rank-ic-and-dependence.svg')
# Cross-check our ddof=0 Bartlett HAC against statsmodels with no finite sample correction.
import statsmodels.api as sm
for name,a in frame.items():
    a=a.loc[a.first_valid_index():a.last_valid_index()]
    if a.isna().any():raise ValueError('Interior missing IC in cross-check')
    fitted=sm.OLS(a.to_numpy(),np.ones((len(a),1))).fit()
    ref=sm.stats.sandwich_covariance.cov_hac(fitted,nlags=10,use_correction=False)[0,0]
    assert np.isclose(ref,hac_mean(a,10)['se']**2,rtol=1e-10,atol=1e-14)
emit({'data':'actual fixed formation-date 60-stock sample' if args.market_dir else 'simulated','sample_formation':'2018-01-02','label':'adjusted open[t+6] / adjusted open[t+1] - 1','minimum_pairs':30,'horizon_sessions':5,'all_dates_equal_weight':True,'signals':rows,'statsmodels_crosscheck':True})
