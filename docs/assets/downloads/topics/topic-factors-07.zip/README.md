# topic-factors-07

本文件夹可独立运行。安装 requirements.txt 中的依赖后，执行 python topic-factors-07.py。结果写入当前目录，包括 results.json 与 SVG 图片。默认使用注明随机种子的模拟数据或题面给定数值。
