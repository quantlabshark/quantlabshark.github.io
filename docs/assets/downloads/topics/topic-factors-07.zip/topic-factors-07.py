from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

previous=np.array([.5,.5]);returns=np.array([.1,0.]);drift=previous*(1+returns)/(1+previous@returns);target=np.array([.5,.5]);delta=target-drift
tau=.5*np.abs(delta).sum();cost=.001*np.abs(delta).sum()
assert np.isclose(tau,1/42);assert np.isclose(cost,1/21000)
capital=1e8;adv=np.array([2e8,5e7]);trade=np.array([.04,.02]);participation=capital*trade/adv;capacity=np.min(.05*adv/trade)
assert np.allclose(participation,[.02,.04]);assert np.isclose(capacity,1.25e8)
a=np.geomspace(1e6,5e8,200);q=a[:,None]*trade/adv;eta=.1;vol=np.array([.02,.025]);c=.0005+eta*vol*np.sqrt(q)
portfolio_cost=(c*trade).sum(axis=1)
fig,axs=plt.subplots(1,2,figsize=(10,3.5));axs[0].plot(a/1e6,100*q[:,0],color=C[0],label='Stock A');axs[0].plot(a/1e6,100*q[:,1],color=C[1],label='Stock B');axs[0].axhline(5,color='.4',ls='--');axs[0].set(xlabel='Capital (million)',ylabel='Participation (%)');axs[0].legend()
axs[1].plot(a/1e6,portfolio_cost*1e4,color=C[2]);axs[1].set(xlabel='Capital (million)',ylabel='Portfolio cost (bp)');save(fig,'cost-and-capacity.svg')
emit({'data':'hypothetical execution model','drifted_weights':drift.tolist(),'one_way_turnover':float(tau),'cost_return':float(cost),'participation':participation.tolist(),'capital_bound':float(capacity),'cost_at_100million_bp':float(((.0005+eta*vol*np.sqrt(participation))*trade).sum()*1e4)})
