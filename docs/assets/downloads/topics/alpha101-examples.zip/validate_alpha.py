from pathlib import Path
import json,copy
import numpy as np,pandas as pd
from alpha_engine import Engine,Parser
W=Path(__file__).parent
def synthetic():
 rng=np.random.default_rng(20261018);T=840;N=36;index=pd.bdate_range('2020-01-01',periods=T);cols=[f'S{i:02d}' for i in range(N)]
 common=rng.normal(0,.007,(T,1));innov=common+rng.normal(0,.014,(T,N));close=(np.full((1,N),30.)*np.exp(np.cumsum(innov,axis=0)))
 op=close*np.exp(rng.normal(0,.009,(T,N)));hi=np.maximum(close,op)*(1+rng.uniform(.001,.02,(T,N)));lo=np.minimum(close,op)*(1-rng.uniform(.001,.02,(T,N)))
 volume=np.exp(rng.normal(np.log(3e6),.6,(T,N)));vwap=(op+hi+lo+close)/4
 frame=lambda a:pd.DataFrame(a,index=index,columns=cols)
 f={k:frame(v) for k,v in dict(close=close,open=op,high=hi,low=lo,volume=volume,vwap=vwap,amount=volume*vwap,cap=close*np.linspace(1e8,5e8,N)).items()}
 f['returns']=f['close'].pct_change(fill_method=None)
 for name,g in [('sector',4),('industry',6),('subindustry',8)]:f['indclass.'+name]=frame(np.tile(np.arange(N)%g,(T,1)))
 return f
if __name__=='__main__':
 f=synthetic();defs=json.loads((W/'alpha-definitions.json').read_text('utf-8'));report=[];cut=330
 changed={k:v.copy() for k,v in f.items()}
 for k,v in changed.items():
  if not k.startswith('indclass.'):v.iloc[cut:]*=1.7
 for d in defs:
  a=Engine(f).compute(d['expression']);b=Engine(changed).compute(d['expression'])
  assert np.allclose(a.iloc[:cut],b.iloc[:cut],equal_nan=True),d['number']
  assert a.notna().any().any() or d['number']==96,('Unexpected empty teaching example',d['number'])
  report.append({'number':d['number'],'no_future_dependency':True,'finite_outputs':int(a.notna().sum().sum())})
 # Powers retain missing operands, including a unit base or zero exponent.
 pp={k:v.copy() for k,v in f.items()};pp['close'].iloc[-1,0]=np.nan;pe=Engine(pp)
 assert pd.isna(pe.compute('close^0').iloc[-1,0])
 assert pd.isna(pe.compute('1^close').iloc[-1,0])
 assert pd.isna(pe.compute('signedpower(open,close)').iloc[-1,0])
 # Independent scalar definitions, separate from evaluator branches.
 e=Engine(f);x=f['close'];v=f['volume'];o=f['open'];h=f['high'];l=f['low']
 alpha3=e.compute(defs[2]['expression']);orank=o.rank(axis=1,pct=True);vrank=v.rank(axis=1,pct=True)
 expected=-np.corrcoef(orank.iloc[-10:,5],vrank.iloc[-10:,5])[0,1];assert np.isclose(alpha3.iloc[-1,5],expected)
 d=x.diff();recent=d.iloc[-5:,5];expected=d.iloc[-1,5] if (recent>0).all() or (recent<0).all() else -d.iloc[-1,5];assert np.isclose(e.compute(defs[8]['expression']).iloc[-1,5],expected)
 expected=(x.iloc[-1,5]-o.iloc[-1,5])/(h.iloc[-1,5]-l.iloc[-1,5]+.001);assert np.isclose(e.compute(defs[100]['expression']).iloc[-1,5],expected)
 # Ranking axes, weighted mean, fractional floor and missing propagation.
 assert np.allclose(e.compute('decay_linear(close,3.9)').iloc[-1],(x.iloc[-3:].to_numpy()*np.array([1,2,3])[:,None]).sum(axis=0)/6)
 assert np.allclose(e.compute('rank(rank(close))'),e.compute('rank(close)'),equal_nan=True)
 aa=e.compute('indneutralize(close,IndClass.industry)');bb=e.compute('indneutralize(indneutralize(close,IndClass.industry),IndClass.industry)');assert np.allclose(aa,bb,atol=1e-12)
 missing={k:v.copy() for k,v in f.items()};missing['close'].iloc[-1,5]=np.nan
 assert pd.isna(Engine(missing).compute('(close>0)?close:0').iloc[-1,5])
 result={'formulas':report,'scalar_checks':7,'inputs':'seed20261018,36 synthetic stocks,840 business days; groups generated for teaching only','conventions':{'rank':'mean percentile,1/N..1','argmax':'oldest=1; first tied maximum','stddev':'sample ddof1','windows':'floor','adv':'amount','missing':'propagate; no zero filling','signedpower':'sign(x)*abs(x)**a'}}
 (W/'alpha-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8');print('101 formula causality checks (96 sparse/undefined on this teaching panel); 7 independent operator/formula checks passed')
