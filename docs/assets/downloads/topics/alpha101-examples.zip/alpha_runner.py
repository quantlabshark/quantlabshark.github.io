"""Run one Alpha101 expression on a panel or on generated teaching inputs."""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd
from alpha_engine import Engine
def demo():
 from validate_alpha import synthetic
 return synthetic()
def read_panel(path):
 d=pd.read_csv(path,parse_dates=['date'])
 if d.duplicated(['date','asset']).any():raise ValueError('Duplicate date/asset')
 required=['open','high','low','close','volume','amount','vwap']
 missing=set(required)-set(d.columns)
 if missing:raise ValueError('Missing fields: '+str(missing))
 f={x:d.pivot(index='date',columns='asset',values=x).sort_index() for x in required}
 f['returns']=f['close'].pct_change(fill_method=None)
 for name in ['cap','sector','industry','subindustry']:
  if name in d:f[name if name=='cap' else 'indclass.'+name]=d.pivot(index='date',columns='asset',values=name).reindex_like(f['close'])
 return f
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--alpha',required=True,type=int);p.add_argument('--input',type=Path);p.add_argument('--demo',action='store_true');p.add_argument('--adv',choices=['amount','volume'],default='amount');p.add_argument('--output',type=Path,default=Path('alpha-output.csv'));a=p.parse_args()
 if not 1<=a.alpha<=101:p.error('alpha must be 1..101')
 if bool(a.input)==bool(a.demo):p.error('choose exactly one of --input and --demo')
 fields=demo() if a.demo else read_panel(a.input)
 definition=json.loads(Path(__file__).with_name('alpha-definitions.json').read_text('utf8'))[a.alpha-1]
 score=Engine(fields,adv_mode=a.adv).compute(definition['expression']);score.to_csv(a.output)
 print('Saved',a.output,'finite observations',int(score.notna().sum().sum()),'inputs',('TEACHING SIMULATION' if a.demo else 'user CSV'),'adv',a.adv)
