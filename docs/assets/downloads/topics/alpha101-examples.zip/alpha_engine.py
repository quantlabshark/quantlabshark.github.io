"""Independent expression evaluator for the mathematical Alpha101 definitions.

Rows are trading dates; columns are instruments. All windows use past/present
observations only. Source formulas: https://arxiv.org/abs/1601.00991.
"""
import re,math
import numpy as np
import pandas as pd

TOKEN=re.compile(r'\s*(\d+(?:\.\d*)?|\.\d+|[A-Za-z_]\w*(?:\.\w+)?|==|!=|<=|>=|\|\||&&|[-+*/^<>()?:,])')
PRECEDENCE={'||':1,'&&':2,'==':3,'!=':3,'<':3,'>':3,'<=':3,'>=':3,'+':4,'-':4,'*':5,'/':5,'^':6}
class Parser:
    def __init__(self,text):
        self.tokens=[];pos=0
        while pos<len(text.strip()):
            m=TOKEN.match(text,pos)
            if not m:raise ValueError('Bad expression at '+text[pos:pos+60])
            self.tokens.append(m.group(1).lower());pos=m.end()
        self.i=0
    def peek(self):return self.tokens[self.i] if self.i<len(self.tokens) else None
    def take(self,expected=None):
        t=self.peek()
        if expected is not None and t!=expected:raise ValueError((expected,t,self.i))
        self.i+=1;return t
    def expr(self,minimum=0):
        t=self.take()
        if t in ['+','-']:node=('unary',t,self.expr(6))
        elif t=='(':
            node=self.expr();self.take(')')
        elif t and (t[0].isdigit() or t[0]=='.'):node=('num',float(t))
        elif t:
            if self.peek()=='(':
                self.take();args=[self.expr()]
                while self.peek()==',':self.take();args.append(self.expr())
                self.take(')');node=('call',t,tuple(args))
            else:node=('field',t)
        else:raise ValueError('Unexpected end')
        while self.peek() in PRECEDENCE and PRECEDENCE[self.peek()]>=minimum:
            op=self.take();p=PRECEDENCE[op];node=('binary',op,node,self.expr(p if op=='^' else p+1))
        if minimum==0 and self.peek()=='?':
            self.take();yes=self.expr();self.take(':');node=('where',node,yes,self.expr())
        return node
    def parse(self):
        n=self.expr()
        if self.i!=len(self.tokens):raise ValueError(('Unused tokens',self.tokens[self.i:]))
        return n

class Engine:
    def __init__(self,fields,adv_mode='amount'):
        self.fields=fields;self.template=fields['close'];self.adv_mode=adv_mode;self.cache={}
    def frame(self,x):
        if isinstance(x,pd.DataFrame):return x
        return pd.DataFrame(x,index=self.template.index,columns=self.template.columns)
    @staticmethod
    def window(d):
        if not np.isscalar(d):raise ValueError('Window must be scalar')
        return max(1,math.floor(d))
    def evaluate(self,node):
        if node in self.cache:return self.cache[node]
        k=node[0]
        if k=='num':v=node[1]
        elif k=='field':
            name=node[1]
            if name.startswith('adv') and name[3:].isdigit():v=self.fields[self.adv_mode].rolling(int(name[3:]),min_periods=int(name[3:])).mean()
            else:
                if name not in self.fields:raise KeyError(name)
                v=self.fields[name]
        elif k=='unary':
            a=self.evaluate(node[2]);v=-a if node[1]=='-' else a
        elif k=='where':
            c=self.frame(self.evaluate(node[1]));a=self.frame(self.evaluate(node[2]));b=self.frame(self.evaluate(node[3]));v=a.where(c.ne(0),b).where(c.notna())
        elif k=='binary':
            a=self.evaluate(node[2]);b=self.evaluate(node[3]);op=node[1]
            with np.errstate(all='ignore'):
                if op=='+':v=a+b
                elif op=='-':v=a-b
                elif op=='*':v=a*b
                elif op=='/':v=a/b
                elif op=='^':v=self.frame(a**b).where(self.frame(a).notna()&self.frame(b).notna())
                else:
                    aa=self.frame(a);bb=self.frame(b)
                    if op=='||':v=aa.ne(0)|bb.ne(0)
                    elif op=='&&':v=aa.ne(0)&bb.ne(0)
                    elif op=='==':v=aa.eq(bb)
                    elif op=='!=':v=aa.ne(bb)
                    elif op=='<':v=aa.lt(bb)
                    elif op=='>':v=aa.gt(bb)
                    elif op=='<=':v=aa.le(bb)
                    elif op=='>=':v=aa.ge(bb)
                    v=v.astype(float).where(aa.notna()&bb.notna())
        elif k=='call':
            name=node[1];a=[self.evaluate(x) for x in node[2]];x=a[0]
            with np.errstate(all='ignore'):
                if name=='rank':v=x.rank(axis=1,method='average',pct=True)
                elif name=='abs':v=abs(x)
                elif name=='sign':v=np.sign(x)
                elif name=='log':v=np.log(x.where(x>0))
                elif name=='signedpower':v=self.frame(np.sign(x)*abs(x)**a[1]).where(self.frame(x).notna()&self.frame(a[1]).notna())
                elif name=='delay':v=x.shift(self.window(a[1]))
                elif name=='delta':v=x-x.shift(self.window(a[1]))
                elif name in ['correlation','covariance']:
                    d=self.window(a[2]);roll=x.rolling(d,min_periods=d)
                    v=roll.corr(a[1]) if name=='correlation' else roll.cov(a[1],ddof=1)
                    if name=='correlation':v=v.clip(-1,1).where(x.rolling(d).std()>1e-12).where(a[1].rolling(d).std()>1e-12)
                elif name=='scale':
                    den=x.abs().sum(axis=1,min_count=1);v=x.div(den.replace(0,np.nan),axis=0)*(a[1] if len(a)>1 else 1)
                elif name=='indneutralize':
                    groups=a[1];v=x.copy()*np.nan
                    # Classifications may change by date; no backward filling.
                    for dt in x.index:
                        xx=x.loc[dt];gg=groups.loc[dt];v.loc[dt]=xx-xx.groupby(gg).transform('mean')
                elif name in ['min','max'] and isinstance(a[1],pd.DataFrame):v=np.minimum(x,a[1]) if name=='min' else np.maximum(x,a[1])
                else:
                    d=self.window(a[1]);roll=x.rolling(d,min_periods=d)
                    if name in ['ts_min','min']:v=roll.min()
                    elif name in ['ts_max','max']:v=roll.max()
                    elif name=='sum':v=roll.sum()
                    elif name=='product':v=roll.apply(np.prod,raw=True)
                    elif name=='stddev':v=roll.std(ddof=1)
                    elif name=='ts_rank':v=roll.rank(method='average',pct=True)
                    elif name=='ts_argmax':v=roll.apply(lambda y:float(np.argmax(y)+1),raw=True)
                    elif name=='ts_argmin':v=roll.apply(lambda y:float(np.argmin(y)+1),raw=True)
                    elif name=='decay_linear':
                        weights=np.arange(1,d+1,dtype=float);weights/=weights.sum();v=roll.apply(lambda y:y@weights,raw=True)
                    else:raise ValueError('Unsupported operator '+name)
        else:raise ValueError(k)
        if isinstance(v,pd.DataFrame):v=v.replace([np.inf,-np.inf],np.nan)
        self.cache[node]=v;return v
    def compute(self,expression):
        self.cache={};return self.frame(self.evaluate(Parser(expression).parse()))

def fields_used(node):
    if node[0]=='field':return {node[1]}
    if node[0]=='num':return set()
    if node[0]=='call':children=node[2]
    elif node[0]=='unary':children=[node[2]]
    elif node[0]=='binary':children=node[2:]
    else:children=node[1:]
    return set().union(*(fields_used(n) for n in children))

if __name__=='__main__':
    import json
    from pathlib import Path
    w=Path(__file__).parent
    pages=json.loads((w/'alpha101-pages.json').read_text('utf-8'))
    text='\n'.join(re.sub(r'(?m)^\s*\d+\s*$','',p['text']) for p in pages[7:15])
    text=text[text.index('Alpha#1:'):].split('A.1. Functions')[0]
    matches=re.findall(r'Alpha#(\d+):\s*(.*?)(?=Alpha#\d+:|$)',text,re.S)
    data=[]
    for n,expr in matches:
        expr=' '.join(expr.split());ast=Parser(expr).parse();fields=sorted(fields_used(ast))
        data.append({'number':int(n),'expression':expr,'fields':fields,'needs_industry':any(f.startswith('indclass.') for f in fields),'needs_cap':'cap' in fields,'original_delay':0 if int(n) in [42,48,53,54] else 1})
    assert [r['number'] for r in data]==list(range(1,102))
    (w/'alpha-definitions.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf-8')
    print('Parsed',len(data),'formulas;',sum(r['needs_industry'] for r in data),'require historical classifications;',sum(r['needs_cap'] for r in data),'require cap')
