Alpha101 计算示例

Python 3.10+；安装：pip install -r requirements.txt
运行：python alpha_runner.py --alpha 101 --demo
个人数据：python alpha_runner.py --alpha 9 --input panel.csv

字段：date,asset,open,high,low,close,volume,amount,vwap；可选cap,sector,industry,subindustry。
每个date/asset唯一。统一交易日索引、价格复权及量价单位。adv默认成交金额；--adv volume是单独的成交股数变体。
rank平均百分位；小数窗口向下取整；样本标准差ddof=1；argmax最旧为1且并列取最早；缺失传播。
教学面板36只股票840日，随机种子20261018，行业和市值均为生成示例。96号在该面板上因多层短窗退化无最终有效值，仍保留中间结果供检查。
真实市场摘要是固定60股2018-2025的诊断结果，不含原始行情。分组费用测算不包含真实成交、借券、价格限制与持仓漂移。
数学定义：https://arxiv.org/abs/1601.00991。代码为独立实现。
