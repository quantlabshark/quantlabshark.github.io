"""Synthetic volatility change and lagged exposure. No fitted parameters."""
from timing_common import *
a=output_parser();rng=np.random.default_rng(704);r=pd.Series(np.r_[rng.normal(0,.006,130),rng.normal(0,.025,100),rng.normal(0,.008,130)]);vol=r.rolling(40).std()*np.sqrt(252);w=(.1/vol).clip(upper=1).shift(1).fillna(0)
fig,axs=plt.subplots(2,1,figsize=(8,4.7),sharex=True);axs[0].plot(vol,color=COLORS[1]);axs[0].axhline(.1,color=COLORS[0],ls='--',lw=1);axs[0].set_ylabel('Annualized volatility');axs[1].plot(w,color=COLORS[0]);axs[1].set(xlabel='Observation',ylabel='Next-period weight',ylim=(0,1.05));save(fig,a.output_dir,'volatility-target')
assert np.allclose(np.minimum(1,.1/np.array([.08,.2,.4])),[1,.5,.25]);write(a.output_dir,'calculation-04.json',{'synthetic':True,'target_weights':[1,.5,.25]})
