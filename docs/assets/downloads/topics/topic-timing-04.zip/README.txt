波动率目标与仓位调整

输入
本例使用明确设定的数值或固定随机种子的模拟数据，不需要行情API或账号。

安装
python -m pip install -r requirements.txt

运行
python topic-timing-04.py --output-dir ./output

文件
topic-timing-04.py 为本课程序；timing_common.py 是所需共享模块，请与程序放在同一目录。输出目录由 --output-dir 指定。示例计算结果位于 examples。

环境
本次实际运行 Python 3.14.6，NumPy 2.4.6，pandas 3.0.3，Matplotlib 3.11.0。
