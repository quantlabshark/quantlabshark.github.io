"""Synthetic comparison: own return sign versus cross-sectional rank."""
from timing_common import *
a=output_parser();past=np.array([-.10,-.04,.02]);future=np.array([-.03,.01,.04]);ts=np.sign(past)/3;cs=np.array([-1.,0,1.])/2
assert np.isclose(ts@future,.02);assert np.isclose(cs@future,.035)
fig,ax=plt.subplots(figsize=(8,3.5));x=np.arange(3);ax.bar(x-.18,ts,.34,label='Time series',color=COLORS[0]);ax.bar(x+.18,cs,.34,label='Cross section',color=COLORS[1]);ax.axhline(0,color='#81919d',lw=.8);ax.set(xticks=x,xticklabels=['A','B','C'],ylabel='Signed capital weight');ax.legend(frameon=False);save(fig,a.output_dir,'momentum-definitions')
write(a.output_dir,'calculation-01.json',{'synthetic':True,'ts_weights':ts.tolist(),'cs_weights':cs.tolist(),'ts_return':float(ts@future),'cs_return':float(cs@future)})
