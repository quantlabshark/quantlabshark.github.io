"""Shared plotting and accounting helpers. No credentials or market data bundled."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#8b99a6','axes.labelcolor':'#40505e','xtick.color':'#40505e','ytick.color':'#40505e','grid.color':'#d9e1e7','grid.alpha':.55,'svg.fonttype':'path','figure.facecolor':'white','axes.facecolor':'white','savefig.bbox':'tight'})
COLORS=['#176a70','#cb7b35','#5d669c','#a55368']
def output_parser(data=False):
    p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,default=Path('output'))
    if data:p.add_argument('--data-dir',type=Path,required=True,help='Directory containing six authorized ETF CSV inputs; not bundled.')
    a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True);return a
def save(fig,out,name):
    fig.savefig(Path(out)/(name+'.svg'));plt.close(fig)
def write(out,name,obj):Path(out,name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def equity_metrics(nav,initial=1.):
    nav=pd.Series(nav);r=nav.pct_change();r.iloc[0]=nav.iloc[0]/initial-1
    years=(nav.index[-1]-nav.index[0]).days/365.25
    peaks=np.maximum.accumulate(np.r_[initial,nav.values])[1:]
    return {'total_return':float(nav.iloc[-1]/initial-1),'cagr':float((nav.iloc[-1]/initial)**(1/years)-1),'volatility':float(r.std(ddof=1)*np.sqrt(252)),'sharpe_cash0':float(r.mean()/r.std(ddof=1)*np.sqrt(252)),'max_drawdown':float(np.min(nav.values/peaks-1))}
def backtest(opens,closes,weights,cost=.0005,start='2016-01-01'):
    """weights are indexed by signal-close date. At open d use weights.shift(1)[d].
    Fractional adjusted units, no borrowing, exact fees on absolute traded value.
    Cash rate zero. Begin in cash. Final close liquidation pays same fee.
    """
    assert opens.index.equals(closes.index) and weights.index.equals(opens.index)
    assert (opens>0).all().all() and (closes>0).all().all()
    decision=weights.shift(1).fillna(0);use=opens.index>=pd.Timestamp(start)
    cash=1.;shares=np.zeros(opens.shape[1]);out=[]
    for d in opens.index[use]:
        op=opens.loc[d].to_numpy();cl=closes.loc[d].to_numpy();target=decision.loc[d].to_numpy()
        assert np.min(target)>=-1e-12 and np.sum(target)<=1+1e-10
        old=shares*op;pre=cash+old.sum();post=pre
        for _ in range(10):post=pre-cost*np.abs(target*post-old).sum()
        turnover=np.abs(target*post-old).sum();fee=cost*turnover
        assert abs(pre-post-fee)<1e-10
        shares=target*post/op;cash=post*(1-target.sum())
        out.append({'date':d,'nav':cash+float(shares@cl),'fee':fee,'turnover':turnover,'exposure':float(target.sum())})
    end_fee=cost*float(shares@closes.loc[out[-1]['date']].to_numpy());out[-1]['nav']-=end_fee;out[-1]['fee']+=end_fee;out[-1]['turnover']+=end_fee/cost if cost else float(shares@closes.loc[out[-1]['date']].to_numpy())
    return pd.DataFrame(out).set_index('date')
