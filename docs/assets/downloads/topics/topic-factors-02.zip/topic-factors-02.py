from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

# A financial fact has a report period and multiple disclosure versions.
versions=pd.DataFrame({'report_end':pd.to_datetime(['2023-12-31']*2),'available_at':pd.to_datetime(['2024-03-29 18:00','2024-05-15 18:00']),'value':[10.,8.]})
decisions=pd.DataFrame({'decision_at':pd.to_datetime(['2024-03-29 15:30','2024-04-01 15:30','2024-05-15 15:30','2024-05-16 15:30'])})
joined=pd.merge_asof(decisions.sort_values('decision_at'),versions.sort_values('available_at'),left_on='decision_at',right_on='available_at',direction='backward')
assert pd.isna(joined.value.iloc[0])
assert joined.value.iloc[1:].tolist()==[10.,10.,8.]
days=pd.date_range('2024-03-20','2024-05-25');visible=np.where(days>=pd.Timestamp('2024-05-16'),8,np.where(days>=pd.Timestamp('2024-04-01'),10,np.nan))
fig,ax=plt.subplots(figsize=(8,3.5));ax.step(days,visible,where='post',lw=2,color=C[0],label='Known at decision time');ax.axhline(8,color=C[1],ls='--',label='Latest revised value')
for d in ['2024-03-29','2024-05-15']:ax.axvline(pd.Timestamp(d),color='.55',lw=.9,ls=':')
ax.set(xlabel='Decision date',ylabel='Annual profit (arbitrary units)',ylim=(7,11));ax.legend();fig.autofmt_xdate();save(fig,'point-in-time.svg')
joined.to_csv(OUT/'pit-example.csv',index=False)
emit({'data':'simulated','visible_after_first_disclosure':10,'visible_after_revision':8,'ttm_example':12-2+3.5})
