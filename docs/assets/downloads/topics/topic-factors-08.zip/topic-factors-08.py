from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

rng=np.random.default_rng(88);n=1200;baseline=rng.normal(size=n);novel=rng.normal(size=n);candidate=.9*baseline+.3*novel;y=.02*baseline+.015*novel+rng.normal(0,.03,n)
X=np.column_stack([np.ones(n),baseline]);rx=candidate-X@np.linalg.lstsq(X,candidate,rcond=None)[0];ry=y-X@np.linalg.lstsq(X,y,rcond=None)[0]
fwl=rx@ry/(rx@rx);full=np.linalg.lstsq(np.column_stack([X,candidate]),y,rcond=None)[0][-1];assert np.isclose(fwl,full)
cut=800;model0=np.linalg.lstsq(X[:cut],y[:cut],rcond=None)[0];X1=np.column_stack([X,candidate]);model1=np.linalg.lstsq(X1[:cut],y[:cut],rcond=None)[0]
mse0=np.mean((y[cut:]-X[cut:]@model0)**2);mse1=np.mean((y[cut:]-X1[cut:]@model1)**2)
fig,axs=plt.subplots(1,2,figsize=(9,3.7));axs[0].scatter(baseline,candidate,s=7,alpha=.3,color=C[0]);axs[0].set(xlabel='Existing factor',ylabel='Candidate factor')
axs[1].scatter(rx,ry,s=7,alpha=.3,color=C[1]);xx=np.linspace(rx.min(),rx.max(),100);axs[1].plot(xx,fwl*xx,color=C[2]);axs[1].set(xlabel='Candidate residual',ylabel='Return residual');save(fig,'incremental-information.svg')
emit({'data':'simulated known incremental signal','factor_correlation':float(np.corrcoef(baseline,candidate)[0,1]),'fwl_coefficient':float(fwl),'full_model_coefficient':float(full),'holdout_mse_existing':float(mse0),'holdout_mse_augmented':float(mse1),'loss_improvement':float(mse0-mse1)})
