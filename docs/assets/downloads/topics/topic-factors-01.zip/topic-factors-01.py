from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

rng=np.random.default_rng(11);N=100;T=120
x=rng.normal(size=N);y=.015*x+rng.normal(0,.025,N)
path=100*np.exp(np.cumsum(rng.normal(.0002,.015,T)))
fig,axs=plt.subplots(1,2,figsize=(10,3.7))
axs[0].plot(path,color=C[0]);axs[0].set(xlabel='Trading day',ylabel='One stock: adjusted price')
axs[1].scatter(x,y*100,s=20,alpha=.7,color=C[1]);axs[1].set(xlabel='Cross-sectional score',ylabel='Next-period return (%)')
save(fig,'cross-section-and-time.svg')
x0=np.array([1.,2.,3.,4.]);y0=np.array([.01,.04,.02,.06]);b=np.cov(x0,y0,ddof=0)[0,1]/np.var(x0)
assert np.isclose(b,.013)
assert np.isclose(stats.spearmanr(x0,y0).statistic,.8)
emit({'data':'simulated','hand_example_slope':float(b),'hand_example_rank_ic':.8,'sample_rank_ic':float(stats.spearmanr(x,y).statistic)})
