"""Fixed-parameter ETF timing experiment, 2016-2025; 2015 is warm-up.
Supply licensed fund_daily and fund_adj CSVs. Raw inputs are never exported.
Example: python topic-timing-10.py --data-dir ./market --output-dir ./output
"""
from timing_common import *
import hashlib
CODES=['510300.SH','510500.SH','518880.SH']
def signals(close):
    ma=(close>close.rolling(200,min_periods=200).mean()).astype(float)
    high=close.shift(1).rolling(60,min_periods=60).max();low=close.shift(1).rolling(20,min_periods=20).min();state=0;channel=[]
    for d,p in close.items():
        if pd.notna(high[d]) and p>high[d]:state=1
        elif pd.notna(low[d]) and p<low[d]:state=0
        channel.append(state)
    vol=close.pct_change().rolling(60,min_periods=60).std(ddof=1)*np.sqrt(252)
    return pd.DataFrame({'MA200':ma,'Breakout60_20':channel,'MA200_Vol10':ma*(.1/vol).clip(upper=1).fillna(0),'Hold':1.},index=close.index)
def load_data(folder):
    opens={};closes={};sig={};audit=[]
    for code in CODES:
        files=[folder/(code+'-fund.csv'),folder/(code+'-fund-adj.csv')]
        raw=pd.read_csv(files[0],dtype={'trade_date':str});adj=pd.read_csv(files[1],dtype={'trade_date':str})
        early=folder/(code+'-fund-adj-early.csv')
        if early.exists():
            files.append(early);extra=pd.read_csv(early,dtype={'trade_date':str});combined=pd.concat([adj,extra],ignore_index=True)
            assert (combined.groupby('trade_date').adj_factor.nunique()<=1).all()
            adj=combined.drop_duplicates('trade_date')
        assert not raw.trade_date.duplicated().any() and not adj.trade_date.duplicated().any()
        d=raw.merge(adj[['trade_date','adj_factor']],on='trade_date',validate='one_to_one',how='left');assert d.adj_factor.notna().all();d.index=pd.to_datetime(d.trade_date,format='%Y%m%d');d=d.sort_index();d=d.loc['2015-01-01':'2025-12-31'];assert (d[['open','close','adj_factor']]>0).all().all()
        # Multiplication uses each date's factor. A common constant normalization cancels in returns/signals.
        opens[code]=d.open*d.adj_factor;closes[code]=d.close*d.adj_factor;sig[code]=signals(closes[code]);audit.append({'code':code,'rows':len(d),'first':str(d.index[0].date()),'last':str(d.index[-1].date()),'input_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}})
    op=pd.DataFrame(opens);cl=pd.DataFrame(closes)
    assert not op.loc['2016-01-01':].isna().any().any(),'Missing price in evaluation period'
    common=op.dropna().index;op=op.loc[common];cl=cl.loc[common]
    assert not op.loc['2016-01-01':].isna().any().any()
    return op,cl,sig,audit
def main():
    a=output_parser(data=True);op,cl,sig,audit=load_data(a.data_dir);runs={};records=[]
    for cost in [0.,.0005,.001]:
        for code in CODES:
            for method in ['Hold','MA200','Breakout60_20','MA200_Vol10']:
                w=sig[code][[method]].reindex(op.index);w.columns=[code];r=backtest(op[[code]],cl[[code]],w,cost);key=code+'_'+method;rec={'instrument':code,'strategy':method,'cost_bps_one_way':cost*1e4,**equity_metrics(r.nav),'avg_target_exposure':float(r.exposure.mean()),'fee_in_initial_wealth_units':float(r.fee.sum()),'trade_sessions':int((r.turnover>1e-8).sum())};records.append(rec)
                if cost==.0005:runs[key]=r
        for method in ['Hold','MA200','Breakout60_20','MA200_Vol10']:
            w=pd.DataFrame({c:sig[c][method] for c in CODES}).reindex(op.index)/3;r=backtest(op,cl,w,cost);key='EqualBudget_'+method;records.append({'instrument':'EqualBudget','strategy':method,'cost_bps_one_way':cost*1e4,**equity_metrics(r.nav),'avg_target_exposure':float(r.exposure.mean()),'fee_in_initial_wealth_units':float(r.fee.sum()),'trade_sessions':int((r.turnover>1e-8).sum())})
            if cost==.0005:runs[key]=r
    metrics=pd.DataFrame(records);metrics.to_csv(a.output_dir/'etf-summary.csv',index=False);nav=pd.DataFrame({k:v.nav for k,v in runs.items()});nav.to_csv(a.output_dir/'strategy-nav.csv',float_format='%.12g')
    annual=nav.groupby(nav.index.year).last().pct_change();annual.iloc[0]=nav.groupby(nav.index.year).last().iloc[0]-1;annual.to_csv(a.output_dir/'annual-returns.csv')
    rolling=nav.pct_change(252).dropna();rolling.to_csv(a.output_dir/'rolling-252-return.csv',float_format='%.10g')
    # Future values cannot affect the signals through the cutoff.
    cutoff=pd.Timestamp('2022-06-30');future_tests=[]
    for c in CODES:
        original=cl[c].copy();changed=original.copy();changed.loc[changed.index>cutoff]*=1.7
        first=signals(original).loc[:cutoff];second=signals(changed).loc[:cutoff];assert first.equals(second);future_tests.append({'code':c,'future_perturbation_preserves_past_signals':True})
    # Check accounting on a constant-price asset: only entry and final-exit fees remain.
    ix=pd.date_range('2020-01-01',periods=5);flat=pd.DataFrame({'x':100.},index=ix);one=pd.DataFrame({'x':1.},index=ix);test=backtest(flat,flat,one,.0005,'2020-01-02');assert np.isclose(test.nav.iloc[-1],.9995/1.0005)
    fig,axs=plt.subplots(3,1,figsize=(9,8),sharex=True)
    for ax,c in zip(axs,CODES):
        for j,m in enumerate(['Hold','MA200','Breakout60_20']):ax.plot(nav.index,nav[c+'_'+m],color=COLORS[j],lw=1.2,label=m)
        ax.text(.015,.89,c,transform=ax.transAxes,color='#40505e');ax.set_ylabel('Wealth');ax.grid(axis='y',lw=.5)
    axs[0].legend(frameon=False,ncol=3);fig.autofmt_xdate();save(fig,a.output_dir,'etf-wealth-comparison')
    fig,axs=plt.subplots(2,1,figsize=(9,5.5),sharex=True)
    for j,m in enumerate(['Hold','MA200','Breakout60_20','MA200_Vol10']):
        s=nav['EqualBudget_'+m];axs[0].plot(s.index,s,label=m,color=COLORS[j]);peak=np.maximum.accumulate(np.r_[1.,s.values])[1:];axs[1].plot(s.index,s.values/peak-1,color=COLORS[j],lw=1)
    axs[0].legend(frameon=False,ncol=2,fontsize=8);axs[0].set_ylabel('Wealth');axs[1].set_ylabel('Drawdown');fig.autofmt_xdate();save(fig,a.output_dir,'multi-asset-wealth-drawdown')
    fig,ax=plt.subplots(figsize=(8,3.6));labels=['Hold','MA200','Breakout60_20','MA200_Vol10'];x=np.arange(10);width=.2
    for j,m in enumerate(labels):ax.bar(x+(j-1.5)*width,annual['EqualBudget_'+m],width,color=COLORS[j],label=m)
    ax.axhline(0,color='#708090',lw=.7);ax.set(xticks=x,xticklabels=annual.index.astype(str),ylabel='Calendar-year return');ax.legend(frameon=False,ncol=2,fontsize=8);save(fig,a.output_dir,'annual-return-comparison')
    write(a.output_dir,'experiment-audit.json',{'input_data':audit,'evaluation_start':str(nav.index[0].date()),'evaluation_end':str(nav.index[-1].date()),'sessions':len(nav),'warmup':'2015, each instrument uses its observed sessions; 510500 lacks 2015-04-13/14 only','signal':'close t; execute open t+1; no same-close fills','initial_position':'cash','terminal':'liquidate at final close with transaction cost','cash_rate':0,'adjustment':'raw OHLC multiplied by same-date fund_adj; synthetic fractional adjusted units, reinvestment proxy','execution':'unlimited fractional units at reported open; no leverage/short/minimum fee/lot or order-book capacity model','parameters_fixed_before_results':{'ma':200,'breakout_entry':60,'breakout_exit':20,'vol_days':60,'vol_target_annual':.1},'future_boundary_tests':future_tests,'accounting_flat_price_test_passed':True,'annual_returns_compound_to_total':bool(np.allclose((1+annual).prod(),nav.iloc[-1]))})
    print(metrics[(metrics.cost_bps_one_way==5)&(metrics.instrument=='EqualBudget')].to_string(index=False))
if __name__=='__main__':main()
