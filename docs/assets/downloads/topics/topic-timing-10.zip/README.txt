三只 ETF 的趋势规则复现

输入
请自行准备有使用权限的六份CSV：三只ETF代码510300.SH、510500.SH、518880.SH，各对应 <代码>-fund.csv 与 <代码>-fund-adj.csv。行情含 trade_date/open/close，因子含 trade_date/adj_factor。若使用分段因子，另放 <代码>-fund-adj-early.csv；重复日期会检查数值一致。覆盖2015–2025，2015只作预热。原始行情不包含在压缩包中。

安装
python -m pip install -r requirements.txt

运行
python topic-timing-10.py --data-dir ./market --output-dir ./output

文件
topic-timing-10.py 为本课程序；timing_common.py 是所需共享模块，请与程序放在同一目录。输出目录由 --output-dir 指定。示例计算结果位于 examples。

环境
本次实际运行 Python 3.14.6，NumPy 2.4.6，pandas 3.0.3，Matplotlib 3.11.0。
