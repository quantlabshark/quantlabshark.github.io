# -*- coding: utf-8 -*-
# 7.3 收益预测、风险与组合优化
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟两资产：比较预算约束均值方差与最小方差。
import numpy as np
S = np.array([[.04,.01],[.01,.09]])
mu = np.array([.08,.12]); one = np.ones(2); risk_aversion = 3
inv = np.linalg.inv(S)
eta = (one@inv@mu-risk_aversion)/(one@inv@one)
w = inv@(mu-eta*one)/risk_aversion
w_min = inv@one/(one@inv@one)
for name, weights in [('mean_variance',w), ('minimum_variance',w_min)]:
    print(name, weights, 'return', weights@mu,
          'volatility', np.sqrt(weights@S@weights))
assert np.isclose(w.sum(),1)
assert np.allclose(w, [20/33,13/33])
assert np.allclose(w_min, [8/11,3/11])
