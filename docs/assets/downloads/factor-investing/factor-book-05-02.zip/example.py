# -*- coding: utf-8 -*-
# 5.2 用基本面区分价格反转
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
far = 0.03 - (-0.01)
fur = 0.01 - 0.02
assert abs(far - 0.04) < 1e-12
assert abs(fur + 0.01) < 1e-12
print(f'FAR={far:.2%}, FUR={fur:.2%}')
