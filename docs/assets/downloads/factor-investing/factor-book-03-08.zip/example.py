# -*- coding: utf-8 -*-
# 异常换手率怎样衡量交易热度变化
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
turnover = [0.01] * 231 + [0.04] * 21
recent = sum(turnover[-21:]) / 21
annual = sum(turnover[-252:]) / 252
abnormal = recent / annual
print(f"近月均值 {recent:.2%}，近年均值 {annual:.2%}，异常换手 {abnormal:.2f}")
assert abs(annual - 0.0125) < 1e-12
assert abs(abnormal - 3.2) < 1e-12
