# -*- coding: utf-8 -*-
# 7.1 从选股指标到预期收益
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟截面：预测的是相对股票池均值的收益偏离。
from statistics import mean, pstdev
raw = [-1.0, 0.0, 1.0]
z = [(x-mean(raw))/pstdev(raw) for x in raw]
ic, cross_section_vol = 0.05, 0.04
forecast = [ic*cross_section_vol*x for x in z]
print([round(x*100, 4) for x in forecast])
assert abs(sum(forecast)) < 1e-12
