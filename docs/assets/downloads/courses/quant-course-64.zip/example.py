# -*- coding: utf-8 -*-
# 64 · 衍生品、波动率与后续学习
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
def payoffs(spot, strike):
    call, put = max(spot-strike, 0), max(strike-spot, 0)
    return call, put
for spot in [70, 100, 130]:
    call, put = payoffs(spot, 100)
    assert call-put == spot-100
S0, up, down, gross = 100.0, 120.0, 80.0, 1.02
delta = (20.0-0.0)/(up-down)
bank = -delta*down/gross
risk_neutral = (gross*S0-down)/(up-down)
replication = delta*S0+bank
discounted = risk_neutral*20/gross
print(delta, round(bank,6), risk_neutral, round(replication,6))
assert abs(replication-discounted)<1e-12
assert abs(delta*up+gross*bank-20)<1e-12
assert abs(delta*down+gross*bank)<1e-12
