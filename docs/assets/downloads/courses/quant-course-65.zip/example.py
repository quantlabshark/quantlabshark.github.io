# -*- coding: utf-8 -*-
# 65 · 均线策略研究项目
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
import pandas as pd

def experiment(seed=17,n=700,fee=.0005):
    rng=np.random.default_rng(seed)
    dates=pd.bdate_range('2020-01-01',periods=n)
    price=pd.Series(100*np.exp(np.cumsum(rng.normal(.0002,.012,n))),index=dates)
    ret=price.pct_change().fillna(0)
    fast=price.rolling(20,min_periods=20).mean()
    slow=price.rolling(60,min_periods=60).mean()
    signal=(fast>slow).astype(float).where(slow.notna(),0)
    # t-2收盘得到信号，t-1收盘执行，承担t-1至t的收益
    position=signal.shift(2).fillna(0)
    turnover=position.diff().abs().fillna(position.abs())
    cost=fee*turnover
    # 样本结束平仓，最后一期额外记一次卖出成本
    cost.iloc[-1]+=fee*position.iloc[-1]
    strategy=(1-cost)*(1+position*ret)-1
    baseline_cost=pd.Series(0.,index=dates)
    baseline_cost.iloc[1]=fee
    baseline_cost.iloc[-1]+=fee
    baseline=(1-baseline_cost)*(1+ret)-1
    out=pd.DataFrame({'price':price,'signal':signal,'position':position,
        'turnover':turnover,'cost':cost,'strategy_return':strategy,
        'baseline_return':baseline})
    out['equity']=(1+strategy).cumprod()
    out['baseline_equity']=(1+baseline).cumprod()
    return out

def describe(returns):
    equity=(1+returns).cumprod()
    # 起始净值1也纳入历史峰值
    peak=equity.cummax().clip(lower=1)
    return {'total_return':equity.iloc[-1]-1,
        'annualized_volatility':returns.std(ddof=1)*np.sqrt(252),
        'maximum_drawdown':(1-equity/peak).max()}

result=experiment()
assert len(result)==700 and result.iloc[:61].position.eq(0).all()
assert np.allclose(result.position.to_numpy()[2:],result.signal.to_numpy()[:-2])
for name in ['strategy_return','baseline_return']:
    print(name,describe(result[name]))
