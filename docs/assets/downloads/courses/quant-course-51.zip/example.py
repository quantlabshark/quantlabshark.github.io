# -*- coding: utf-8 -*-
# 51 · 异步交易与多资产协方差
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
ta = np.array([0., 1., 3.])
tb = np.array([0., 2., 3.])
ra = np.array([0.01, -0.02])
rb = np.array([0.03, 0.01])
covariance = 0.0
pairs = []
for i, ai in enumerate(ra):
    for j, bj in enumerate(rb):
        if min(ta[i+1], tb[j+1]) > max(ta[i], tb[j]):
            covariance += ai*bj
            pairs.append((i+1,j+1))
print('重叠配对', pairs, '协变差', covariance)
assert np.isclose(covariance, -0.0005)
