# -*- coding: utf-8 -*-
# 54 · 波动率预测与状态变化
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
x = np.array([0.0001, 0.00012, 0.00015, 0.0009, 0.0007, 0.0003])
beta, gamma = 0.7, 0.2
long_run = 0.0001
omega = (1-beta-gamma)*np.log(long_run)
h = np.empty(len(x)+1)
h[0] = long_run
for t in range(len(x)):
    h[t+1] = np.exp(omega + beta*np.log(h[t]) + gamma*np.log(x[t]))
for t in range(len(x)):
    print('日',t+1,'当日事前预测',round(h[t],7),'收盘测度',x[t],
          '下一日预测',round(h[t+1],7))
assert h[4] > h[3]
