# -*- coding: utf-8 -*-
# 36 · 预测模型的完整研究流程
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error

rng = np.random.default_rng(36)
n = 180
close = 100*np.cumprod(1+rng.normal(0, 0.01, n))
opening = np.r_[100.0, close[:-1]]
price = pd.Series(close)
frame = pd.DataFrame({"return1": price.pct_change(fill_method=None),
                      "momentum3": price/price.shift(3)-1,
                      "volatility3": price.pct_change(fill_method=None).rolling(3).std()})
frame["target"] = pd.Series(opening).shift(-2)/pd.Series(opening).shift(-1)-1
frame["label_end"] = np.arange(n)+2
frame = frame.dropna()
columns = ["return1", "momentum3", "volatility3"]
train = frame.loc[frame["label_end"] <= 60]
valid = frame.loc[(frame.index >= 60) & (frame.index < 80)]
test = frame.loc[frame.index >= 90]

def fit_model(alpha, data):
    model = make_pipeline(StandardScaler(), Ridge(alpha=alpha))
    return model.fit(data[columns], data["target"])

scores = {}
for alpha in [0.1, 1.0, 10.0]:
    model = fit_model(alpha, train)
    scores[alpha] = mean_squared_error(valid["target"], model.predict(valid[columns]))
best = min(scores, key=lambda a: (scores[a], a))
ready = frame.loc[frame["label_end"] <= 90]
model = fit_model(best, ready)
prediction = model.predict(test[columns])
baseline = np.full(len(test), ready["target"].mean())
print("validation MSE:", scores, "selected alpha:", best)
print("test MSE model/mean:", mean_squared_error(test["target"], prediction),
      mean_squared_error(test["target"], baseline))

cash, shares, cost = 10000.0, 0, 0.001
nav, trades = [cash], 0
for t, forecast in zip(test.index, prediction):
    price_in = opening[t+1]
    target = int(forecast > 0.002)
    if target and shares == 0:
        shares = int(cash/(price_in*(1+cost)))
        cash -= shares*price_in*(1+cost)
        trades += int(shares > 0)
    elif not target and shares > 0:
        cash += shares*price_in*(1-cost)
        shares = 0
        trades += 1
    nav.append(cash+shares*opening[t+2])
if shares:
    cash += shares*opening[test.index[-1]+2]*(1-cost)
    nav[-1] = cash
    shares = 0
    trades += 1
nav = np.array(nav)
print("synthetic account return:", nav[-1]/nav[0]-1, "trades:", trades)
assert train["label_end"].max() <= 60
assert ready["label_end"].max() <= 90
assert shares == 0 and cash >= 0
