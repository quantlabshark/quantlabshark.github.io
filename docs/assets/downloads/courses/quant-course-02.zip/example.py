# -*- coding: utf-8 -*-
# 02 · 股票、债券与衍生品怎样产生盈亏
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
purchase, strike, premium = 100, 100, 5
for terminal in [90, 100, 103, 105, 110]:
    stock_pnl = terminal-purchase
    call_pnl = max(terminal-strike, 0)-premium
    print(terminal, stock_pnl, call_pnl)
futures_pnl = (103-100)*10
print("期货盈亏/名义金额/保证金:", futures_pnl, 1000, 100)
assert futures_pnl == 30
