# -*- coding: utf-8 -*-
from scipy.stats import chi2_contingency
table=[[20,30],[35,15]]
result=chi2_contingency(table,correction=False)
print('expected counts',result.expected_freq)
print('chi-square',result.statistic,'p',result.pvalue)
