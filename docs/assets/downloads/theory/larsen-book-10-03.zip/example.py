# -*- coding: utf-8 -*-
from scipy.stats import chi2_contingency
table=[[60,40],[45,55]]
result=chi2_contingency(table,correction=False)
print('expected counts',result.expected_freq)
print('chi-square',result.statistic,'p',result.pvalue)

import numpy as np
rng=np.random.default_rng(20261018)
ordered=np.sort(rng.normal(size=(100000,10)),axis=1)
span=ordered[:,-1]-ordered[:,0]
upper=(ordered[:,-1]-ordered[:,-2])/span
lower=(ordered[:,1]-ordered[:,0])/span
observed=11/19
print('Dixon observed',observed,'upper-only 95% threshold',np.quantile(upper,.95))
print('two-end 95% threshold',np.quantile(np.maximum(upper,lower),.95))
print('two-end simulated p',(1+np.count_nonzero(np.maximum(upper,lower)>=observed))/(len(upper)+1))
