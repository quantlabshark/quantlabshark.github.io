"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-07'

R=1.;D=.5;h=.001;n=6000;x=np.zeros((n,3));active=np.ones(n,dtype=bool);tau=np.zeros(n);step=0
while active.any():
    step+=1;ids=np.flatnonzero(active);x[ids]+=np.sqrt(2*D*h)*rng.normal(size=(len(ids),3));done=np.sum(x[ids]**2,axis=1)>=R*R;tau[ids[done]]=step*h;active[ids[done]]=False
    assert step<15000
check('3D exit time discretized',tau.mean(),R*R/(6*D),.035)
fig,ax=plt.subplots(figsize=(7,3.7));ax.hist(tau,bins=60,density=True,alpha=.5);ax.axvline(1/3,color='#d99a39',ls='--',label='Continuous mean');ax.set(xlabel='Exit time',ylabel='Density');ax.legend();finish(fig)
