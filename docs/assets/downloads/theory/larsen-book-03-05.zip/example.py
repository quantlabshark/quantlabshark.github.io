# -*- coding: utf-8 -*-
import numpy as np
cov=np.array([[.01,.002],[.002,.01]])
w=np.array([.5,.5]);variance=w@cov@w
assert np.isclose(variance,.006)
print('equal-weight variance',variance,'standard deviation',variance**.5)

from math import factorial
m3=factorial(3)-3*factorial(2)+3*factorial(1)-1
m4=factorial(4)-4*factorial(3)+6*factorial(2)-4+1
assert (m3,m4-3)==(2,6)
print('exponential skewness',m3,'excess kurtosis',m4-3)
