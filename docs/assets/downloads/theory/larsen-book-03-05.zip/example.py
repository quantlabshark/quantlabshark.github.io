# -*- coding: utf-8 -*-
import numpy as np
cov=np.array([[4.,1.],[1.,9.]])
w=np.array([.6,.4])
variance=w@cov@w
assert np.isclose(variance,.36*4+.16*9+2*.6*.4)
print('weighted sum variance',variance,'standard deviation',variance**.5)
