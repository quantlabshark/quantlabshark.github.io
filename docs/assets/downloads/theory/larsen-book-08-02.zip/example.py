# -*- coding: utf-8 -*-
import numpy as np
x=np.array([1,3,3,4,4,5,7,20])
q1,q3=np.quantile(x,[.25,.75]);iqr=q3-q1
print('mean',x.mean(),'median',np.median(x),'quartiles',q1,q3)
print('outer fence observations',x[(x<q1-1.5*iqr)|(x>q3+1.5*iqr)])
