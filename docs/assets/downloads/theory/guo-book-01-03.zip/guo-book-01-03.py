from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
import matplotlib.pyplot as plt
x=np.linspace(0,1,501);mean=.05+.03*x;variance=.042*x*x-.012*x+.01
fig,ax=plt.subplots(figsize=(7.2,3.8))
for lam,color in [(1,'#b98a49'),(3,'#387ca3')]:
    utility=mean-lam*variance;best=np.argmax(utility)
    ax.plot(x,utility,label=f'风险系数 {lam}',color=color)
    ax.scatter(x[best],utility[best],color=color,s=25)
    exact=(.03+.012*lam)/(.084*lam)
    assert abs(x[best]-exact)<.0021
    print('风险系数',lam,'第一资产权重',exact)
ax.set(xlabel='第一资产权重',ylabel='均值减风险惩罚');ax.legend(frameon=False)
save(fig,'decision-objective.svg')
