"""Stopping a fair random walk and checking a discrete Ito identity."""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def main(output):
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(20261018)
    samples = 60000
    values = np.zeros(samples, dtype=int)
    durations = np.zeros(samples, dtype=int)
    active = np.ones(samples, dtype=bool)
    paths = [values[:12].copy()]
    while active.any():
        values[active] += rng.choice([-1, 1], active.sum())
        durations[active] += 1
        active &= (values > -2) & (values < 3)
        paths.append(values[:12].copy())
    probability = float(np.mean(values == 3))
    mean_duration = float(durations.mean())
    assert abs(probability - 0.4) < 0.008
    assert abs(mean_duration - 6) < 0.09
    assert abs(values.mean()) < 0.04
    steps, T = 4096, 2.0
    increments = rng.normal(scale=np.sqrt(T / steps), size=steps)
    path = np.r_[0.0, np.cumsum(increments)]
    integral = float(path[:-1] @ increments)
    quadratic_variation = float(increments @ increments)
    assert np.isclose(integral, (path[-1] ** 2 - quadratic_variation) / 2)
    report = dict(upper_probability=probability, exact_probability=0.4,
                  mean_steps=mean_duration, exact_mean_steps=6,
                  discrete_integral=integral, quadratic_variation=quadratic_variation,
                  continuous_target_T=T)
    (output / "guo-appendix-a-results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "svg.fonttype": "none", "figure.facecolor": "#f7f8f6"})
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6), gridspec_kw={"width_ratios": [2, 1]})
    series = np.asarray(paths)
    for i in range(series.shape[1]):
        axes[0].step(np.arange(min(28, len(series))), series[:28, i], where="post",
                     color=plt.cm.viridis(0.15 + i / 15), lw=1.1, alpha=0.7)
    for bound in [-2, 3]:
        axes[0].axhline(bound, color="#263747", ls=":", lw=1)
    axes[0].set(xlabel="Step", ylabel="Cumulative gain", ylim=(-2.6, 3.6))
    axes[1].bar([-2, 3], [1-probability, probability], width=1.3, color=["#67969a", "#bc965f"])
    axes[1].scatter([-2, 3], [0.6, 0.4], color="#253743", s=28, zorder=3, label="Exact")
    axes[1].set(xlabel="Stopped gain", ylabel="Probability", xticks=[-2, 3], ylim=(0, 0.75))
    axes[1].legend(frameon=False)
    for ax in axes:
        ax.set_facecolor("#f7f8f6")
        ax.grid(axis="y", alpha=0.14)
    fig.tight_layout()
    fig.savefig(output / "guo-appendix-a.svg", bbox_inches="tight")
    plt.close(fig)
    print(json.dumps(report))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("outputs"))
    main(parser.parse_args().output)
