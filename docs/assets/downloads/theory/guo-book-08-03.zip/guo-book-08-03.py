from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--output',default='outputs');args=p.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True)

import struct
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

class Order:
    def __init__(self,quantity):self.quantity=quantity;self.filled=0;self.cancelled=0;self.executions=set();self.state='accepted'
    def fill(self,execution_id,quantity):
        if execution_id in self.executions:return
        if quantity<=0 or self.filled+self.cancelled+quantity>self.quantity:raise ValueError('Invalid fill')
        self.executions.add(execution_id);self.filled+=quantity
        self.state='filled' if self.filled==self.quantity else ('cancel_pending' if self.state=='cancel_pending' else 'partially_filled')
    def cancel_request(self):self.state='cancel_pending'
    def cancel_ack(self):self.cancelled=self.quantity-self.filled;self.state='cancelled' if self.cancelled else 'filled'

o=Order(100);o.fill('a',40);o.cancel_request();o.fill('b',20);o.fill('b',20);o.cancel_ack()
assert (o.filled,o.cancelled)==(60,40)
values=[6.6784e-11,6.626069e-34,1.602176565e-19]
floats=[]
for x in values:
    b=struct.pack('>f',x);value=struct.unpack('>f',b)[0];bits=int.from_bytes(b,'big');exponent=(bits>>23)&255
    assert 1<=exponent<=254
    floats.append({'input':x,'float32':value,'bits':f'{bits:032b}','relative_error':abs(value-x)/abs(x)})
latency=np.concatenate([np.full(9900,5.),np.full(100,100.)])
assert abs(latency.mean()-5.95)<1e-12
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(8,3.2));x,counts=np.unique(latency,return_counts=True);survival=1-np.cumsum(counts)/len(latency)
ax.step(np.r_[0,x],np.r_[1,survival],where='post',color='#297d80',lw=2);ax.set_yscale('log');ax.set_ylim(.001,1.3);ax.set_xlabel('Latency (microseconds)');ax.set_ylabel('Fraction exceeding latency');ax.grid(alpha=.16);fig.tight_layout();fig.savefig(out/'guo-system-latency.svg');plt.close(fig)
cpp=r'''
#include <chrono>
#include <cstdint>
#include <iostream>
#include <vector>
#include <stdexcept>
volatile std::uint64_t sink = 0;
int main(){
    const std::size_t rows=1000, cols=5000;
    std::vector<std::uint32_t> data(rows*cols,1);
    std::vector<std::uint64_t> sweep(32*1024*1024,1);
    for(int trial=0;trial<6;++trial){
        for(bool row_first : {true,false}){
            std::uint64_t sweep_sum=0;
            for(auto v:sweep)sweep_sum+=v;
            sink=sweep_sum; // pressure the cache; not a guarantee of a fully cold cache
            auto begin=std::chrono::steady_clock::now();std::uint64_t sum=0;
            if(row_first){for(std::size_t i=0;i<rows;++i)for(std::size_t j=0;j<cols;++j)sum+=data[i*cols+j];}
            else {for(std::size_t j=0;j<cols;++j)for(std::size_t i=0;i<rows;++i)sum+=data[i*cols+j];}
            auto end=std::chrono::steady_clock::now();sink=sum;
            if(sum!=rows*cols)throw std::runtime_error("sum mismatch");
            std::cout<<trial<<","<<(row_first?"row":"column")<<","<<std::chrono::duration<double,std::milli>(end-begin).count()<<"\n";
        }
    }
}
'''
(out/'matrix_benchmark.cpp').write_text(cpp,'utf-8')
(out/'matrix_benchmark_README.txt').write_text('Compile: g++ -O2 -std=c++17 matrix_benchmark.cpp -o matrix_benchmark\nRun the executable. Output: trial, access order, milliseconds.\nA large buffer sweep creates cache pressure, but does not prove every cache was invalidated.\n','utf-8')
result={'filled':o.filled,'cancelled':o.cancelled,'float32':floats,'latency_mean_us':float(latency.mean()),'latency_p999_us':float(np.quantile(latency,.999))}
(out/'system-implementation.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
