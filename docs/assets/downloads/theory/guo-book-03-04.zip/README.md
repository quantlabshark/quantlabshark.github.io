# 长期增长、再平衡与通用组合

Python 3.10 或更高版本。

安装依赖：

    python -m pip install numpy matplotlib

运行：

    python guo-book-03-04.py

示例使用模拟数据或题面给出的数据。参数和单位见脚本注释。
