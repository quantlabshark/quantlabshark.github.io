from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(304);R=np.exp(rng.normal([.0004,.0002],[.015,.010],size=(250,2)))
grid=np.linspace(0,1,101);wealth=np.ones(len(grid));mix=[1.];bestpaths=[]
for row in R:
    w=np.dot(grid,wealth)/wealth.sum();mix.append(mix[-1]*(w*row[0]+(1-w)*row[1]));wealth*=grid*row[0]+(1-grid)*row[1];bestpaths.append(wealth.copy())
paths=np.array(bestpaths);j=wealth.argmax()
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(mix,label='通用组合');ax.plot(np.r_[1,paths[:,j]],label='事后最佳固定比例');ax.set(xlabel='期数',ylabel='财富倍数');ax.legend(frameon=False);save(fig,'universal-portfolio.svg')
assert np.isclose(mix[-1],wealth.mean())
print('Kelly比例',2*.6-1,'合并权重',(120*.2+80*.8)/200)
