"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

n=500000
# Exact joint Gaussian sampling: Cov(W1,J)=1/2, Var(J)=1/3.
z=rng.normal(size=(2,n));w=z[0];j=.5*w+np.sqrt(1/12)*z[1];i=.5*(w*w-1)
mixed=float(np.mean(i*j*j));cov=float(np.mean(i*j))
assert abs(cov)<.01 and abs(mixed-.25)<.012
report(covariance_I_J=cov,mixed_moment_I_J_squared=mixed,theoretical_mixed_moment=.25,conclusion="uncorrelated but dependent")
