from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(407);n=16000;t=np.arange(n)/n;v=.0004*(1+.6*np.cos(2*np.pi*t));r=np.sqrt(v/n)*rng.normal(size=n)
N=100;k=np.arange(-N,N+1);c=np.exp(-2j*np.pi*k[:,None]*t)@r/(2*np.pi);iv=(2*np.pi)**2*np.mean(np.abs(c)**2)
local=n*r*r;ft=np.fft.rfft(local);freq=np.arange(len(ft));M=12;weights=np.maximum(0,1-freq/M);smooth=np.fft.irfft(ft*weights,n)
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(t,v,label='生成瞬时方差');ax.plot(t,smooth,label='局部平方的频率平滑');ax.set(xlabel='交易时段比例',ylabel='方差率');ax.legend(frameon=False);save(fig,'fourier-spot.svg')
assert np.isclose((2*np.pi)**2*np.mean(np.abs(3*c)**2),9*iv)
print('谱积分方差',iv,'生成积分方差',v.mean())
