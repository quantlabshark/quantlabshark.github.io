from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
x=np.linspace(.2,10,160);y=np.linspace(.2,10,160);X,Y=np.meshgrid(x,y);P=2/np.pi*np.arctan(X/Y)
fig,ax=plt.subplots(figsize=(6.5,4));im=ax.imshow(P,cmap='viridis',vmin=0,vmax=1,origin='lower',extent=[x[0],x[-1],y[0],y[-1]],aspect='auto',interpolation='bilinear');fig.colorbar(im,ax=ax,label='向上概率');ax.set(xlabel='买侧队列',ylabel='卖侧队列');save(fig,'queue-up-probability.svg')
assert np.isclose(2/np.pi*np.arctan(1),.5)
assert np.isclose(1+2*.5/(1-.5),3)
print('双倍买侧深度的近似向上概率',2/np.pi*np.arctan(2),'平均耗尽时间',20/(6-4))
