# -*- coding: utf-8 -*-
import numpy as np
from itertools import product
levels=np.array(list(product([-1,1],repeat=3)))
a,b,c=levels.T
design=np.column_stack([np.ones(8),a,b,c,a*b,a*c,b*c,a*b*c])
assert np.allclose(design.T@design,8*np.eye(8))
y=10+2*a-b+3*a*b
coef=design.T@y/8
print('coefficients',coef,'effects',2*coef[1:])

levels2=np.array([[-1,-1],[1,-1],[-1,1],[1,1]])
a,b=levels2.T
design2=np.column_stack([np.ones(4),a,b,a*b])
y2=np.array([2.,6.,4.,12.]);coef2=design2.T@y2/4
assert np.allclose(coef2,[6,3,2,1])
print('two-factor coefficients',coef2,'effects',2*coef2[1:])

cell_means=10+2*levels[:,0]-levels[:,1]+3*levels[:,0]*levels[:,1]
observations=cell_means[:,None]+np.array([-1.,1.])
sse=((observations-cell_means[:,None])**2).sum()
ss_effects=16*coef[1:]**2
total=((observations-observations.mean())**2).sum()
assert np.isclose(total,240) and np.isclose(sse+ss_effects.sum(),total)
print('three-factor SS',ss_effects,'SSE',sse,'F',ss_effects/(sse/8))
