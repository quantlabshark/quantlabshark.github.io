# -*- coding: utf-8 -*-
from scipy.stats import binom
n=10;p0=.5
print('one-sided P(X>=8)',binom.sf(7,n,p0))
print('size for reject X>=9',binom.sf(8,n,p0))

from scipy.stats import binomtest,norm
z=(.6-.5)/(.25/100)**.5
print('proportion test: z',z,'normal p',2*norm.sf(abs(z)),'exact p',binomtest(60,100,.5).pvalue)
