# -*- coding: utf-8 -*-
prior=[.6,.4];defect=[.05,.1]
joint=[p*q for p,q in zip(prior,defect)]
total=sum(joint)
posterior=[p/total for p in joint]
assert abs(sum(posterior)-1)<1e-12
print('defect probability',total,'posterior',posterior)
