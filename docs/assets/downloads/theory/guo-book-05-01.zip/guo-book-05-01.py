from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
bidp=np.array([99.99,99.98,99.97]);bidq=np.array([80,120,200]);askp=np.array([100.01,100.02,100.03]);askq=np.array([100,200,260])
def vwap(p,q,size):
    remain=size;cash=0
    for price,qty in zip(p,q):
        use=min(remain,qty);cash+=price*use;remain-=use
        if not remain:return cash/size
    raise ValueError('可见深度不足')
buy=vwap(askp,askq,150);sell=vwap(bidp,bidq,150)
fig,ax=plt.subplots(figsize=(7,3.6));ax.bar(bidp,bidq,width=.007,color='#438f99',label='买侧');ax.bar(askp,askq,width=.007,color='#bd7560',label='卖侧');ax.set(xlabel='价格',ylabel='可见数量');ax.legend(frameon=False);save(fig,'lob-depth.svg')
assert np.isclose(buy-sell,.028)
print('买入均价',buy,'卖出均价',sell,'价差',buy-sell)
