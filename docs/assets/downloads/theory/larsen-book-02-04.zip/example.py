# -*- coding: utf-8 -*-
from math import comb, factorial, perm
print('two ordered roles',perm(5,2),'two members',comb(5,2))
print('AABC arrangements',factorial(4)//factorial(2))
print('named groups 3,3,2',factorial(8)//(factorial(3)**2*factorial(2)))
print('unnamed equal-sized groups',factorial(8)//(factorial(3)**2*factorial(2)*factorial(2)))
assert perm(5,2)==comb(5,2)*factorial(2)
