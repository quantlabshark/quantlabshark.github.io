"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-08-04'

k=2.;sigma=.3;x0=1.;t=np.linspace(0,3,601);h=t[1];m=12000;x=np.full(m,x0);paths=[x[:12].copy()];means=[x.mean()];vars_=[x.var()]
decay=np.exp(-k*h);sd=sigma*np.sqrt((1-decay**2)/(2*k))
for _ in t[1:]:x=decay*x+sd*rng.normal(size=m);paths.append(x[:12].copy());means.append(x.mean());vars_.append(x.var())
truth=sigma**2*(1-np.exp(-2*k*t))/(2*k)
check('OU mean',x.mean(),np.exp(-6),.006);check('OU variance',x.var(),truth[-1],.001)
check('normal threshold probability',norm.cdf((.5-np.exp(-6))/np.sqrt(truth[-1])),.9995447562952463)
fig,axs=plt.subplots(1,2,figsize=(10,3.7));axs[0].plot(t,paths,alpha=.3,lw=.7);axs[0].plot(t,np.exp(-k*t),color='#203a40',lw=2,label='Mean');axs[0].set(xlabel='Time',ylabel='State');axs[0].legend();axs[1].plot(t,truth,label='Theory');axs[1].plot(t,vars_,alpha=.65,label='Simulation');axs[1].axhline(sigma**2/(2*k),linestyle=':',color='#6a75ad',label='Stationary variance');axs[1].set(xlabel='Time',ylabel='Variance');axs[1].legend();finish(fig)
