# -*- coding: utf-8 -*-
import numpy as np
means=np.array([[2.,4.],[6.,12.]])
interaction=means-means.mean(axis=1,keepdims=True)-means.mean(axis=0,keepdims=True)+means.mean()
print('B effect at each A',np.diff(means,axis=1).ravel())
print('interaction residuals',interaction)
