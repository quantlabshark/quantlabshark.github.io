"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

lam=2.;T=1.;x=.25;terms=[]
for k in range(80):
 logterm=k*np.log(lam*np.sqrt(np.pi*x)/2)-special.gammaln(k+1)-special.gammaln(k/2+1)
 terms.append(np.exp(logterm))
cdf=np.exp(-lam*T)*sum(terms)
reps=400000;counts=rng.poisson(lam*T,size=reps);idx=np.repeat(np.arange(reps),counts)
u=rng.uniform(0,T,size=len(idx));values=np.bincount(idx,weights=u*u,minlength=reps)
mc=float(np.mean(values<=x));se=np.sqrt(cdf*(1-cdf)/reps)
assert abs(mc-cdf)<5*se
assert abs(values.mean()-2/3)<.006 and abs(values.var()-.4)<.008
v0,k,rho=100,.2,5
vmean=v0*np.exp(-k*T)-lam*rho/k*(1-np.exp(-k*T))
vvar=lam*rho*rho/(2*k)*(1-np.exp(-2*k*T))
v=v0*np.exp(-k*T)-rho*np.exp(-k*T)*np.bincount(idx,weights=np.exp(k*u),minlength=reps)
assert abs(v.mean()-vmean)<.04 and abs(v.var()-vvar)<.3
fig,ax=plt.subplots(figsize=(8,4.2));positive=values[values>0]
ax.hist(positive,bins=np.linspace(0,3,65),weights=np.full(len(positive),1/reps/(3/64)),color=BLUE,alpha=.65)
ax.axvline(0,color=ORANGE,lw=2,label=f"Atom at zero: {np.exp(-2):.3f}")
ax.set(xlabel="Poisson integral",ylabel="Continuous density estimate");ax.legend(frameon=False);save(fig,"poisson-integral-distribution")
report(cdf_formula=float(cdf),cdf_simulation=mc,monte_carlo_standard_error=float(se),poisson_tail_error_bound=float(stats.poisson.sf(79,lam*T)),mean=float(values.mean()),variance=float(values.var()),payment_mean=float(vmean),payment_variance=float(vvar))
