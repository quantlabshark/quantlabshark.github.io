"""Reflection mapping and the heavy-traffic stationary limit of an M/M/1 queue."""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def reflect(net_input):
    regulator = np.maximum.accumulate(np.maximum(-net_input, 0))
    return net_input+regulator, regulator

def main(output):
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(20261018)
    time = np.linspace(0, 12, 1201);dt=time[1]-time[0]
    brownian = np.r_[0., np.cumsum(rng.normal(scale=np.sqrt(dt), size=len(time)-1))]
    net = 0.6-0.8*time+1.4*brownian
    queue, regulator = reflect(net)
    assert np.min(queue) >= -1e-12
    assert np.all(np.diff(regulator)>=-1e-12)
    increases = np.diff(regulator)>1e-12
    assert np.allclose(queue[1:][increases], 0)
    # A negative net-input episode shifts every subsequent value by its deficit.
    test, _ = reflect(np.array([1., -2., 1.]))
    assert np.allclose(test, [1., 0., 3.])
    rho=0.95; mean_queue=rho/(1-rho)
    assert np.isclose(mean_queue, 19)
    assert np.isclose((1-rho)*mean_queue, 0.95)
    x=np.linspace(0, 5, 500)
    epsilons=[0.2, 0.1, 0.05]
    cdfs=[1-(1-eps)**(np.floor(x/eps)+1) for eps in epsilons]
    limit=1-np.exp(-x)
    errors=[float(np.max(np.abs(cdf-limit))) for cdf in cdfs]
    assert errors[0]>errors[1]>errors[2]
    # Long-run variance for a stationary variance-one AR(1).
    phi=0.5
    long_run=1+2*sum(phi**k for k in range(1, 100))
    assert np.isclose(long_run, 3)
    report=dict(mean_queue=mean_queue, scaled_mean=(1-rho)*mean_queue,
                cdf_max_errors=errors, minimum_reflected_queue=float(queue.min()),
                ar1_long_run_variance=long_run)
    (output/"guo-appendix-d-results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    plt.rcParams.update({"font.size": 11,"axes.spines.top":False,"axes.spines.right":False,"svg.fonttype":"none"})
    fig, axes=plt.subplots(1, 2, figsize=(9, 3.7), facecolor="#f7f8f6")
    axes[0].plot(time,net,color="#b29d82",lw=1.2,label="Net input")
    axes[0].plot(time,queue,color="#347b7a",lw=1.6,label="Reflected queue")
    axes[0].axhline(0,color="#263747",lw=0.7)
    axes[0].set(xlabel="Time",ylabel="Level")
    for eps,cdf,color in zip(epsilons,cdfs,["#b29d82","#759998","#347b7a"]):
        axes[1].step(x,cdf,where="post",lw=1.2,color=color,label=rf"$\varepsilon={eps}$")
    axes[1].plot(x,limit,color="#263747",ls="--",lw=1.4,label="Exponential limit")
    axes[1].set(xlabel=r"$\varepsilon Q$",ylabel="Cumulative probability",ylim=(0,1.03))
    for ax in axes:
        ax.set_facecolor("#f7f8f6");ax.legend(frameon=False,fontsize=8);ax.grid(alpha=0.14)
    fig.tight_layout();fig.savefig(output/"guo-appendix-d.svg",bbox_inches="tight")
    plt.close(fig)
    print(json.dumps(report))

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=Path("outputs"))
    main(parser.parse_args().output)
