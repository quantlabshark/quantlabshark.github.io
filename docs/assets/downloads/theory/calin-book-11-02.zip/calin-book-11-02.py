"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-02'

n0=100;lam=.2;t=np.linspace(0,20,401);p=np.exp(-lam*t);fig,ax=plt.subplots(figsize=(7,3.7))
for _ in range(8):lifetimes=rng.exponential(1/lam,n0);ax.step(t,(lifetimes[:,None]>t).sum(0),where='post',alpha=.45,lw=.8)
ax.plot(t,n0*p,color='#203e43',lw=2,label='Mean');sd=np.sqrt(n0*p*(1-p));ax.fill_between(t,np.maximum(0,n0*p-1.96*sd),n0*p+1.96*sd,alpha=.12,label='Mean ± 1.96 SD')
check('mean half-death hitting time',sum(1/j for j in range(6,11)),.6456349206349206)
sample=rng.binomial(n0,.9,100000);check('binomial variance',sample.var(),9,.15)
ax.set(xlabel='Time',ylabel='Survivors');ax.legend();finish(fig)
