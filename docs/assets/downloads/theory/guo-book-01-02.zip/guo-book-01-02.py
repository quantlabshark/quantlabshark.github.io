from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
import matplotlib.pyplot as plt
rng=np.random.default_rng(41);n=180
benchmark=.004+rng.normal(0,.035,n)
active=.001+rng.normal(0,.008,n)
portfolio=benchmark+active
fig,axes=plt.subplots(2,1,figsize=(7.2,5.2),sharex=True)
axes[0].plot(np.cumprod(1+benchmark),label='基准',color='#8e9caa')
axes[0].plot(np.cumprod(1+portfolio),label='组合',color='#387ca3')
axes[0].set(ylabel='净值');axes[0].legend(frameon=False)
axes[1].plot(np.cumsum(active),color='#b98a49');axes[1].axhline(0,color='#adb5bd',lw=.6)
axes[1].set(xlabel='月份',ylabel='累计主动收益')
save(fig,'performance-paths.svg')
te=np.sqrt(.14**2+.12**2-2*.95*.14*.12)
assert np.isclose(te**2,.00208)
print('SR',(.09-.02)/.14,'跟踪误差',te,'IR',.02/te)
