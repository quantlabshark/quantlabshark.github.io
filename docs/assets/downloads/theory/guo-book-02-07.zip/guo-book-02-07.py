from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(207)
cov=np.array([[.0004,.00012],[.00012,.0001]])
z=rng.multivariate_normal([0,0],cov,3000);ind=z.copy();rng.shuffle(ind[:,1])
fig,axs=plt.subplots(1,2,figsize=(8,3.5),sharex=True,sharey=True)
for ax,data,label in zip(axs,[z,ind],['整组残差抽样','分别抽样']):
    ax.scatter(data[:,0]*100,data[:,1]*100,s=3,alpha=.17,label=label);ax.set_xlabel('资产一收益（%）');ax.legend(frameon=False)
axs[0].set_ylabel('资产二收益（%）');save(fig,'joint-residuals.svg')
a=np.array([.2,-.2]);te=np.sqrt(a@cov@a)
assert np.isclose(te**2,.0000104)
print('主动收益',a@np.array([.01,.004]),'跟踪误差',te)
