# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import f_oneway
groups=[np.array([1.,2.,3.]),np.array([2.,3.,4.]),np.array([4.,5.,6.])]
all_data=np.concatenate(groups);grand=all_data.mean()
between=sum(len(g)*(g.mean()-grand)**2 for g in groups)
within=sum(((g-g.mean())**2).sum() for g in groups)
assert np.isclose(between+within,((all_data-grand)**2).sum())
print('SS between and within',between,within,f_oneway(*groups))
