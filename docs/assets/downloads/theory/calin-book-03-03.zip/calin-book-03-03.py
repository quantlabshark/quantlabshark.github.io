"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

T=3;n=900;t=np.linspace(0,T,n+1);h=T/n
w=np.r_[0,np.cumsum(rng.normal(scale=np.sqrt(h),size=n))]
z=np.r_[0,np.cumsum((w[:-1]+w[1:])*h/2)]
fig,axs=plt.subplots(2,1,figsize=(8,5),sharex=True)
axs[0].plot(t,w,color=BLUE);axs[0].fill_between(t,0,w,color=BLUE,alpha=.12);axs[0].set(ylabel="Brownian value")
axs[1].plot(t,z,color=GREEN);axs[1].set(xlabel="Time",ylabel="Accumulated area")
save(fig,"integrated-brownian")
s,t1=1,2;cov=s*s*t1/2-s**3/6
vcov=np.exp((s**3+t1**3)/6)*np.expm1(cov)
assert np.isclose(integrate.quad(lambda u:integrate.quad(lambda v:min(u,v),0,t1)[0],0,s)[0],cov)
report(integrated_covariance=float(cov),exponential_covariance=float(vcov),conditional_exp_mean=float(np.exp(.2+.5+1/6)))
