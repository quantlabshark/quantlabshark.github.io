"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-03'

omega=1.;sigma=.2;h=.02;n=900;m=10000;th=np.zeros(m);v=np.zeros(m);co=np.cos(h);si=np.sin(h)
vth=sigma*sigma*(h/2-np.sin(2*h)/4);vv=sigma*sigma*(h/2+np.sin(2*h)/4);cov=sigma*sigma*np.sin(h)**2/2;L=np.linalg.cholesky([[vth,cov],[cov,vv]]);paths=[];energy=[]
for _ in range(n):
    noise=rng.normal(size=(m,2))@L.T;th,v=co*th+si*v+noise[:,0],-si*th+co*v+noise[:,1];paths.append((th[0],v[0]));energy.append(np.mean((th*th+v*v)/2))
T=n*h;check('mean energy',energy[-1],sigma*sigma*T/2,.015)
fig,axs=plt.subplots(1,2,figsize=(9,3.8));paths=np.array(paths);axs[0].plot(paths[:,0],paths[:,1],lw=.8);axs[0].set(xlabel='Angle',ylabel='Angular velocity');t=np.arange(1,n+1)*h;axs[1].plot(t,energy,label='Simulation');axs[1].plot(t,sigma*sigma*t/2,'--',label='Theory');axs[1].set(xlabel='Time',ylabel='Mean energy');axs[1].legend();finish(fig)
