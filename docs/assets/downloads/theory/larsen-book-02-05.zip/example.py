# -*- coding: utf-8 -*-
from math import comb
p=comb(5,2)*comb(3,1)/comb(8,3)
print('two successes without replacement',p)
print('birthday collision, 23 people',1-__import__('math').prod((365-i)/365 for i in range(23)))
