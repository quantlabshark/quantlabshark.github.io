"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

T=8;n=800;h=T/n;t=np.linspace(0,T,n+1);a=.5;m=10;sigma=1
x=np.empty((14,n+1));x[:,0]=14
decay=np.exp(-a*h);sd=sigma*np.sqrt((1-decay**2)/(2*a))
for i in range(n):x[:,i+1]=m+(x[:,i]-m)*decay+sd*rng.normal(size=len(x))
fig,ax=plt.subplots(figsize=(8,4.2))
for path in x:ax.plot(t,path,color=BLUE,alpha=.25,lw=.9)
ax.plot(t,m+4*np.exp(-a*t),color=GREEN,lw=2,label="Conditional mean")
ax.axhline(m,color="#94a3b8",ls="--",lw=1)
ax.set(xlabel="Time",ylabel="State");ax.legend(frameon=False);save(fig,"mean-reversion")
assert np.isclose(sd**2,(1-np.exp(-h)))
report(mean_t2=float(m+4*np.exp(-1)),half_life=float(np.log(2)/a))
