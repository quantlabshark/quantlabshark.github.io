# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import poisson,chi2
from scipy.optimize import minimize_scalar
observed=np.array([36,38,18,8]);n=observed.sum()
def probabilities(rate):
    return np.r_[poisson.pmf([0,1,2],rate),poisson.sf(2,rate)]
def nll(rate):
    return -observed@np.log(probabilities(rate))
fit=minimize_scalar(nll,bounds=(.01,10),method='bounded',options={'xatol':1e-12})
assert fit.success
expected=n*probabilities(fit.x)
stat=((observed-expected)**2/expected).sum()
print('grouped likelihood rate',fit.x,'expected',expected)
print('Pearson statistic',stat,'df',2,'p',chi2.sf(stat,2))
