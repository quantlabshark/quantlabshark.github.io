# -*- coding: utf-8 -*-
from scipy.stats import kruskal,friedmanchisquare
result=kruskal([1,2],[3,4],[5,6])
assert abs(result.statistic-32/7)<1e-12
print(result)
print('within-block ranks',friedmanchisquare([1,4,2,3],[2,5,3,5],[3,6,4,4]))
