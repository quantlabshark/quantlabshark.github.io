from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--output',default='outputs');args=p.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True)

def route_buy(offers,quantity):
    left=quantity;fills=[]
    for venue,price_ticks,size in sorted(offers,key=lambda x:x[1]):
        q=min(size,left)
        if q:fills.append((venue,price_ticks,q));left-=q
        if not left:break
    return fills,left

fills,left=route_buy([('A',5002,300),('B',5001,100),('C',5001,50)],250)
assert left==0 and sum(x[2] for x in fills)==250
average=sum(price*q for _,price,q in fills)/250/100
assert abs(average-50.014)<1e-12
best_bid=max([2498,2499,2497]);best_ask=min([2502,2501,2503])
assert (best_bid,best_ask,best_ask-best_bid)==(2499,2501,2)
# A teaching check after the relevant price restriction has already been activated.
def passes_short_price_test(price,best_bid,active=True,exempt=False):return not active or exempt or price>best_bid
assert not passes_short_price_test(8999,8999)
assert passes_short_price_test(9000,8999)
result={'routing':fills,'average_price':average,'nbbo':[best_bid/100,best_ask/100]}
(out/'market-mechanisms.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
