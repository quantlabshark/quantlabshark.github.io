from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(303);rets=rng.normal(.0002,.015,180);w=.5;path=[];turns=[]
for i,r in enumerate(rets):
    w=w*(1+r)/(1+w*r)
    if w>.55:w=.55;turns.append(i)
    if w<.45:w=.45;turns.append(i)
    path.append(w)
fig,ax=plt.subplots(figsize=(7,3.6));ax.axhspan(.45,.55,color='#438f99',alpha=.14);ax.plot(path,color='#257b88');ax.axhline(.5,color='gray',ls='--');ax.set(xlabel='交易日',ylabel='股票财富比例',ylim=(.42,.58));save(fig,'no-trade-band.svg')
assert np.isclose((.08-.02)/(3*.2**2),.5)
print('Merton比例',.5,'恢复目标所需卖出',2.5)
