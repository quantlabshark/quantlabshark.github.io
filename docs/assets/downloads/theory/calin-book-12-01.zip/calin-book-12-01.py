"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-12-01'

T=2.;n=1000;m=20000;h=T/n;w=np.zeros(m);area=np.zeros(m);q=np.zeros(m)
for _ in range(n):
    dw=rng.normal(size=m)*np.sqrt(h);area+=w*h;q+=dw*dw;w+=dw
res=area-T*w/2
check('conditional residual variance',res.var(),T**3/12,.025);check('quadratic variation variance',q.var(),2*T*T/n,.0004)
fig,ax=plt.subplots(figsize=(6.5,4));ax.scatter(w[:2000],area[:2000],s=5,alpha=.2);u=np.linspace(-5,5,100);ax.plot(u,T*u/2,color='#d99a39',label='Conditional mean');ax.set(xlabel='Terminal Brownian value',ylabel='Integrated Brownian value');ax.legend();finish(fig)
