# -*- coding: utf-8 -*-
import random
names=list(range(12));random.Random(12).shuffle(names)
print('randomized treatment A',names[:6],'B',names[6:])
blocks=[list(range(i,i+4)) for i in (0,4,8)]
rng=random.Random(12)
for block in blocks:
    rng.shuffle(block);print('within block A',block[:2],'B',block[2:])
