# -*- coding: utf-8 -*-
def mean(values):
    if not values:
        raise ValueError('values must not be empty')
    return sum(values)/len(values)

print(mean([2,4,6]))
assert mean([2,4,6])==4
try:
    mean([])
except ValueError:
    print('empty input rejected')
else:
    raise AssertionError('missing validation')

def newton_sqrt(value,tol=1e-12,max_steps=1000):
    if value<0:raise ValueError('negative real argument')
    if value==0:return 0.
    x=max(1.,value/2)
    for _ in range(max_steps):
        following=(x+value/x)/2
        if abs(following-x)<=tol*max(1.,abs(following)):return following
        x=following
    raise ArithmeticError('iteration did not converge')
from math import isclose,sqrt
for value in [0,2,100,1e-8]:assert isclose(newton_sqrt(value),sqrt(value),rel_tol=1e-10,abs_tol=1e-12)
print('sqrt(2)',newton_sqrt(2))
