"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

T=15;n=1200;t=np.linspace(0,T,n+1);h=T/n
w=np.c_[np.zeros(35),np.cumsum(rng.normal(scale=np.sqrt(h),size=(35,n)),axis=1)]
l=np.exp(w-t/2)
fig,ax=plt.subplots(figsize=(8,4.2))
for p in l:ax.plot(t,p,color=BLUE,alpha=.25,lw=.8)
ax.plot(t,np.exp(-t/2),color=GREEN,lw=2,label="Median")
ax.axhline(1,color=ORANGE,ls="--",label="Theoretical mean")
ax.set(xlabel="Time",ylabel="Exponential martingale",yscale="log",ylim=(1e-7,100));ax.legend(frameon=False)
save(fig,"exponential-martingale")
report(theoretical_mean=1,second_moment_T=float(np.exp(T)),almost_sure_limit=0)
