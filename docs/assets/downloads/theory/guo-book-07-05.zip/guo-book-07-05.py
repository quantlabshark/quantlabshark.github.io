from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
def km(n,r,limit):
    s=[1.];risk=[]
    for j in range(limit):
        valid=(n>j)&(r>=j);N=valid.sum();D=((n>j)&(r==j)).sum();risk.append(int(N))
        if N==0:break
        s.append(s[-1]*(1-D/N))
    return np.array(s),risk
n=np.array([2,4,3,5]);r=np.array([1,4,2,3]);s,risk=km(n,r,8);assert np.allclose(s,[1,1,.75,.5,.25]);print('四样本尾概率',s,'风险集',risk)
rng=np.random.default_rng(715);count=30000;u=np.where(rng.random(count)<.25,0,rng.geometric(.12,count));n=rng.integers(2,18,count);r=np.minimum(n,u);s,_=km(n,r,17);j=np.arange(len(s));true=np.r_[1.,.75*.88**np.arange(len(s)-1)]
fig,ax=plt.subplots(figsize=(7,3.7));ax.step(j,s,where='post',label='删失估计');ax.plot(j,true,'--',label='生成分布');ax.plot(j,[np.mean(r>=z) for z in j],':',label='直接使用成交量');ax.set(xlabel='容量门槛（股）',ylabel='达到门槛的概率',ylim=(0,1.04));ax.legend(frameon=False);save(fig,'censored-capacity-km.svg')
assert np.max(np.abs(s-true))<.025
