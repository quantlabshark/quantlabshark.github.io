"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

lam,T,theta=2,2,.7;n=200000;counts=rng.poisson(lam*T,size=n)
idx=np.repeat(np.arange(n),counts);weights=T-rng.uniform(0,T,size=len(idx))
area=np.bincount(idx,weights=weights,minlength=n)
lt=np.exp(lam*((1-np.exp(-theta*T))/theta-T))
assert abs(area.mean()-lam*T*T/2)<.04
assert abs(area.var()-lam*T**3/3)<.12
assert abs(np.exp(-theta*area).mean()-lt)<.003
report(mean=float(area.mean()),variance=float(area.var()),laplace_simulation=float(np.exp(-theta*area).mean()),laplace_formula=float(lt))
