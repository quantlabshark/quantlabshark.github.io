"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-04'

r=.3;beta=1.;p0=1.;t=np.linspace(0,8,801);h=t[1];w=np.column_stack([np.zeros(20),np.cumsum(rng.normal(size=(20,800))*np.sqrt(h),axis=1)]);g=np.exp((r-beta*beta/2)*t+beta*w);integ=np.column_stack([np.zeros(20),np.cumsum((g[:,1:]+g[:,:-1])*h/2,axis=1)]);logistic=p0*g/(1+.4*p0*integ)
check('catastrophe mean growth',.3-2*.2,-.1);check('catastrophe log growth',.3+2*np.log(.8),-.1462871026284194)
fig,axs=plt.subplots(1,2,figsize=(10,3.7));axs[0].plot(t,g.T,lw=.7,alpha=.35);axs[0].plot(t,np.exp(r*t),'k--',label='Mean');axs[0].set(xlabel='Time',ylabel='Unrestricted population',yscale='log');axs[0].legend();axs[1].plot(t,logistic.T,lw=.8,alpha=.55);axs[1].set(xlabel='Time',ylabel='Logistic population');finish(fig)
