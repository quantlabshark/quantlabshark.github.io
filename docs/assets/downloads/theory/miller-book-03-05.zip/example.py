# -*- coding: utf-8 -*-
class Node:
    def __init__(self,value,next=None):self.value,self.next=value,next
def insert(head,value):
    previous=None;current=head
    while current is not None and current.value<value:
        previous,current=current,current.next
    node=Node(value,current)
    if previous is None:return node
    previous.next=node
    return head
def values(head):
    out=[]
    while head is not None:
        out.append(head.value);head=head.next
    return out
head=None
for x in [4,1,7,5]:head=insert(head,x)
assert values(head)==[1,4,5,7]
print(values(head))

def remove(head,value):
    previous=None;current=head
    while current is not None and current.value!=value:
        previous,current=current,current.next
    if current is None:raise KeyError(value)
    if previous is None:return current.next
    previous.next=current.next
    return head
for key in (1,5,7,4):head=remove(head,key)
assert head is None
print('head, middle, tail and final-node deletion checked')
