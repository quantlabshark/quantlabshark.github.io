from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--output',default='outputs');args=p.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def exposure(position,buy_remaining,sell_remaining):
    if buy_remaining<0 or sell_remaining<0:raise ValueError('Negative outstanding quantity')
    return position-sell_remaining,position+buy_remaining

def decode(message):
    if not message:raise ValueError('Empty message')
    kind=message[:1]
    expected={b'A':36,b'E':31}
    if kind not in expected or len(message)!=expected[kind]:raise ValueError('Invalid type or length')
    u=lambda a,b:int.from_bytes(message[a:b],'big')
    result={'type':kind.decode(),'order_id':u(11,19),'timestamp':u(5,11)}
    if kind==b'A':
        side=message[19:20]
        if side not in (b'B',b'S'):raise ValueError('Invalid side')
        result.update(side=side.decode(),shares=u(20,24),symbol=message[24:32].decode('ascii').rstrip(),price_integer=u(32,36))
    else:result.update(shares=u(19,23),match_id=u(23,31))
    if result['shares']<=0:raise ValueError('Nonpositive quantity')
    return result

header=lambda kind:kind+(12345).to_bytes(2,'big')+(12233).to_bytes(2,'big')+(1222444555).to_bytes(6,'big')+(3321123456).to_bytes(8,'big')
add=header(b'A')+b'B'+(500).to_bytes(4,'big')+b'TEST    '+(1145000).to_bytes(4,'big')
execution=header(b'E')+(200).to_bytes(4,'big')+(123456).to_bytes(8,'big')
a=decode(add);e=decode(execution)
assert a['shares']==500 and a['price_integer']==1145000 and a['order_id']==e['order_id']
assert a['shares']-e['shares']==300
def remaining_after_fill(order,event):
    if event['order_id']!=order['order_id'] or event['shares']>order['shares']:raise ValueError('Order or quantity mismatch')
    return order['shares']-event['shares']
assert remaining_after_fill(a,e)==300
try:remaining_after_fill(a,{**e,'shares':501})
except ValueError:pass
else:raise AssertionError('Overfill accepted')
for bad in [add[:-1],b'X'+add[1:],b'']:
    try:decode(bad)
    except ValueError:pass
    else:raise AssertionError('Invalid message accepted')
assert exposure(20,80,70)==(-50,100)
assert exposure(-30,120,40)==(-70,90)
assert exposure(-30,140,40)[1]>100
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(8,3.2));cases=[(20,80,70),(-30,120,40),(-30,140,40)]
for i,(q,b,s) in enumerate(cases):
    lo,hi=exposure(q,b,s);ax.plot([lo,hi],[i,i],lw=8,color='#297d80' if hi<=100 else '#c48657',solid_capstyle='round');ax.scatter([q],[i],s=50,c='white',edgecolors='#263d48',zorder=3)
ax.axvline(-100,c='#9ca8ad',ls='--');ax.axvline(100,c='#9ca8ad',ls='--');ax.set_yticks(range(3),['Position 20','Position -30','Add 20 buy']);ax.set_xlabel('Potential position (shares)');ax.set_ylim(-.5,2.5);ax.grid(axis='x',alpha=.15);fig.tight_layout();fig.savefig(out/'guo-system-exposure.svg');plt.close(fig)
result={'add_message':a,'execution_message':e,'remaining':300,'potential_interval':exposure(-30,120,40),'stress_loss':100*(5+.2)}
(out/'system-risk.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
