# 操作风险、策略风险与压力测试

Python 3.10 或更高版本。

安装依赖：

    python -m pip install matplotlib

运行：

    python guo-book-08-05.py

示例使用模拟数据或题面给出的数据。参数和单位见脚本注释。
