# 两个独立总体的均值比较

需要 Python 3.10 或更新版本。

在解压目录打开终端：

~~~text
python -m pip install -r requirements.txt
~~~

~~~text
python example.py
~~~

程序重现教学示例。检查输出与 expected-output.txt；数值库版本变化可能影响末尾小数。
