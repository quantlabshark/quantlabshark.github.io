# -*- coding: utf-8 -*-
from scipy.stats import t
n1=n2=5;mean1=12.;mean2=9.;v1=4.;v2=9.
pooled=((n1-1)*v1+(n2-1)*v2)/(n1+n2-2)
se=(v1/n1+v2/n2)**.5
df=(v1/n1+v2/n2)**2/((v1/n1)**2/(n1-1)+(v2/n2)**2/(n2-1))
stat=(mean1-mean2)/se
for label,nu in [('pooled',n1+n2-2),('Welch',df)]:
    half=t.ppf(.975,nu)*se
    print(label,'df',nu,'t',stat,'p',2*t.sf(abs(stat),nu),'CI',(3-half,3+half))
