# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import ttest_ind
a=np.array([8.,9.,10.,11.,12.]);b=np.array([7.,8.,10.,13.,17.])
print('pooled',ttest_ind(a,b,equal_var=True))
print('Welch',ttest_ind(a,b,equal_var=False))
