from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(402);n=6000;K=100;values=[]
for _ in range(160):
    x=np.r_[0,np.cumsum(rng.normal(0,.01/np.sqrt(n),n))];y=x+rng.normal(0,.0002,n+1);allrv=np.diff(y)@np.diff(y)
    seq=[y[k::K] for k in range(K)];avg=np.mean([np.sum(np.diff(a)**2) for a in seq]);ratio=np.mean([len(a)-1 for a in seq])/n
    values.append([allrv,avg,(avg-ratio*allrv)/(1-ratio)])
fig,ax=plt.subplots(figsize=(7,3.6));ax.boxplot(np.array(values),tick_labels=['原始方差','子样本平均','双尺度']);ax.axhline(.0001,color='#b05b52',ls='--');ax.set_ylabel('积分方差估计');save(fig,'two-scale-estimates.svg')
assert np.isclose((.00014-.1*.0005)/.9,.0001)
print('各估计均值',np.mean(values,axis=0))
