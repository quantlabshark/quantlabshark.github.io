from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
import matplotlib.pyplot as plt
error=np.linspace(.005,.06,200);precision=1/.02**2+1/error**2
mean=(.05/.02**2+.08/error**2)/precision;sd=1/np.sqrt(precision)
fig,ax=plt.subplots(figsize=(7.2,3.8))
ax.plot(error,mean,color='#387ca3',label='后验均值');ax.fill_between(error,mean-1.96*sd,mean+1.96*sd,color='#387ca3',alpha=.13)
ax.axhline(.05,color='#8e9caa',ls='--',label='先验均值');ax.axhline(.08,color='#b98a49',ls=':',label='观点')
ax.set(xlabel='观点误差标准差',ylabel='收益均值');ax.legend(frameon=False)
save(fig,'view-precision.svg')
for e,expected in [(.01,.074),(.04,.056)]:
    v=1/(1/.02**2+1/e**2);m=v*(.05/.02**2+.08/e**2)
    assert np.isclose(m,expected);print('观点误差',e,'后验均值',m,'后验标准差',np.sqrt(v))
