# -*- coding: utf-8 -*-
from collections import deque
def topological(graph):
    vertices=set(graph)
    for neighbors in graph.values():vertices.update(neighbors)
    degree={v:0 for v in vertices}
    for neighbors in graph.values():
        for v in neighbors:degree[v]+=1
    q=deque(sorted(v for v in vertices if degree[v]==0));out=[]
    while q:
        u=q.popleft();out.append(u)
        for v in graph.get(u,[]):
            degree[v]-=1
            if degree[v]==0:q.append(v)
    if len(out)!=len(vertices):raise ValueError('directed cycle')
    return out
graph={'A':['C'],'B':['C'],'C':['D'],'D':[]}
order=topological(graph);position={v:i for i,v in enumerate(order)}
assert all(position[u]<position[v] for u,vs in graph.items() for v in vs)
print(order)
