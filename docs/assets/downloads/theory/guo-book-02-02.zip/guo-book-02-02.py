from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
import matplotlib.pyplot as plt
w=np.linspace(0,1,301);mu=.05+.03*w
fig,ax=plt.subplots(figsize=(7.2,3.8))
for rho,color in [(-.5,'#4f9a89'),(0,'#387ca3'),(.8,'#b98a49')]:
    var=.04*w*w+.01*(1-w)**2+2*.2*.1*rho*w*(1-w)
    ax.plot(np.sqrt(var),mu,label=f'相关系数 {rho}',color=color)
ax.set(xlabel='组合波动率',ylabel='期望收益');ax.legend(frameon=False)
save(fig,'two-asset-frontiers.svg')
sigma=np.diag([.04,.01]);raw=np.linalg.solve(sigma,np.ones(2));weight=raw/raw.sum()
assert np.allclose(weight,[.2,.8]);print('最小方差权重',weight,'方差',weight@sigma@weight)
