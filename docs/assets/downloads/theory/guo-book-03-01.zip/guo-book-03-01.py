from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(301);factor=rng.normal(.003,.025,100);residual=rng.normal(.001,.008,100);active=.3*factor+residual
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(np.cumsum(active),label='主动收益');ax.plot(np.cumsum(.3*factor),label='因子贡献');ax.plot(np.cumsum(residual),label='残差贡献');ax.set(xlabel='月份',ylabel='累计算术收益');ax.legend(frameon=False);save(fig,'active-attribution.svg')
assert np.allclose(active,.3*factor+residual)
print('年化信息比率',np.sqrt(12)*.002/.01)
