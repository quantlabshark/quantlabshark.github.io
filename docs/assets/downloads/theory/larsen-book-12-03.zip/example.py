# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import f,ncf
means=np.array([2.,3.,5.]);sigma=1;n=3
nc=n*((means-means.mean())**2).sum()/sigma**2
critical=f.ppf(.95,2,3*n-3)
print('noncentrality',nc,'power',ncf.sf(critical,2,3*n-3,nc))
