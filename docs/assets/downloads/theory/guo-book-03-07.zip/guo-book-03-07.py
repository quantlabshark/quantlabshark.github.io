from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
P=np.array([[[.9,.1],[.98,.02]],[[.3,.7],[.8,.2]]]);cost=np.array([[.2,.35],[1.,.5]])
v=np.zeros(2);err=[]
for _ in range(200):
    q=cost+.9*np.einsum('saj,j->sa',P,v);n=q.min(1);err.append(np.max(abs(n-v)));v=n
fig,ax=plt.subplots(figsize=(7,3.6));ax.semilogy(np.arange(1,201),err,color='#257b88');ax.set(xlabel='迭代次数',ylabel='相邻价值最大差');save(fig,'value-iteration.svg')
assert err[-1]<1e-8
assert np.isclose(4+.2*(1+.9*2-4),3.76)
print('价值',v,'最优行动',q.argmin(1),'残差',err[-1])
