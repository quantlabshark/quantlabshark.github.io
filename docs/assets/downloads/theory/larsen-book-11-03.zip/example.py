# -*- coding: utf-8 -*-
rho=.6;mu_x,mu_y=1,3;sigma_x,sigma_y=2,4;x=5
conditional_mean=mu_y+rho*sigma_y/sigma_x*(x-mu_x)
conditional_variance=sigma_y**2*(1-rho**2)
print('Y|X=5 mean',conditional_mean,'variance',conditional_variance)
