# -*- coding: utf-8 -*-
def schedule(arrivals):
    finish=0;rows=[]
    for arrival,duration in arrivals:
        start=max(arrival,finish)
        rows.append((arrival,start,start-arrival))
        finish=start+duration
    return rows,finish
rows,finish=schedule([(0,3),(1,2),(4,1)])
assert [r[2] for r in rows]==[0,2,1]
assert finish==6
print(rows,finish)

import random,math
from collections import deque
def simulate(seconds=3600,speed=5,seed=20261018):
    rng=random.Random(seed);tasks=[]
    for second in range(seconds):
        if rng.random()<1/180:
            pages=rng.randint(1,20)
            tasks.append((second,math.ceil(60*pages/speed)))
    arrivals=deque(tasks);waiting=deque();remaining=0;clock=0;waits=[];maximum=0
    while clock<seconds or waiting or remaining:
        while arrivals and arrivals[0][0]==clock:waiting.append(arrivals.popleft())
        maximum=max(maximum,len(waiting))
        if remaining==0 and waiting:
            arrival,remaining=waiting.popleft();waits.append(clock-arrival)
        if remaining:remaining-=1
        clock+=1
    reference,_=schedule(tasks)
    assert waits==[row[2] for row in reference]
    return len(waits),sum(waits)/len(waits) if waits else 0,maximum
for speed in (5,10):
    for seed in (10,11,12):print('speed,seed,task count,mean wait,max queue',speed,seed,simulate(speed=speed,seed=seed))
