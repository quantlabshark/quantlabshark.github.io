# -*- coding: utf-8 -*-
import numpy as np
x=np.array([[[1.,3.],[3.,5.]],[[5.,7.],[11.,13.]]])
grand=x.mean();cell=x.mean(axis=2);a=x.mean(axis=(1,2));b=x.mean(axis=(0,2))
ss_a=4*((a-grand)**2).sum();ss_b=4*((b-grand)**2).sum()
ss_ab=2*((cell-a[:,None]-b[None,:]+grand)**2).sum()
ss_e=((x-cell[:,:,None])**2).sum()
assert np.allclose([ss_a,ss_b,ss_ab,ss_e],[72,32,8,8])
print('SS',ss_a,ss_b,ss_ab,ss_e,'F',np.array([ss_a,ss_b,ss_ab])/(ss_e/4))
