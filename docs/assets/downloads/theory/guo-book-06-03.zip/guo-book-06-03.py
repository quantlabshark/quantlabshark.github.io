from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight',dpi=200)
    plt.close(fig)

import numpy as np
sigma=.2;mu=.01;discount=.05;c=1.;lam=.02
n=np.roots([.5*sigma**2,mu-.5*sigma**2,-discount]).max();F=n*c/(n-1)
y=np.linspace(0,40,160);x=np.linspace(.3*F,3*F,160);Y,X=np.meshgrid(y,x);sell=np.minimum(Y,np.maximum(0,np.log(X/F)/lam))
fig,ax=plt.subplots(figsize=(6.5,4));im=ax.pcolormesh(Y,X,sell,shading='auto',cmap='viridis',rasterized=True);fig.colorbar(im,ax=ax,label='即时卖出量');ax.set(xlabel='库存',ylabel='当前价格');save(fig,'multiplicative-boundary.svg')
q=np.log(100/80)/.02;assert np.isclose(100*np.exp(-.02*q),80)
assert abs(.5*sigma**2*n*(n-1)+mu*n-discount)<1e-12
print('边界参数',n,F,'例题卖出量',q)
