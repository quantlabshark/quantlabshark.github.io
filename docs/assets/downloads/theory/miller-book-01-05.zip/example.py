# -*- coding: utf-8 -*-
class AndGate:
    def output(self,a,b):return bool(a and b)
class NotGate:
    def output(self,a):return not a
and_gate,not_gate=AndGate(),NotGate()
for a in (False,True):
    for b in (False,True):
        value=not_gate.output(and_gate.output(a,b))
        assert value==(not (a and b))
        print(a,b,value)
