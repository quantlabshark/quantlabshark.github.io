# -*- coding: utf-8 -*-
from scipy.stats import norm
x1,n1,x2,n2=60,100,45,100
p1,p2=x1/n1,x2/n2;pooled=(x1+x2)/(n1+n2)
z=(p1-p2)/(pooled*(1-pooled)*(1/n1+1/n2))**.5
se=(p1*(1-p1)/n1+p2*(1-p2)/n2)**.5
print('test z and p',z,2*norm.sf(abs(z)))
print('difference CI',p1-p2-1.96*se,p1-p2+1.96*se)
