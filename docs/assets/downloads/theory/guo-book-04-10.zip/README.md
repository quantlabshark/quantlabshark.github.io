# 已实现 GARCH、跳跃与波动预测

Python 3.10 或更高版本。

安装依赖：

    python -m pip install numpy matplotlib

运行：

    python guo-book-04-10.py

示例使用模拟数据或题面给出的数据。参数和单位见脚本注释。
