from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
t=np.arange(100);target=.6*np.exp(-t/35);fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(t,target,'--',color='gray',label='无成本目标')
for k in [.12,.6]:
    u=0;out=[]
    for v in target:u=(.12*v+k*u)/(.12+k);out.append(u)
    ax.plot(t,out,label=f'成本系数 {k}')
ax.set(xlabel='期数',ylabel='持仓');ax.legend(frameon=False);save(fig,'dynamic-position.svg')
assert np.isclose((.06+.18*.2)/(.12+.18),.32)
print('新持仓',.32,'买入量',.12)
