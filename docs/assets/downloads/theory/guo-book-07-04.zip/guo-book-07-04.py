from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(714);m=np.array([120.,70.]);Q=np.array([60.,10.]);h=.01;rebates=np.array([.001,.002]);penalty=.06;theta=.0005;w=h+rebates+penalty+theta;total=80.
star=(np.log(w[0]/w[1])-Q[0]/m[0]+(Q[1]+total)/m[1])/(1/m[0]+1/m[1]);star=np.clip(star,0,total)
def objective(l):
    L=np.array([l,total-l]);B=m*np.exp(-Q/m)*(1-np.exp(-L/m));return .013*20+.06*80+.0005*180-np.dot(w,B)
l=40.;trajectory=[]
for t in range(1,7001):
    eta=rng.exponential(m,size=(128,2));g=-w[0]*np.mean(eta[:,0]>Q[0]+l)+w[1]*np.mean(eta[:,1]>Q[1]+total-l)
    l=np.clip(l-80/(1+t/300)**.6*g,0,total);trajectory.append(l)
estimate=np.mean(trajectory[-1500:]);assert abs(estimate-star)<1.5
grid=np.linspace(0,80,201);fig,axes=plt.subplots(1,2,figsize=(8.2,3.5));axes[0].plot(grid,[objective(z) for z in grid]);axes[0].axvline(star,color='#bb784e',ls='--');axes[0].set(xlabel='分给市场一的股数',ylabel='期望成本');axes[1].plot(trajectory,color='#477e79',lw=.8);axes[1].axhline(star,color='#bb784e',ls='--',label='解析最优');axes[1].set(xlabel='更新次数',ylabel='市场一分配量');axes[1].legend(frameon=False);save(fig,'routing-stochastic-gradient.svg');print('解析分配',star,'随机梯度平均',estimate)
