"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-08-06'

n=4096;m=4000;dw=rng.normal(size=(m,n))/np.sqrt(n);exact=np.exp(dw.sum(1)-.5)-1;steps=np.array([32,64,128,256,512]);errors=[]
for k in steps:
    d=dw.reshape(m,k,n//k).sum(2);x=np.zeros(m)
    for j in range(k):x+=(x+1)*d[:,j]
    errors.append(np.mean((x-exact)**2))
assert errors[-1]<errors[0]/6
metrics['mean_square_errors']=[float(x) for x in errors]
fig,ax=plt.subplots(figsize=(6.4,3.7));ax.loglog(1/steps,errors,'o-',label='Euler mean square error');ax.loglog(1/steps,errors[0]*steps[0]/steps,'--',label='Proportional to step');ax.set(xlabel='Step size',ylabel='Mean square error');ax.set_xticks(1/steps);ax.set_xticklabels([f'1/{k}' for k in steps]);ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator());ax.legend();finish(fig)
