"""CTMC probabilities, exit times, and a two-state stopping decision."""
from pathlib import Path
import argparse
import json
import numpy as np
from scipy.linalg import expm
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def value_iteration(market_cost, tolerance=1e-13):
    transition = np.array([[0.0, 0.4], [0.5, 0.3]])
    value = np.zeros(2)
    for iteration in range(10000):
        wait = 0.1 + transition @ value
        new_value = np.minimum(market_cost, wait)
        if np.max(np.abs(new_value-value)) < tolerance:
            return new_value, np.where(wait < market_cost, "wait", "market").tolist()
        value = new_value
    raise RuntimeError("Value iteration did not converge")

def main(output):
    output.mkdir(parents=True, exist_ok=True)
    generator = np.array([[-2., 2.], [1., -1.]])
    stationary = np.array([1/3, 2/3])
    assert np.allclose(generator.sum(axis=1), 0)
    assert np.allclose(stationary @ generator, 0)
    time = np.linspace(0, 4, 241)
    probabilities = np.asarray([expm(generator*t)[0] for t in time])
    assert np.allclose(probabilities.sum(axis=1), 1)
    transient = np.array([[0., 0.4], [0.5, 0.3]])
    mean_steps = np.linalg.solve(np.eye(2)-transient, np.ones(2))
    assert np.allclose(mean_steps, [2.2, 3.0])
    value, policy = value_iteration(0.25)
    assert np.allclose(value, [0.2, 0.25]) and policy == ["wait", "market"]
    low_value, low_policy = value_iteration(0.15)
    assert np.allclose(low_value, [0.15, 0.15]) and low_policy == ["market", "market"]
    report = dict(stationary=stationary.tolist(), mean_waiting_steps=mean_steps.tolist(),
                  optimal_cost=value.tolist(), policy=policy, lower_market_cost_policy=low_policy)
    (output/"guo-appendix-b-results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    plt.rcParams.update({"font.size": 12, "axes.spines.top": False,
                         "axes.spines.right": False, "svg.fonttype": "none"})
    fig, ax = plt.subplots(figsize=(8, 3.8), facecolor="#f7f8f6")
    ax.set_facecolor("#f7f8f6")
    for i, color in enumerate(["#347b7a", "#b28a57"]):
        ax.plot(time, probabilities[:, i], color=color, lw=2, label=f"State {i}")
        ax.axhline(stationary[i], color=color, ls=":", lw=1)
    ax.set(xlabel="Time", ylabel="Transition probability", ylim=(-0.03, 1.03))
    ax.legend(frameon=False)
    ax.grid(alpha=0.15)
    fig.tight_layout()
    fig.savefig(output/"guo-appendix-b.svg", bbox_inches="tight")
    plt.close(fig)
    print(json.dumps(report))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("outputs"))
    main(parser.parse_args().output)
