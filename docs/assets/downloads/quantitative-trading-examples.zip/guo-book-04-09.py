from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
p=.4;q=.6;theta=.7;marks=np.arange(-8,9);prob=[]
for m in marks:
    prob.append(1-p if m==0 else p*(q if m>0 else 1-q)*theta*(1-theta)**(abs(m)-1))
fig,ax=plt.subplots(figsize=(7,3.6));ax.bar(marks,prob,color='#438f99');ax.set(xlabel='价格变化（档）',ylabel='概率');save(fig,'price-mark-distribution.svg')
assert np.isclose(.5*(.7*2-.3),.55)
assert sum(prob)<1 and sum(prob)>.999
print('有限画图区间概率和',sum(prob),'练习均值',.55)
