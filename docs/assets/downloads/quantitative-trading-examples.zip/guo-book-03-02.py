from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
from itertools import combinations
vol=np.array([.10,.15,.20,.25]);rows=[]
for pair in combinations(range(4),2):
    v=vol[list(pair)]**2;w=(1/v)/(1/v).sum();rows.append((pair,float(np.sum(w*w*v))))
fig,ax=plt.subplots(figsize=(7,3.6));ax.bar([f'{p[0]+1}与{p[1]+1}' for p,v in rows],[v for p,v in rows],color='#438f99');ax.set(xlabel='持仓资产集合',ylabel='组合方差');save(fig,'cardinality-sets.svg')
assert min(rows,key=lambda z:z[1])[0]==(0,1)
assert np.isclose(rows[0][1],1/(100+1/.0225))
print(rows)
