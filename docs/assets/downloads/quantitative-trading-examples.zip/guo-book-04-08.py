from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(408);mu=.4;alpha=.6;beta=1.2;T=100;t=0.;exc=0.;events=[]
while t<T:
    bound=mu+exc;dt=rng.exponential(1/bound);t+=dt;exc*=np.exp(-beta*dt)
    if t>T:break
    if rng.random()<(mu+exc)/bound:events.append(t);exc+=alpha
grid=np.linspace(0,T,2000);lam=np.full_like(grid,mu)
for e in events:lam+=alpha*np.exp(-beta*np.maximum(grid-e,0))*(grid>e)
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(grid,lam,color='#257b88');ax.plot(events,np.zeros(len(events)),'|',color='#b05b52');ax.set(xlabel='秒',ylabel='条件到达率');save(fig,'hawkes-intensity.svg')
assert np.isclose(mu/(1-alpha/beta),.8)
print('事件数',len(events),'理论平稳强度',.8,'半衰期',np.log(2)/beta)
