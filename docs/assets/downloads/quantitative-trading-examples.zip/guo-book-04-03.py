from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(403);n=15000;x=np.r_[0,np.cumsum(rng.normal(0,.012/np.sqrt(n),n))];y=x+rng.normal(0,.00015,n+1);r=np.diff(y);a2=max(0,-np.mean(r[1:]*r[:-1]));ks=np.arange(15,260,10);est=[]
for k in ks:
    g=np.minimum(np.arange(k+1)/k,1-np.arange(k+1)/k);pre=np.convolve(r,g[1:-1],mode='valid');A=np.sum(g*g);B=np.sum(np.diff(g)**2);est.append(n*(np.mean(pre**2)-a2*B)/A)
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(ks,est,color='#257b88');ax.axhline(.012**2,color='#b05b52',ls='--');ax.set(xlabel='预平均窗长',ylabel='积分方差估计');save(fig,'preaverage-window.svg')
g=np.array([0,.25,.5,.25,0]);assert np.isclose(g@g,.375) and np.isclose(np.diff(g)@np.diff(g),.25)
print('离散权重系数',.375,.25,'噪声方差估计',a2)
