from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
t=np.linspace(0,1,401);fig,ax=plt.subplots(figsize=(7,3.6))
for k in [0,1,2,4]:
    x=1-t if k==0 else np.sinh(k*(1-t))/np.sinh(k);ax.plot(t,x,label=f'κ={k}');assert abs(x[0]-1)<1e-12 and abs(x[-1])<1e-12
ax.set(xlabel='执行时间比例',ylabel='剩余库存比例');ax.legend(frameon=False);save(fig,'almgren-chriss-path.svg')
print('半程剩余库存',np.sinh(1)/np.sinh(2))
