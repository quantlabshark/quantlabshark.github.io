from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
p=np.linspace(0,1,200);cost=98.98*p+100.6*(1-p);fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(p,cost,label='先挂限价再补单');ax.axhline(100.1,color='#b05b52',ls='--',label='立即市价');ax.set(xlabel='限价成交概率',ylabel='预期每股成本');ax.legend(frameon=False);save(fig,'limit-placement-cost.svg')
assert np.isclose(.6*98.98+.4*100.6,99.628)
print('例题成本',99.628,'概率阈值',.5/1.62)
