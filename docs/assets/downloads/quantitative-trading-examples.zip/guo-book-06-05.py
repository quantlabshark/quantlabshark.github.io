from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
N=8;Q=100;idx=np.arange(N+1);fig,ax=plt.subplots(figsize=(7,3.6))
for a in [.2,.6,.9]:
    edge=Q/(2+(N-1)*(1-a));q=np.r_[edge,np.full(N-1,(1-a)*edge),edge];K=a**abs(idx[:,None]-idx[None,:]);numeric=np.linalg.solve(K,np.ones(N+1));numeric*=Q/numeric.sum();assert np.allclose(q,numeric);ax.plot(idx,q,'o-',label=f'残留比例 {a}')
ax.set(xlabel='交易时点序号',ylabel='交易数量');ax.legend(frameon=False);save(fig,'lob-optimal-split.svg')
print('200股块状成本',200**2/(2*1000))
