from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
Q=100;z0=50;m=5;c=10;tau=Q/c*np.log(1+c*z0/(m*Q));t=np.linspace(0,tau,200);z=(z0+m*Q/c)*np.exp(-c*t/Q)-m*Q/c
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(t,z,label='前方数量');ax.axhline(Q,color='gray',ls='--',label='总队列');ax.set(xlabel='秒',ylabel='数量');ax.legend(frameon=False);save(fig,'queue-position.svg')
assert abs(z[-1])<1e-10 and np.isclose(tau,10*np.log(2))
print('到达队首的流体时间',tau,'撤单前方减少期望',2)
