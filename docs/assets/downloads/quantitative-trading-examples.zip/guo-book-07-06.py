from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
S=[np.array([.9,.6,.2]),np.array([.8,.7,.1])];allocation=[0,0];chosen=[]
for _ in range(3):
    i=max(range(2),key=lambda k:S[k][allocation[k]]);chosen.append((i,allocation[i]));allocation[i]+=1
value=lambda a:sum(S[k][:a[k]].sum() for k in range(2))
all_values=[value([j,3-j]) for j in range(4)];assert allocation==[1,2] and np.isclose(value(allocation),2.4) and np.isclose(max(all_values),2.4)
fig,ax=plt.subplots(figsize=(7,3.6));x=np.arange(1,4);ax.bar(x-.18,S[0],.36,label='市场 A',color='#477e79');ax.bar(x+.18,S[1],.36,label='市场 B',color='#b99565');ax.set(xlabel='分给该市场的第几股',ylabel='边际成交概率',xticks=x,ylim=(0,1));ax.legend(frameon=False);save(fig,'greedy-capacity-allocation.svg');print('逐股选择',chosen,'最优分配',allocation,'所有分配收益',all_values)
