from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
import matplotlib.pyplot as plt
rng=np.random.default_rng(42);n=15000
sign=rng.choice([-1,1],n);price=100+.02*sign;change=np.diff(price)
cov=np.mean((change[1:]-change[1:].mean())*(change[:-1]-change[:-1].mean()))
assert abs(np.var(change)-.0008)<.00004
assert abs(cov+.0004)<.00004
fig,axes=plt.subplots(2,1,figsize=(7.2,5.0))
axes[0].step(np.arange(50),price[:50],where='post',color='#387ca3');axes[0].axhline(100,color='#b98a49',lw=.8)
axes[0].set(xlabel='成交序号',ylabel='成交价格')
values,counts=np.unique(np.round(change,2),return_counts=True)
axes[1].bar(values,counts/counts.sum(),width=.012,color='#387ca3');axes[1].set(xlabel='相邻价格变化',ylabel='频率')
save(fig,'tick-and-bounce.svg')
print('增量方差',np.var(change),'一阶自协方差',cov)
