from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
from scipy.fft import dst
from scipy.optimize import minimize
rng=np.random.default_rng(404);n=2500;dt=1/n;x=np.r_[0,np.cumsum(rng.normal(0,.02*np.sqrt(dt),n))];y=x+rng.normal(0,.0005,n+1);z=dst(np.diff(y),type=1,norm='ortho');q=2*(1-np.cos(np.arange(1,n+1)*np.pi/(n+1)))
def loss(logp):
    s2,a2=np.exp(logp);d=s2*dt+a2*q;return .5*np.sum(np.log(d)+z*z/d)
fit=minimize(loss,np.log([.0004,2.5e-7]),method='L-BFGS-B');s2,a2=np.exp(fit.x)
grid=np.linspace(.0001,.0008,100);v=np.array([loss(np.log([v,a2])) for v in grid]);fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(grid,v-v.min(),color='#257b88');ax.set(xlabel='有效价格方差',ylabel='负对数似然与最小值之差');save(fig,'qmle-profile.svg')
assert fit.success and s2>0 and a2>0
assert np.isclose(.0001*(1-.8)**2/.01,.0004)
print('拟合方差与噪声方差',s2,a2)
