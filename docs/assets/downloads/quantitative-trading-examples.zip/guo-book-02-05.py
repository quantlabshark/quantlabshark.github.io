from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
from scipy.stats import norm
rng=np.random.default_rng(205);n=350000
v=rng.gamma(2,.5,n);r=np.sqrt(v)*rng.normal(size=n)
levels=np.linspace(.3,5,90);tail=np.array([(np.abs(r)>x).mean() for x in levels])
fig,ax=plt.subplots(figsize=(7,3.6));ax.semilogy(levels,tail,label='随机时钟');ax.semilogy(levels,2*norm.sf(levels),'--',label='同方差正态');ax.set(xlabel='标准差倍数',ylabel='双侧超越概率');ax.legend(frameon=False);save(fig,'random-clock-tails.svg')
kurt=np.mean(r**4)/np.mean(r**2)**2
assert abs(kurt-4.5)<.2
assert np.isclose(3*(1+1/4),3.75)
print('理论/模拟峰度',4.5,kurt)
