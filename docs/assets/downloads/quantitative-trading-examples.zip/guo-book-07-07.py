from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
from scipy.optimize import brentq
rng=np.random.default_rng(717);m=np.array([.4,.8,.3]);rho=np.array([1.,.8,1.2]);lam=brentq(lambda z:np.maximum(0,m*np.log(rho/z)).sum()-1,.0001,rho.max());star=np.maximum(0,m*np.log(rho/lam))
def project(v):
    u=np.sort(v)[::-1];css=np.cumsum(u)-1;j=np.arange(1,len(v)+1);valid=u-css/j>0;k=np.flatnonzero(valid)[-1];return np.maximum(v-css[k]/(k+1),0)
r=np.ones(3)/3;trajectory=[]
for t in range(1,30001):
    capacity=rng.exponential(m);g=rho*(capacity>r);r=project(r+.08/t**.65*g);trajectory.append(r.copy())
trajectory=np.array(trajectory);estimate=trajectory[15000:].mean(axis=0);assert np.max(np.abs(estimate-star))<.04
fig,ax=plt.subplots(figsize=(7,3.8));colors=['#477e79','#b99565','#6f81a8']
for i,color in enumerate(colors):ax.plot(np.arange(1,len(trajectory)+1),trajectory[:,i],color=color,lw=.7,label=f'市场 {i+1}');ax.axhline(star[i],color=color,ls='--',lw=.8)
ax.set(xlabel='更新次数',ylabel='订单分配比例',ylim=(0,1));ax.legend(frameon=False,ncol=3);save(fig,'stochastic-routing-proportions.svg');print('理论最优',star,'后半段平均',estimate)
assert np.allclose(project(np.array([-.5,.8,1.2])).sum(),1)
