from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(308);n=150;x=np.cumsum(rng.normal(0,.12,n));y=x+rng.normal(0,.5,n);m=0.;p=1.;est=[]
for z in y:
    p+=.12**2;k=p/(p+.5**2);m+=k*(z-m);p=(1-k)**2*p+k*k*.5**2;est.append(m)
fig,ax=plt.subplots(figsize=(7,3.6));ax.scatter(np.arange(n),y,s=7,alpha=.35,label='观测');ax.plot(x,label='隐藏状态');ax.plot(est,label='滤波估计');ax.set(xlabel='时点',ylabel='状态');ax.legend(frameon=False,ncol=3);save(fig,'kalman-state.svg')
assert np.isclose(10+4/5*2,11.6) and np.isclose(10+1/5*2,10.4)
print('两种信息精度的更新均值',11.6,10.4)
