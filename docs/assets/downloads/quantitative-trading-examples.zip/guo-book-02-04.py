from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(204)
data=rng.multivariate_normal([.008,.005],[[.0016,.0002],[.0002,.0005]],size=180)
etas=np.linspace(.1,2.4,30);lam=8.;B=1200
sample_indices=rng.integers(len(data),size=(B,60));future_indices=rng.integers(len(data),size=B)
results=[]
for eta in etas:
    outcomes=[]
    for b in range(B):
        sample=data[sample_indices[b]]
        mu=sample.mean(0);V=sample.T@sample/len(sample)+np.eye(2)*1e-7
        inv1=np.linalg.solve(V,np.ones(2));invm=np.linalg.solve(V,mu)
        C=inv1.sum();A=invm.sum()
        w=inv1/C+eta/(2*lam)*(invm-A/C*inv1)
        w=np.array([np.clip(w[0],0,1),1-np.clip(w[0],0,1)])
        outcomes.append(w@data[future_indices[b]])
    a=np.array(outcomes);results.append([a.mean(),a.var(),a.mean()-lam*a.var()])
results=np.array(results)
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(etas,results[:,2],color='#257b88');ax.set(xlabel='参数 η',ylabel='估计均值减风险惩罚');save(fig,'npeb-utility.svg')
assert np.isclose(.0004+np.var([0,.02]),.0005)
print('最佳网格参数',etas[results[:,2].argmax()]);print('全方差例题',.0005)
