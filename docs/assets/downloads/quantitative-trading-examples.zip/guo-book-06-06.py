from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
t=np.linspace(0,1,301);fig,ax=plt.subplots(figsize=(7,3.6))
for eig,label in [(1.8,'共同方向'),(.2,'对冲方向')]:
    k=np.sqrt(5*eig);x=np.sinh(k*(1-t))/np.sinh(k);ax.plot(t,x,label=label)
ax.set(xlabel='执行时间比例',ylabel='方向上的剩余库存比例');ax.legend(frameon=False);save(fig,'portfolio-execution.svg')
S=np.array([[1,.8],[.8,1]]);same=np.array([10,10]);hedge=np.array([10,-10]);assert np.isclose(same@S@same,360) and np.isclose(hedge@S@hedge,40)
print('同向/对冲风险',same@S@same,hedge@S@hedge)
