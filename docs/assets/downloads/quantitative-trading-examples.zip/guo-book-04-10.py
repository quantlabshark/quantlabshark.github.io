from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(410);n=10000;r=rng.normal(0,.01/np.sqrt(n),n);r[n//2]+=.03;x=np.r_[0,r.cumsum()];rv=np.sum(r*r);bv=np.pi/2*np.sum(abs(r[1:])*abs(r[:-1]))
fig,axs=plt.subplots(2,1,figsize=(7,4.5),sharex=True);axs[0].plot(x,color='#257b88');axs[0].set_ylabel('对数价格');axs[1].plot(np.cumsum(r*r),color='#b05b52');axs[1].set(xlabel='事件序号',ylabel='累计平方变差');save(fig,'jump-variation.svg')
assert np.isclose(.0001+.03**2,.001)
print('RV',rv,'BV',bv,'估计跳跃变差',rv-bv)
