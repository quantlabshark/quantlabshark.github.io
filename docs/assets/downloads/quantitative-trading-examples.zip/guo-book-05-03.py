from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
rng=np.random.default_rng(503);X=rng.normal(size=(8000,3));p=1/(1+np.exp(-(1.2*X[:,0]-.5*X[:,1])));y=rng.binomial(1,p);sc=StandardScaler().fit(X[:5000]);model=LogisticRegression().fit(sc.transform(X[:5000]),y[:5000]);pred=model.predict_proba(sc.transform(X[5000:]))[:,1];obs=y[5000:]
centers=[];rates=[]
for a,b in zip(np.linspace(0,.9,10),np.linspace(.1,1,10)):
    take=(pred>=a)&(pred<b)
    if take.sum()>15:centers.append(pred[take].mean());rates.append(obs[take].mean())
fig,ax=plt.subplots(figsize=(6,4));ax.plot([0,1],[0,1],'--',color='gray');ax.plot(centers,rates,'o-',color='#257b88');ax.set(xlabel='平均预测上涨概率',ylabel='实际上涨频率',xlim=(0,1),ylim=(0,1));save(fig,'lob-calibration.svg')
assert np.isclose(.55*1.5-.45-.2,.175)
print('测试Brier损失',np.mean((pred-obs)**2),'练习净收益',.175)
