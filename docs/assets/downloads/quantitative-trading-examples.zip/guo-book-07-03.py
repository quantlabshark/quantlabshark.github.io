from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
x=np.linspace(0,120,241);fig,ax=plt.subplots(figsize=(7,3.7))
for q in [10,30,60]:ax.plot(x,np.minimum(np.maximum(x-q,0),50),label=f'前方队列 {q}')
ax.set(xlabel='有效队列消耗量',ylabel='本订单成交量');ax.legend(frameon=False);save(fig,'routing-queue-fill.svg')
def cost(eta):
    B=np.minimum(np.maximum(np.array(eta)-[30,10],0),[50,50]);a=20+B.sum();under=max(100-a,0);over=max(a-100,0)
    return a,.013*20-np.dot([.011,.012],B)+.05*under+.06*over+.0005*(120+under)
assert np.isclose(cost([70,50])[1],-.6) and np.isclose(cost([70,20])[1],1.275)
print('正常与缺单场景',cost([70,50]),cost([70,20]))
