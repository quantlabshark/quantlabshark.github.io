# -*- coding: utf-8 -*-
from scipy.stats import poisson,binom
print('Poisson(3) P(X<=2)',poisson.cdf(2,3))
for n in [30,300,3000]:
    print(n,binom.cdf(2,n,3/n))
