# -*- coding: utf-8 -*-
import numpy as np
rng=np.random.default_rng(20261018)
n=10000
u=rng.random(n)
x=-np.log1p(-u)/2
print('mean',x.mean(),'variance',x.var(ddof=1),'mean SE',0.5/n**0.5)
print('tail P(X>1)',np.mean(x>1),'theory',np.exp(-2))
