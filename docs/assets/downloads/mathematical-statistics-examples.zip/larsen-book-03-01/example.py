# -*- coding: utf-8 -*-
from scipy.stats import binom,hypergeom
print('with replacement',binom.pmf(2,3,.4))
print('without replacement',hypergeom.pmf(2,10,4,3))
assert abs(hypergeom.pmf(2,10,4,3)-.3)<1e-12
