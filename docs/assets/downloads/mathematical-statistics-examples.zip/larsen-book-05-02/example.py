# -*- coding: utf-8 -*-
from scipy.stats import norm
n=20;phat=.1;z=norm.ppf(.975)
center=(phat+z*z/(2*n))/(1+z*z/n)
half=z*(phat*(1-phat)/n+z*z/(4*n*n))**.5/(1+z*z/n)
assert 0<=center-half<center+half<=1
print('Wilson interval',center-half,center+half)
