# -*- coding: utf-8 -*-
import numpy as np
from scipy.integrate import quad
x=np.array([2.,4.,9.]);mu=4
left=((x-mu)**2).sum()
right=((x-x.mean())**2).sum()+len(x)*(x.mean()-mu)**2
assert np.isclose(left,right)
print('sum, mean, squared deviations:',x.sum(),x.mean(),left)
print('density area 0..0.5:',quad(lambda t:2*t,0,.5)[0])
