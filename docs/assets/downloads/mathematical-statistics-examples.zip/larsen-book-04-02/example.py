# -*- coding: utf-8 -*-
from scipy.stats import norm,binom
exact=binom.cdf(45,100,.4)
approx=norm.cdf((45.5-40)/24**.5)
print('exact',exact,'normal with correction',approx,'error',approx-exact)
