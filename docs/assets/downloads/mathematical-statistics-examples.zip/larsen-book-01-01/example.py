# -*- coding: utf-8 -*-
import numpy as np
success=np.array([[9,18],[72,1]])
total=np.array([[10,90],[90,10]])
print('within-group rates:',success/total)
print('aggregate rates:',success.sum(axis=1)/total.sum(axis=1))
print('equal-weight rates:',(success/total).mean(axis=1))
