# -*- coding: utf-8 -*-
import numpy as np
values=np.array([0,1,2]);prob=np.array([.25,.5,.25])
cdf=np.cumsum(prob)
assert np.isclose(prob.sum(),1)
for q in [.25,.5,.9]:
    print(q,values[np.searchsorted(cdf,q,side='left')])
