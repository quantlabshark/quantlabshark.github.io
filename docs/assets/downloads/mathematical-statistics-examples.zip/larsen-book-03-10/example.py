# -*- coding: utf-8 -*-
import numpy as np
p=.3;n=5;t=.2
mgf=(1-p+p*np.exp(t))**n
from scipy.stats import binom
direct=sum(np.exp(t*k)*binom.pmf(k,n,p) for k in range(n+1))
assert np.isclose(mgf,direct)
print('MGF',mgf,'mean',n*p,'variance',n*p*(1-p))
