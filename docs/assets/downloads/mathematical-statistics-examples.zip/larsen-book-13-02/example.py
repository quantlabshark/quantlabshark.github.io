# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import ttest_rel,t
before=np.array([9.,12.,15.,11.,14.]);after=np.array([10.,14.,16.,13.,16.])
d=after-before
half=t.ppf(.975,len(d)-1)*d.std(ddof=1)/len(d)**.5
print('differences',d,'interval',d.mean()-half,d.mean()+half)
print(ttest_rel(after,before))
