# -*- coding: utf-8 -*-
from scipy import stats
print('z .975',stats.norm.ppf(.975))
print('t(10) .975',stats.t.ppf(.975,10))
print('chi2(5) interval',stats.chi2.ppf([.025,.975],5))
print('F(5,10) .95',stats.f.ppf(.95,5,10))
print('binomial >=8',stats.binom.sf(7,10,.5))
print('binomial >8',stats.binom.sf(8,10,.5))
