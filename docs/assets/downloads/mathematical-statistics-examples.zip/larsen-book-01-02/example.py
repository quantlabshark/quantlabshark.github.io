# -*- coding: utf-8 -*-
import numpy as np
rng=np.random.default_rng(20261018)
for n in [4,16,64]:
    means=rng.normal(0,6,(20000,n)).mean(axis=1)
    print(n,means.std(ddof=1),'theory',6/np.sqrt(n))
