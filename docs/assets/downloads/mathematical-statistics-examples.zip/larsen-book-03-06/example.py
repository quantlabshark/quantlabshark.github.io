# -*- coding: utf-8 -*-
import numpy as np
p=np.array([[.1,.2],[.3,.4]])
px=p.sum(axis=1);py=p.sum(axis=0)
assert np.isclose(p.sum(),1)
print('marginals',px,py,'independent?',np.allclose(p,np.outer(px,py)))
print('P(X=1|Y=0)',p[1,0]/py[0])
