# 数理统计及其应用：Python 示例

每个目录对应一个教学单元，先阅读目录内 README.md，再运行 example.py。
