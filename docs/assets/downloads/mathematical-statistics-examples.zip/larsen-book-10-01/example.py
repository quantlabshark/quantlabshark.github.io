# -*- coding: utf-8 -*-
from scipy.stats import chisquare
observed=[18,22,20];expected=[20,20,20]
result=chisquare(observed,expected)
assert abs(result.statistic-.4)<1e-12
print(result)
