# -*- coding: utf-8 -*-
from math import log,ceil
p=.1
print('at least one in 5:',1-(1-p)**5)
n=ceil(log(.05)/log(1-p))
assert 1-(1-p)**n>=.95 and 1-(1-p)**(n-1)<.95
print('required repetitions',n)
