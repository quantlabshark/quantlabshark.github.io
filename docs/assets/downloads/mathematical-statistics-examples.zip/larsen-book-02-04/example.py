# -*- coding: utf-8 -*-
from math import comb,factorial,perm
print('ordered choices',perm(5,3),'unordered choices',comb(5,3))
assert perm(5,3)==comb(5,3)*factorial(3)
print('multiset arrangements of AABBC',factorial(5)//(factorial(2)*factorial(2)))
