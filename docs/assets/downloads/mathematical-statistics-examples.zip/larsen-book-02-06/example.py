# -*- coding: utf-8 -*-
import numpy as np
rng=np.random.default_rng(20261018)
n=100000
xy=rng.random((n,2))
p=np.mean(np.sum(xy*xy,axis=1)<=1)
print('pi estimate',4*p,'standard error',4*np.sqrt(p*(1-p)/n))
