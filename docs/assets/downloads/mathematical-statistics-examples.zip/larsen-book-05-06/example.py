# -*- coding: utf-8 -*-
import numpy as np
rng=np.random.default_rng(20261018)
x=np.array([2.,4.,6.,8.])
copies=rng.choice(x,size=(20000,len(x)),replace=True).mean(axis=1)
print('bootstrap SE',copies.std(ddof=1),'conditional exact SE',np.sqrt(1.25))
