# -*- coding: utf-8 -*-
from scipy.stats import gamma,poisson
rate=2;k=3;t=1
waiting=gamma.cdf(t,a=k,scale=1/rate)
arrivals=poisson.sf(k-1,rate*t)
assert abs(waiting-arrivals)<1e-12
print('P(T_3<=1)=P(N(1)>=3)',waiting)
