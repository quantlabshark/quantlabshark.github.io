# -*- coding: utf-8 -*-
import numpy as np
x=np.array([1.,2.,2.,5.])
print('normal mean MLE',x.mean(),'variance MLE',x.var(ddof=0))
print('unbiased variance',x.var(ddof=1))
print('uniform upper-bound MLE',x.max(),'method of moments',2*x.mean())
