# -*- coding: utf-8 -*-
from itertools import product
omega=set(product(range(1,7),repeat=2))
a={x for x in omega if sum(x)==7};b={x for x in omega if x[0]==3}
assert len(a|b)==len(a)+len(b)-len(a&b)==11
print('intersection',a&b,'union probability',len(a|b)/len(omega))
