# -*- coding: utf-8 -*-
import numpy as np
w=np.array([.4,.6]);means=np.array([2.,5.]);variances=np.array([1.,4.])
mu=w@means
within=w@variances;between=w@((means-mu)**2)
print('E(X)',mu,'within',within,'between',between,'Var(X)',within+between)
