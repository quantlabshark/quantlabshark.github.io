# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import poisson,chi2
observed=np.array([30,36,20,14]);n=observed.sum()
# Bins 0,1,2,>=3; known rate is used here, so df=4-1.
prob=np.r_[poisson.pmf([0,1,2],1.2),poisson.sf(2,1.2)]
expected=n*prob
stat=((observed-expected)**2/expected).sum()
print('expected',expected,'statistic',stat,'p for known rate',chi2.sf(stat,3))
