# -*- coding: utf-8 -*-
from scipy.integrate import quad
assert abs(quad(lambda x:2*x,0,1)[0]-1)<1e-12
print('P(0.2<X<0.6)',quad(lambda x:2*x,.2,.6)[0])
print('E(X)',quad(lambda x:x*2*x,0,1)[0])
