# -*- coding: utf-8 -*-
from math import prod
p=.3
a=[1,0,1,0];b=[0,1,0,1]
lik=lambda x:prod(p**z*(1-p)**(1-z) for z in x)
from math import isclose
assert isclose(lik(a),lik(b),rel_tol=1e-12)
print('same count, same Bernoulli likelihood',lik(a))
