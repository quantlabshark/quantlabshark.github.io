# -*- coding: utf-8 -*-
import numpy as np
from scipy import stats
x=np.array([8.,9.,10.,11.,12.]);n=x.size
se=x.std(ddof=1)/np.sqrt(n);t=(x.mean()-9)/se
critical=stats.t.ppf(.975,n-1)
print('mean',x.mean(),'variance',x.var(ddof=1),'t',t)
print('p',2*stats.t.sf(abs(t),n-1),'CI',x.mean()+np.array([-1,1])*critical*se)
