# -*- coding: utf-8 -*-
from scipy.stats import chi2
n=10;s2=4;df=n-1
interval=(df*s2/chi2.ppf(.975,df),df*s2/chi2.ppf(.025,df))
print('variance interval',interval)
assert interval[0]<s2<interval[1]
