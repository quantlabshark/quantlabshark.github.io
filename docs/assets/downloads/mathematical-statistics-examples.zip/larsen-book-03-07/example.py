# -*- coding: utf-8 -*-
from scipy.integrate import quad
def convolution(s):
    lo=max(0,s-1);hi=min(1,s)
    return max(0,hi-lo)
for s in [.25,.75,1,1.5,2]:
    print(s,convolution(s))
assert abs(quad(convolution,0,2)[0]-1)<1e-10
