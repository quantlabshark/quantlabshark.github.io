# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import studentized_range
means=np.array([2.,4.,6.]);mse=1.;n=3;k=3;df=6
critical=studentized_range.ppf(.95,k,df)
half=critical*(mse/n)**.5
for i in range(k):
    for j in range(i+1,k):
        difference=means[i]-means[j]
        print(i,j,'Tukey interval',difference-half,difference+half)
