# -*- coding: utf-8 -*-
import numpy as np
x=np.array([0.,1.,2.,3.]);y=np.array([1.,2.,2.,4.])
design=np.column_stack([np.ones(len(x)),x])
b=np.linalg.lstsq(design,y,rcond=None)[0];residual=y-design@b
assert np.allclose(design.T@residual,0)
print('intercept, slope',b,'residuals',residual)
