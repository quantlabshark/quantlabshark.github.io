# -*- coding: utf-8 -*-
import numpy as np
rng=np.random.default_rng(8);x=rng.normal(0,2,(50000,5))
for name,est in [('MLE',x.var(axis=1)),('unbiased',x.var(axis=1,ddof=1))]:
    bias=est.mean()-4;var=est.var();mse=((est-4)**2).mean()
    assert np.isclose(mse,var+bias*bias)
    print(name,'bias',bias,'variance',var,'MSE',mse)
