# -*- coding: utf-8 -*-
# 21 · 突破通道、真实波幅与风险仓位
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from math import floor
highs, lows, previous_closes = [102,108,109],[98,104,103],[100,100,107]
true_ranges = [max(h-l,abs(h-c),abs(l-c)) for h,l,c in zip(highs,lows,previous_closes)]
atr = sum(true_ranges)/len(true_ranges)
equity,risk_fraction,multiplier = 100000,0.01,10
distance = 2*atr
contracts = floor(equity*risk_fraction/(distance*multiplier))
print("TR:",true_ranges,"ATR:",atr)
print("合约数:",contracts,"计划止损金额:",contracts*distance*multiplier)
assert true_ranges == [4,8,6] and contracts == 8
