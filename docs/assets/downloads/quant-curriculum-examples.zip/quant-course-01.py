# -*- coding: utf-8 -*-
# 01 · 量化研究、交易规则与账户核算
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
previous_returns = [0.02, -0.01, 0.01, -0.02]
opens = [103, 102, 105, 100]
closes = [104, 101, 103, 102]
cash, shares, fee_per_share = 2000.0, 10, 0.01
for day, (signal, buy, sell) in enumerate(zip(previous_returns, opens, closes), 1):
    pnl = shares * (sell-buy) - 2*shares*fee_per_share if signal > 0 else 0.0
    cash += pnl
    print(day, f"当日净盈亏 {pnl:.2f} 元", f"现金 {cash:.2f} 元")
print(f"累计收益 {cash/2000-1:.2%}")
assert abs(cash-1989.6) < 1e-9
