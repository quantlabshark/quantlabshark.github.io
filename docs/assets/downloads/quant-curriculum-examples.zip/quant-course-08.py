# -*- coding: utf-8 -*-
# 08 · 用变量、列表和函数表达交易账本
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
trades = [
    {"side":"buy", "price":100.0, "shares":20},
    {"side":"sell", "price":105.0, "shares":8},
]
cash, position = 5000.0, 0
for trade in trades:
    quantity, price = trade["shares"], trade["price"]
    if trade["side"] == "buy":
        cash -= quantity*price + 2
        position += quantity
    else:
        cash += quantity*price - 2
        position -= quantity
market_value = position*103.0
print(cash, position, market_value, cash+market_value)
assert cash == 3836 and cash+market_value == 5072

# 示例 2
def simple_return(start_price, end_price):
    if start_price <= 0:
        raise ValueError("期初价格必须大于零")
    return end_price/start_price - 1

prices = [100,102,101,105]
returns = [simple_return(a,b) for a,b in zip(prices[:-1],prices[1:])]
print([round(r*100,4) for r in returns])
assert len(returns) == len(prices)-1
