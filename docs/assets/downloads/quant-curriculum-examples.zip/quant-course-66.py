# -*- coding: utf-8 -*-
# 66 · 学习资料索引与职业准备
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
dependencies = {
    "事件数据": ["Python"], "队列": ["概率", "事件数据"],
    "执行优化": ["队列"], "回放项目": ["执行优化", "事件数据"]}
hours = {"事件数据": 2, "队列": 3, "执行优化": 3, "回放项目": 4}
known = {"Python", "概率"}
plan, visited = [], set(known)
def visit(topic):
    if topic in visited:
        return
    for prerequisite in dependencies.get(topic, []):
        visit(prerequisite)
    visited.add(topic)
    plan.append(topic)
visit("回放项目")
print(" → ".join(plan))
print("估计小时", sum(hours[t] for t in plan))
assert plan == ["事件数据", "队列", "执行优化", "回放项目"]
assert sum(hours[t] for t in plan) == 12
