# -*- coding: utf-8 -*-
# 20 · 移动平均怎样生成趋势持仓
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
closes = [10,10,10,11,12,11,10,9,10,11,12,11]
opens = [10,10,10,10.5,11.5,12,10.5,9.5,9.5,10.5,11.5,12]
def average_at(values,index,window):
    return sum(values[index-window+1:index+1])/window if index+1>=window else None
cash, shares, target = 1000.0,0,0
for i,(op,cl) in enumerate(zip(opens,closes)):
    order = target-shares
    cash -= order*op + (1 if order else 0)
    shares = target
    short,long = average_at(closes,i,3),average_at(closes,i,5)
    target = 10 if long is not None and short>long else 0
    print(i+1,"短线",short,"长线",long,"成交股数",order,"资产",round(cash+shares*cl,2))
print("最终资产:",cash+shares*closes[-1])
assert abs(cash+shares*closes[-1]-962) < 1e-10
