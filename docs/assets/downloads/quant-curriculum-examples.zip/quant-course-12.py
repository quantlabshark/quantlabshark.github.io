# -*- coding: utf-8 -*-
# 12 · 按信息到达时间重建历史数据
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from datetime import date
events = [
    {"available":date(2026,4,20),"period":date(2026,3,31),"value":100},
    {"available":date(2026,6,1),"period":date(2026,3,31),"value":90},
]
def known_value(decision_date):
    known = [x for x in events if x["available"] <= decision_date]
    return max(known,key=lambda x:x["available"])["value"] if known else None
for decision in [date(2026,4,10),date(2026,5,1),date(2026,6,10)]:
    print(decision,known_value(decision))
assert [known_value(date(2026,m,d)) for m,d in [(4,10),(5,1),(6,10)]] == [None,100,90]
