# -*- coding: utf-8 -*-
# 05 · 波动、回撤与分散投资各衡量什么
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from statistics import stdev
nav = [100, 110, 105, 120, 90, 108]
returns = [b/a-1 for a,b in zip(nav,nav[1:])]
peak, drawdowns = nav[0], []
for value in nav:
    peak = max(peak,value)
    drawdowns.append(value/peak-1)
print("回撤:", [round(x*100,2) for x in drawdowns])
print(f"最大回撤 {min(drawdowns):.2%}")
print(f"单期样本标准差 {stdev(returns):.2%}")
assert min(drawdowns) == -0.25
