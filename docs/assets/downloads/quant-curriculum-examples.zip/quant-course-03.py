# -*- coding: utf-8 -*-
# 03 · 订单簿中的价格、数量与成交成本
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
asks = [(10.02, 500), (10.04, 600), (10.06, 900)]
remaining, cash, filled = 800, 0.0, 0
for price, available in asks:
    quantity = min(remaining, available)
    cash += price*quantity
    remaining -= quantity
    filled += quantity
    if remaining == 0:
        break
average = cash/filled
print(f"成交 {filled} 股，剩余 {remaining} 股")
print(f"金额 {cash:.2f} 元，均价 {average:.4f} 元")
print(f"相对中间价成本 {cash-filled*10:.2f} 元")
assert abs(average-10.0275) < 1e-12
