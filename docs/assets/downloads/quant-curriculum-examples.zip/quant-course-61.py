# -*- coding: utf-8 -*-
# 61 · 行情、信号与订单系统
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from dataclasses import dataclass,field
@dataclass
class Account:
    cash: float=10000.0
    position: int=0
    seen: set=field(default_factory=set)
    def fill(self,execution_id,side,quantity,price,fee=0.0):
        if execution_id in self.seen:return False
        if side not in (-1,1) or quantity<=0 or price<=0 or fee<0:
            raise ValueError('非法成交字段')
        self.position+=side*quantity
        self.cash-=side*quantity*price+fee
        self.seen.add(execution_id)
        return True
a=Account()
a.fill('e1',1,40,10)
a.fill('e2',1,20,10.02)
assert not a.fill('e2',1,20,10.02)
assert a.position==60 and abs(a.cash-9399.6)<1e-9
print("现金", a.cash, "持仓", a.position)
