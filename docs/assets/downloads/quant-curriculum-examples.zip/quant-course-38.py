# -*- coding: utf-8 -*-
# 38 · Alpha、Beta与主动组合
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
market = np.array([-0.02, -0.01, 0.0, 0.01, 0.02])
asset = 0.003 + 1.5 * market
x = np.column_stack([np.ones(len(market)), market])
alpha, beta = np.linalg.lstsq(x, asset, rcond=None)[0]
residual = asset - x @ np.array([alpha, beta])
print(round(alpha, 6), round(beta, 6))
print(np.max(np.abs(residual)))
weights = np.array([0.6, 0.4])
asset_beta = np.array([1.5, 0.5])
print('portfolio beta:', weights @ asset_beta)
