# -*- coding: utf-8 -*-
# 06 · 设计样本、验证样本与研究假说
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
validation = {3:[1,-1,1,1],5:[2,0,1,1],7:[3,-2,1,1]}
test = {3:[-1,1,0,0],5:[1,-1,1,1],7:[3,2,-1,2]}
mean = lambda x: sum(x)/len(x)
chosen = max(validation,key=lambda k:mean(validation[k]))
print("验证期选择窗口:",chosen)
print(f"验证均值 {mean(validation[chosen]):.2f}%")
print(f"固定规则测试均值 {mean(test[chosen]):.2f}%")
assert chosen == 5
