# -*- coding: utf-8 -*-
# 13 · 条件概率怎样表达市场信息
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from random import Random
from math import sqrt
market_up_stock_up, market_up = 28, 40
stock_up = 46
print(f"P(股票涨|市场涨)={market_up_stock_up/market_up:.2%}")
print(f"P(市场涨|股票涨)={market_up_stock_up/stock_up:.2%}")
rng = Random(2026)
for n in [20,200,2000]:
    proportion = sum(rng.random()<0.7 for _ in range(n))/n
    standard_error = sqrt(0.7*0.3/n)
    print(n,f"样本比例 {proportion:.2%}",f"理论标准误 {standard_error:.2%}")
