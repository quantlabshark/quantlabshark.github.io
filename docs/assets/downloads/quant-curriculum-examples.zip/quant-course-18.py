# -*- coding: utf-8 -*-
# 18 · 显著性、多重检验与策略筛选
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from math import comb
n, correct = 20, 15
p_one = sum(comb(n,k) for k in range(correct,n+1))/2**n
print(f"单侧p值 {p_one:.6f}，对称双侧 {2*p_one:.6f}")
for m in [1,20,100]:
    print(m,f"至少一次误报 {1-0.95**m:.2%}")
print("20次检验的Bonferroni单项阈值:",0.05/20)
assert abs(p_one-0.020694732666015625) < 1e-14
