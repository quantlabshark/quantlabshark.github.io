# -*- coding: utf-8 -*-
# 53 · 持续时间、ACD与标值点过程
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(53)
omega, alpha, beta = 0.2, 0.2, 0.7
N = 20000
psi = np.empty(N)
duration = np.empty(N)
psi[0] = omega/(1-alpha-beta)
for i in range(N):
    if i:
        psi[i] = omega + alpha*duration[i-1] + beta*psi[i-1]
    duration[i] = psi[i]*rng.exponential()
residual = duration/psi
print('间隔均值、理论均值', duration[1000:].mean(), omega/(1-alpha-beta))
print('标准化残差均值', residual.mean())
print('负对数似然', np.sum(np.log(psi)+duration/psi))
