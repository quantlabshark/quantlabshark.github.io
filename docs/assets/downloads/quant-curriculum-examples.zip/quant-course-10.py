# -*- coding: utf-8 -*-
# 10 · 用 pandas 整理日期、重复记录与缺失值
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import pandas as pd
raw = pd.DataFrame({
    "date":["2026-01-03","2026-01-01","2026-01-03","2026-01-04","2026-01-05"],
    "close":[102,100,103,None,104],"version":[1,1,2,1,1]})
raw["date"] = pd.to_datetime(raw["date"])
clean = (raw.sort_values(["date","version"])
         .drop_duplicates("date",keep="last")
         .set_index("date"))
clean["return"] = clean["close"].pct_change(fill_method=None)
print(clean)
assert clean.index.is_unique and clean.index.is_monotonic_increasing
assert clean["return"].notna().sum() == 1
