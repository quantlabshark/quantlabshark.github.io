# -*- coding: utf-8 -*-
# 26 · 分组收益、信息系数与换手
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import pandas as pd
import numpy as np

factor = pd.Series([1., 2., 3., 4., 5., 6.])
future = pd.Series([-0.02, 0.00, 0.01, -0.01, 0.02, 0.03])
rank_ic = factor.rank().corr(future.rank())
groups = pd.Series([1, 1, 2, 2, 3, 3])
means = future.groupby(groups).mean()
old = np.array([0.5, 0.5, 0.0])
new = np.array([0.0, 0.5, 0.5])
print("rank IC:", rank_ic, "group means:", means.to_dict())
print("one-way turnover:", 0.5*np.abs(new-old).sum())
assert np.isclose(rank_ic, 29/35)
assert np.isclose(means.loc[3]-means.loc[1], 0.035)
