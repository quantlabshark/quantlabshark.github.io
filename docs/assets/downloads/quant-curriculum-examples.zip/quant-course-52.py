# -*- coding: utf-8 -*-
# 52 · 傅里叶估计、跳跃与幂变差
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(52)
n, sigma = 8192, 0.20
r = rng.normal(0, sigma/np.sqrt(n), n)
t = np.arange(n)/n
N = 40
freq = np.arange(-N, N+1)
C = np.exp(-2j*np.pi*np.outer(freq,t))@r
fourier_iv = np.mean(np.abs(C)**2)
r_jump = r.copy()
r_jump[n//2] += 0.08
for label, increments in [('连续', r), ('含跳跃', r_jump)]:
    rv = increments@increments
    bv = np.pi/2*np.sum(np.abs(increments[1:])*np.abs(increments[:-1]))
    print(label, 'RV', round(rv,5), 'BV', round(bv,5))
print('频域 IV', round(float(fourier_iv),5), '真实连续 IV', sigma*sigma)
