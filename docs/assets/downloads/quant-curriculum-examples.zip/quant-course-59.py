# -*- coding: utf-8 -*-
# 59 · 智能订单路由与随机逼近
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(59)
N, h, fee, theta = 1.0, 0.01, 0.001, 0.0001
rebate = np.array([0.0002,0.0001])
Q = np.array([0.2,0.1])
under_penalty, over_penalty = 0.06, 0.03
order = np.array([0.4,0.3,0.3])
average = np.zeros(3)
for t in range(1,30001):
    flow = rng.exponential([0.7,0.5])
    fill = np.minimum(np.maximum(flow-Q,0),order[1:])
    total = order[0]+fill.sum()
    common = -(under_penalty+theta)*(total<N)+over_penalty*(total>N)
    active = (flow>Q+order[1:]).astype(float)
    gradient = np.r_[h+fee+theta+common,
                      theta+active*(-h-rebate+common)]
    step = 0.3/(1+t/100)**0.6
    order = np.clip(order-step*gradient,0,N)
    if t>15000:
        average += order/15000
flow = rng.exponential([0.7,0.5],(100000,2))
fill = np.minimum(np.maximum(flow-Q,0),average[1:])
total = average[0]+fill.sum(axis=1)
cost = ((h+fee)*average[0] - fill@(h+rebate)
        + under_penalty*np.maximum(N-total,0) + over_penalty*np.maximum(total-N,0)
        + theta*(average.sum()+np.maximum(N-total,0)))
print('市价与两处限价',average)
print('独立评估成本、全市价成本',cost.mean(),(h+fee+theta)*N)
