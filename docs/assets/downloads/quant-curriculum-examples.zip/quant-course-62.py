# -*- coding: utf-8 -*-
# 62 · 操作风险、策略风险与监控
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
def check_buy(current,pending,new,price,max_quantity,max_notional):
    if any(x<0 for x in (pending,new)) or price<=0:
        return False,'字段不合法'
    worst=current+pending+new
    if worst>max_quantity:return False,'数量超过上限'
    if worst*price>max_notional:return False,'金额超过上限'
    return True,'通过'
assert check_buy(200,100,100,10,300,10000)[0] is False
assert check_buy(100,50,50,10,300,10000)[0] is True
print(check_buy(200,100,100,10,300,10000))
print(check_buy(100,50,50,10,300,10000))
