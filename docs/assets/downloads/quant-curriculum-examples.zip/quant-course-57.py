# -*- coding: utf-8 -*-
# 57 · 多资产执行与最优配置
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
q = np.array([1.,-1.])
impact = np.diag([1.,4.])
cov = np.array([[1.,0.8],[0.8,1.]])
lam = 2.0
u = np.linalg.solve(2*impact+lam*cov, (impact+lam*cov)@q)
def objective(first):
    remaining = q-first
    return first@impact@first + remaining@impact@remaining + lam*(remaining@cov@remaining)
print('首期交易、剩余库存',u,q-u)
print('最优目标、各半目标',objective(u),objective(q/2))
assert objective(u) <= objective(q/2)
