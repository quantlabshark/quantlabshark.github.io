# -*- coding: utf-8 -*-
# 39 · 收缩估计与Black–Litterman配置
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
cov = np.array([[0.04, 0.01], [0.01, 0.09]])
tau = 0.05
prior = np.array([0.04, 0.06])
p = np.array([[1.0, -1.0]])
view = np.array([0.01])
omega = np.array([[0.0025]])
v = tau * cov
adjustment = v @ p.T @ np.linalg.solve(p @ v @ p.T + omega, view - p @ prior)
posterior = prior + adjustment
print(posterior)
print('prior spread:', float((p @ prior)[0]))
print('posterior spread:', float((p @ posterior)[0]))
