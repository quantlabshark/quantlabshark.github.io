# -*- coding: utf-8 -*-
# 07 · 运行 Python 与保存结果
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from pathlib import Path
import csv
import sys

buy_price, end_price, shares = 100.0, 105.0, 20
return_rate = end_price/buy_price-1
pnl = (end_price-buy_price)*shares
print("解释器:", sys.executable)
print("工作目录:", Path.cwd())
print(f"价格收益 {return_rate:.2%}，盈亏 {pnl:.2f} 元")
target = Path("first_experiment_result.csv")
with target.open("w", newline="", encoding="utf-8-sig") as stream:
    writer = csv.writer(stream)
    writer.writerow(["buy_price","end_price","shares","return","pnl"])
    writer.writerow([buy_price,end_price,shares,return_rate,pnl])
print("已保存:",target.resolve())
assert abs(return_rate-0.05) < 1e-12 and pnl == 100
