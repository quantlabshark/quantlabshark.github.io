# -*- coding: utf-8 -*-
# 16 · 回归直线怎样解释收益与残差
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
x = np.array([-2,-1,0,1,2],dtype=float)
y = np.array([-1.5,-1,1,2,2],dtype=float)
slope = ((x-x.mean())*(y-y.mean())).sum()/((x-x.mean())**2).sum()
intercept = y.mean()-slope*x.mean()
fitted = intercept+slope*x
residual = y-fitted
r2 = 1-(residual**2).sum()/((y-y.mean())**2).sum()
print(f"截距 {intercept:.2f} 个百分点，斜率 {slope:.2f}，R² {r2:.2%}")
print("残差:",residual)
assert np.isclose(residual.sum(),0)
assert np.isclose(np.dot(x,residual),0)
