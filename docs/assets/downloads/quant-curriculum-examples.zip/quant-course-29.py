# -*- coding: utf-8 -*-
# 29 · KNN分类与回归
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

X = np.array([[0.0], [1.0], [3.0], [4.0]])
classes = np.array([0, 0, 1, 1])
values = np.array([0.0, 0.1, 0.3, 0.4])
query = np.array([[2.8]])
classifier = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=3))
regressor = make_pipeline(StandardScaler(), KNeighborsRegressor(n_neighbors=3))
classifier.fit(X, classes)
regressor.fit(X, values)
print("class:", classifier.predict(query))
print("probability:", classifier.predict_proba(query))
print("regression:", regressor.predict(query))
assert np.isclose(classifier.predict_proba(query)[0, 1], 2/3)
assert np.isclose(regressor.predict(query)[0], 0.8/3)
