# -*- coding: utf-8 -*-
# 48 · 排队模型与扩散近似
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
arrival, service = 8.0, 10.0
rho = arrival/service
q = np.arange(200)
probability = (1-rho)*rho**q
print('概率和', probability.sum())
print('平均系统人数', (q*probability).sum())
print('平均逗留时间', 1/(service-arrival))
assert abs((q*probability).sum()-4.0) < 1e-12
