# -*- coding: utf-8 -*-
# 23 · 交易成本、成交约束与绩效指标
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np

cash = 1000.0
shares = 0
fee_rate = 0.001
buy_price, sell_price, quantity = 10.0, 10.05, 10
buy_fee = quantity * buy_price * fee_rate
cash -= quantity * buy_price + buy_fee
shares += quantity
nav_after_buy = cash + shares * buy_price
nav_middle = cash + shares * 10.10
sell_fee = shares * sell_price * fee_rate
cash += shares * sell_price - sell_fee
shares = 0
nav = np.array([1000.0, nav_after_buy, nav_middle, cash])
drawdown = nav / np.maximum.accumulate(nav) - 1
print("net pnl:", cash - 1000)
print("max drawdown:", -drawdown.min())
assert np.isclose(cash, 1000.2995)
assert shares == 0
