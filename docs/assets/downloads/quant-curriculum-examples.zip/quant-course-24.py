# -*- coding: utf-8 -*-
# 24 · 样本外回测与研究报告
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
import pandas as pd

close = np.array([100,101,102,101,100,99,100,102,104,103,102,104,
                  105,106,104,103,102,104,105,104,103,101,100,102,
                  103,105,106,104,103,101,102,104,106,105,107,108], dtype=float)
opening = np.array([100,100,101,102,101,100,99,100,102,104,103,102,
                    104,105,106,104,103,102,104,105,104,103,101,100,
                    102,103,105,106,104,103,101,102,104,106,105,107], dtype=float)

def backtest(window, start, end, cost=0.001):
    average = pd.Series(close).rolling(window).mean().to_numpy()
    cash, shares = 10000.0, 0
    nav, orders = [cash], []
    for t in range(start, end):
        target = int(t >= window and close[t-1] > average[t-1])
        price = opening[t]
        if target == 1 and shares == 0:
            quantity = int(cash / (price * (1 + cost)))
            if quantity > 0:
                cash -= quantity * price * (1 + cost)
                shares = quantity
                orders.append((t, "buy", quantity, price))
        elif target == 0 and shares > 0:
            cash += shares * price * (1 - cost)
            orders.append((t, "sell", shares, price))
            shares = 0
        assert cash >= -1e-8 and shares >= 0
        nav.append(cash + shares * opening[t+1])
    if shares:
        cash += shares * opening[end] * (1 - cost)
        orders.append((end, "sell", shares, opening[end]))
        nav[-1] = cash
        shares = 0
    assert shares == 0
    return np.array(nav), orders

def buy_and_hold(start, end, cost=0.001):
    quantity = int(10000 / (opening[start] * (1 + cost)))
    cash = 10000 - quantity * opening[start] * (1 + cost)
    nav = np.r_[10000.0, cash + quantity * opening[start+1:end+1]]
    nav[-1] -= quantity * opening[end] * cost
    return nav

def metrics(nav):
    drawdown = nav / np.maximum.accumulate(nav) - 1
    return {"return": float(nav[-1]/nav[0]-1),
            "max_drawdown": float(-drawdown.min())}

candidates = [2, 3, 4]
validation = {w: backtest(w, 18, 23)[0][-1] for w in candidates}
best = max(candidates, key=lambda w: (validation[w], -w))
nav, orders = backtest(best, 24, 35)
print("validation final wealth:", validation)
print("selected window:", best)
print("strategy:", metrics(nav))
print("buy and hold:", metrics(buy_and_hold(24, 35)))
print("cash:", metrics(np.full(12, 10000.0)))
print("orders:", orders)
for cost in [0.0, 0.001, 0.002]:
    scenario, _ = backtest(best, 24, 35, cost=cost)
    print("cost scenario:", cost, metrics(scenario))
assert len(nav) == 12
