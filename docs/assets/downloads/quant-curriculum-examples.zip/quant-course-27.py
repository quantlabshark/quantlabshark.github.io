# -*- coding: utf-8 -*-
# 27 · 标准化、相关性与主成分分析
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import make_pipeline

train = np.array([[1., 2.], [2., 4.], [3., 6.]])
pipe = make_pipeline(StandardScaler(), PCA(n_components=1))
score = pipe.fit_transform(train)
new_score = pipe.transform([[4., 8.]])
pca = pipe.named_steps["pca"]
print("loadings:", pca.components_)
print("variance ratio:", pca.explained_variance_ratio_)
print("scores:", score.ravel(), "new:", new_score.ravel())
assert np.isclose(pca.explained_variance_ratio_[0], 1.0)
assert score.shape == (3, 1)
