# -*- coding: utf-8 -*-
# 14 · 期望、方差与协方差怎样连接组合风险
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
returns = np.array([[-2,3],[0,1],[2,1],[4,3]],dtype=float)/100
prob = np.full(4,0.25)
mean = prob@returns
centered = returns-mean
covariance = (centered*prob[:,None]).T@centered
weights = np.array([0.5,0.5])
portfolio = returns@weights
variance = weights@covariance@weights
print("均值(%):",mean*100)
print("协方差矩阵:\n",covariance)
print(f"组合均值 {prob@portfolio:.2%}，波动 {np.sqrt(variance):.4%}")
assert np.isclose(variance,np.sum(prob*(portfolio-prob@portfolio)**2))
