# -*- coding: utf-8 -*-
# 17 · 价格趋势、收益平稳性与波动聚集
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(2026)
shock = rng.normal(0,1,600)
walk = np.cumsum(shock)
ar = np.zeros(len(shock))
for t in range(1,len(ar)):
    ar[t] = 0.6*ar[t-1]+shock[t]
def acf(values,lag):
    centered = values-values.mean()
    return np.dot(centered[lag:],centered[:-lag])/np.dot(centered,centered)
sample = ar[100:]
print("AR样本一阶自相关:",round(acf(sample,1),3))
print("冲击一阶自相关:",round(acf(shock[100:],1),3))
print("未来无新增冲击时的偏离:",[8*0.5**k for k in range(4)])
