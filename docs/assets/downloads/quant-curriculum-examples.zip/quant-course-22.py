# -*- coding: utf-8 -*-
# 22 · 配对价差、均值回复与季节性效应
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
entry_a,entry_b,exit_a,exit_b,hedge = 110,50,106,51,2
entry_spread = entry_a-hedge*entry_b
exit_spread = exit_a-hedge*exit_b
pnl_short_a = entry_a-exit_a
pnl_long_b = hedge*(exit_b-entry_b)
gross_exposure = entry_a+hedge*entry_b
cost = 0.5
net_pnl = pnl_short_a+pnl_long_b-cost
print("价差:",entry_spread,"→",exit_spread)
print("两腿毛盈亏:",pnl_short_a,pnl_long_b,"净盈亏:",net_pnl)
print(f"按初始总名义金额归一化 {net_pnl/gross_exposure:.4%}")
assert pnl_short_a+pnl_long_b == entry_spread-exit_spread == 6
