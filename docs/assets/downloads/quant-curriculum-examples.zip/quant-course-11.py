# -*- coding: utf-8 -*-
# 11 · 行情、财报与文本分别记录什么
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
records = [
    {"price":10.0,"shares":200},
    {"price":10.2,"shares":300},
    {"price":10.4,"shares":500},
]
volume = sum(x["shares"] for x in records)
amount = sum(x["price"]*x["shares"] for x in records)
vwap = amount/volume
profit_ttm = 90+120-80
schema = {"price":"元/股","shares":"股","amount":"元","profit_ttm":"百万元"}
print(schema)
print(f"成交量 {volume} 股，成交额 {amount:.2f} 元，均价 {vwap:.3f} 元/股")
print("TTM利润:",profit_ttm,"百万元")
assert abs(vwap-10.26) < 1e-12 and profit_ttm == 130
