# -*- coding: utf-8 -*-
# 7.6 基金风格与收益来源
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(17)
market = rng.normal(0,.04,60)
value = rng.normal(0,.03,60)
X = np.column_stack([np.ones(60),market,value])
fund = .002 + .8*market + .3*value
coef = np.linalg.lstsq(X,fund,rcond=None)[0]
print('alpha, market beta, value beta:', coef)
assert np.allclose(coef,[.002,.8,.3])
