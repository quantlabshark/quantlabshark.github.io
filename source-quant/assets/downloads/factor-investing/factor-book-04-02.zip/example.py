# -*- coding: utf-8 -*-
# 4.2 用截面回归识别因子的独立作用
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
slope = -0.0052
feature_sd = 1.02
impact = slope * feature_sd
assert abs(impact + 0.005304) < 1e-12
print(f'一个标准差的月收益影响：{impact:.4%}')
