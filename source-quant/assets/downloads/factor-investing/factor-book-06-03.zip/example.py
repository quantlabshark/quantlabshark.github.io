# -*- coding: utf-8 -*-
# 6.3 行为偏差如何影响价格与交易
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
def w(p, gamma=0.65):
    return p**gamma / (p**gamma + (1-p)**gamma)**(1/gamma)
prob = [0.5, 0.4, 0.1]
payoff = [10, 30, 100]
weights = [w(sum(prob[i:])) - w(sum(prob[i+1:])) for i in range(3)]
subjective = sum(weight * x**0.5 for weight, x in zip(weights, payoff))
assert abs(sum(weights) - 1) < 1e-12
print('决策权重：', [round(x, 4) for x in weights])
print('主观价值：', round(subjective, 4))
