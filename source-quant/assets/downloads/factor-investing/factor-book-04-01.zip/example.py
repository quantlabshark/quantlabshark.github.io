# -*- coding: utf-8 -*-
# 4.1 多因子模型的经济含义与组合构造
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
small = [0.03, 0.02, 0.01]  # 依次为高、中、低BM
big = [0.02, 0.01, 0.00]
smb = sum(small) / 3 - sum(big) / 3
hml = (small[0] + big[0] - small[2] - big[2]) / 2
assert abs(smb - 0.01) < 1e-12
assert abs(hml - 0.02) < 1e-12
print(f'SMB={smb:.2%}, HML={hml:.2%}')
