# -*- coding: utf-8 -*-
# 5.1 估值与财务质量怎样共同影响收益
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
previous = dict(assets=100, net=5, operating=8, cashflow=7,
                debt=30, current_assets=40, current_debt=25,
                sales=150, cost=105)
current = dict(assets=120, net=8, operating=11, cashflow=10,
               debt=30, current_assets=55, current_debt=25,
               sales=168, cost=109.2, issued=True)
def ratios(d):
    return dict(roa=d['net']/d['assets'], cfoa=d['cashflow']/d['assets'],
                accrual=(d['operating']-d['cashflow'])/d['assets'],
                leverage=d['debt']/d['assets'],
                liquidity=d['current_assets']/d['current_debt'],
                margin=1-d['cost']/d['sales'], turnover=d['sales']/d['assets'])
p, c = ratios(previous), ratios(current)
signals = {'ROA为正': c['roa']>0, 'ROA提高': c['roa']>p['roa'],
           '经营现金流为正': c['cfoa']>0, '应计利润为负': c['accrual']<0,
           '长期负债率下降': c['leverage']<p['leverage'],
           '流动比率提高': c['liquidity']>p['liquidity'],
           '无增发配售': not current['issued'],
           '毛利率提高': c['margin']>p['margin'],
           '资产周转率提高': c['turnover']>p['turnover']}
score = sum(signals.values())
for name, value in signals.items():
    print(name, int(value))
print('本年比率', {k: round(v, 6) for k, v in c.items()})
assert score == 6
print('F-Score =', score)
