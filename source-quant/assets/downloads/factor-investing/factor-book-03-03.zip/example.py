# -*- coding: utf-8 -*-
# 公司规模与股票收益：小市值差异怎样计算
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
small_returns = [0.04, 0.02]
big_returns = [0.01, -0.01]
big_caps = [900, 100]
small = sum(small_returns) / 2
big_equal = sum(big_returns) / 2
big_value = sum(r*m for r, m in zip(big_returns, big_caps)) / sum(big_caps)
print(f"等权价差 {small-big_equal:.2%}，大组市值加权后价差 {small-big_value:.2%}")
assert abs((small-big_value)-0.022) < 1e-12
