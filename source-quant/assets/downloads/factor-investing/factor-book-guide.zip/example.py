# -*- coding: utf-8 -*-
# 收益、风险与因子：阅读所需的基础知识
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np

returns = np.array([0.01, -0.01, 0.03])
mean = returns.mean()
vol = returns.std(ddof=1)
print("均值、波动率、均值标准误:", mean, vol, vol / np.sqrt(3))
print("先涨后跌累计收益:", np.prod(1 + np.array([0.1, -0.1])) - 1)

factor = np.array([-0.02, -0.01, 0.0, 0.01, 0.02])
asset = 0.002 + 1.2 * factor
x = np.column_stack([np.ones(factor.size), factor])
alpha, beta = np.linalg.lstsq(x, asset, rcond=None)[0]
assert np.allclose([alpha, beta], [0.002, 1.2])
print("截距、斜率:", alpha, beta)

w = np.array([0.5, 0.5])
cov = np.diag([0.2**2, 0.2**2])
print("不相关时的组合波动率:", np.sqrt(w @ cov @ w))
