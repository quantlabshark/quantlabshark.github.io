from pathlib import Path
import argparse, json
import calculations

LESSON = 'guo-book-07-01'
FIGURES = ['inventory-quotes']

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--figures', action='store_true', help='Generate the lesson diagrams')
    args=parser.parse_args()
    output=Path(__file__).resolve().parent/'output'
    output.mkdir(exist_ok=True)
    result=calculations.CASES[LESSON]()
    text=json.dumps(result,ensure_ascii=False,indent=2)
    (output/'results.json').write_text(text,encoding='utf-8')
    print(text)
    if args.figures:
        import diagrams
        for name in FIGURES:
            fig=diagrams.PLOTS[name]()
            fig.savefig(output/(name+'.svg'),metadata={'Date':None})
            fig.savefig(output/(name+'.png'),dpi=180)
            diagrams.plt.close(fig)
        print('Diagrams:',len(FIGURES))

if __name__=='__main__': main()
