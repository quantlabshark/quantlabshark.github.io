# 傅里叶估计与瞬时波动率：补充算例

使用 Python 3.10 或更新版本。打开终端并进入解压后的目录：

    python -m pip install -r requirements.txt
    python example.py

计算结果保存到 output/results.json，也会打印到终端。expected-results.json 是文章对应的核算结果，可逐项对照。

example.py 指定本节的计算与图像；calculations.py 保存计算步骤和数值断言，diagrams.py 保存绘图方法。参数为教学算例，不需要行情账号或网络数据。
