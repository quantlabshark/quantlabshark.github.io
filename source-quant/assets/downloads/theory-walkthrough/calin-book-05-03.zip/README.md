# 伊藤等距、鞅性质与连续版本：补充算例

使用 Python 3.10 或更新版本。打开终端并进入解压后的目录：

    python -m pip install -r requirements.txt
    python example.py

计算结果保存到 output/results.json，也会打印到终端。expected-results.json 是文章对应的核算结果，可逐项对照。

生成本节示意图：

    python example.py --figures

图像保存到 output，含 SVG 和 PNG。Windows 使用 Microsoft YaHei 字体；其他系统可在 diagrams.py 开头将字体改为已安装的中文字体。

example.py 指定本节的计算与图像；calculations.py 保存计算步骤和数值断言，diagrams.py 保存绘图方法。参数为教学算例，不需要行情账号或网络数据。
