# -*- coding: utf-8 -*-
# 2.2 大额订单、成交数量与信息暴露
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
trades = [(1000, 20.00), (2000, 20.02), (1000, 20.05)]
quantity = sum(q for q, p in trades)
cash = sum(q * p for q, p in trades)
average = cash / quantity
print(f"成交数量：{quantity} 股；成交均价：{average:.4f} 元")
assert abs(average - 20.0225) < 1e-10
