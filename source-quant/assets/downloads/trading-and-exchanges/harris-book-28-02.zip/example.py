# -*- coding: utf-8 -*-
# 28.2 历史崩盘中的共同机制与不同原因
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟反馈模型；数值用于说明机制，不复现1987年行情
def total_decline(initial, feedback, rounds=80):
    decline = initial
    cumulative = 0.0
    for _ in range(rounds):
        cumulative += decline
        decline *= feedback
    return cumulative

for r in [0.0, 0.3, 0.6, 0.8]:
    value = total_decline(0.01, r)
    theoretical = 0.01 / (1 - r)
    print('反馈强度', r, '累计跌幅', round(value, 6))
    assert abs(value - theoretical) < 1e-8
