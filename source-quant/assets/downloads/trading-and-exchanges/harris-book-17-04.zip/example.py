# -*- coding: utf-8 -*-
# 17.4 套利如何连接市场与转移流动性
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
eur_usd = 1.10   # 每欧元对应美元
usd_jpy = 150.0  # 每美元对应日元
implied_eur_jpy = eur_usd * usd_jpy
print(round(implied_eur_jpy, 2))
assert abs(implied_eur_jpy - 165.0) < 1e-9
