# -*- coding: utf-8 -*-
# 4.1 市价单、限价单与订单簿
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
asks = [(10.04, 100), (10.05, 200), (10.08, 500)]
remaining = 400
cost = 0.0
fills = []
for price, available in asks:
    filled = min(remaining, available)
    if filled:
        fills.append((price, filled))
        cost += price * filled
        remaining -= filled
    if remaining == 0:
        break
assert remaining == 0
print("成交明细：", fills)
print(f"成交均价：{cost / 400:.4f} 元")
assert abs(cost / 400 - 10.055) < 1e-10
