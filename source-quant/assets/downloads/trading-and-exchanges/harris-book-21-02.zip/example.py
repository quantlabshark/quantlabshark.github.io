# -*- coding: utf-8 -*-
# 21.2 实现缺口与未成交机会成本
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟部分成交数据；仅使用 Python 标准库
def shortfall(side, target, decision, fills, terminal, fees):
    done = sum(q for q, _ in fills)
    assert side in (-1, 1) and 0 <= done <= target
    execution = side * sum(q * (p - decision) for q, p in fills)
    missed = side * (target - done) * (terminal - decision)
    total = execution + missed + fees
    return execution, missed, total, total / (target * decision) * 10000

buy = shortfall(1, 1000, 10, [(400, 10.02), (300, 10.05)], 10.10, 5)
sell = shortfall(-1, 1000, 10, [(400, 9.98), (300, 9.95)], 9.90, 5)
for name, result in [('买入', buy), ('卖出', sell)]:
    print(name, tuple(round(x, 4) for x in result))
    assert abs(result[2] - 58) < 1e-9
