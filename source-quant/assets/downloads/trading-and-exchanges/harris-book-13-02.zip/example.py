# -*- coding: utf-8 -*-
# 13.2 库存控制与两类持仓风险
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
value, target, pressure, half_spread = 50.0, 0, 0.001, 0.05
for inventory in (-100, 0, 100):
    midpoint = value - pressure * (inventory - target)
    bid, ask = midpoint - half_spread, midpoint + half_spread
    print(inventory, round(bid, 3), round(ask, 3))
