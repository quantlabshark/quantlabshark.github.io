from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

def load_market(directory):
    directory=Path(directory)
    codes=pd.read_csv(directory/'universe-20180102.csv').ts_code.tolist()
    calendar=pd.to_datetime(pd.read_csv(directory/'000300.SH-index.csv',dtype={'trade_date':str}).trade_date).sort_values().unique()
    series=[]
    for code in codes:
        d=pd.read_csv(directory/(code+'-daily.csv'),dtype={'trade_date':str})
        a=pd.read_csv(directory/(code+'-adj_factor.csv'),dtype={'trade_date':str})
        d=d.merge(a,on=['ts_code','trade_date'],validate='one_to_one').sort_values('trade_date')
        adjustment=d.adj_factor/d.adj_factor.iloc[0]
        d['adj_close']=d.close*adjustment;d['adj_open']=d.open*adjustment
        d['cash_amount']=d.amount*1000
        d['date']=pd.to_datetime(d.trade_date)
        series.append(d)
    long=pd.concat(series,ignore_index=True)
    return {k:long.pivot(index='date',columns='ts_code',values=k).reindex(index=calendar,columns=codes) for k in ['adj_close','adj_open','cash_amount']}

def simulate_panel(seed=20261018,T=1500,N=60):
    rng=np.random.default_rng(seed);dates=pd.bdate_range('2018-01-03',periods=T)
    returns=rng.normal(0,.009,(T,1))+rng.normal(0,.018,(T,N))
    close=20*np.exp(np.cumsum(returns,axis=0))
    op=close*np.exp(rng.normal(0,.003,(T,N)))
    return {k:pd.DataFrame(v,index=dates) for k,v in {'adj_close':close,'adj_open':op,'cash_amount':np.exp(rng.normal(np.log(2e8),.8,(T,N)))}.items()}

def signals(panel):
    p=panel['adj_close'];ret=p.pct_change(fill_method=None)
    return {'momentum':p.shift(5)/p.shift(65)-1,
            'reversal':-(p/p.shift(5)-1),
            'lowvol':-ret.rolling(20,min_periods=20).std(ddof=1),
            'liquidity':-(ret.abs()/panel['cash_amount'].where(panel['cash_amount']>0)).rolling(20,min_periods=20).mean()*1e8}

def daily_ic(x,y,minimum=30):
    valid=x.notna()&y.notna();a=x.where(valid).rank(axis=1,method='average');b=y.where(valid).rank(axis=1,method='average')
    return a.corrwith(b,axis=1).where(valid.sum(axis=1)>=minimum)

def hac_mean(values,lags):
    a=np.asarray(values,dtype=float)
    if not np.isfinite(a).all():raise ValueError('HAC requires a consecutive, nonmissing time sequence')
    T=len(a);u=a-a.mean();longvar=u@u/T
    for k in range(1,min(lags,T-1)+1):longvar+=2*(1-k/(lags+1))*(u[k:]@u[:-k])/T
    se=np.sqrt(max(longvar,0)/T)
    return {'days':T,'mean':float(a.mean()),'se':float(se),'t':float(a.mean()/se) if se else None,'lags':lags}

parser=argparse.ArgumentParser();parser.add_argument('--market-dir');args=parser.parse_args()
p=load_market(args.market_dir) if args.market_dir else simulate_panel();s=signals(p)
import matplotlib.dates as mdates
fig,axs=plt.subplots(2,2,figsize=(10,6))
for ax,(name,v),color in zip(axs.flat,s.items(),C):
    a=v.iloc[:,0].dropna().iloc[-180:];ax.plot(a.index,a,color=color);ax.set(xlabel='Date',ylabel=name)
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2));ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
save(fig,'four-price-signals.svg')
# Check exact window direction and future independence.
q={k:v.copy() for k,v in p.items()};cut=len(q['adj_close'])//2
for v in q.values():v.iloc[cut+1:]*=1.7
ss=signals(q)
for k in s:pd.testing.assert_frame_equal(s[k].iloc[:cut+1],ss[k].iloc[:cut+1])
assert np.isclose((121/110-1),.1)
emit({'data':'actual fixed starting sample' if args.market_dir else 'simulated','future_perturbation_test':True,'factor_names':list(s),'momentum_example':.1,'earnings_yield_example':12/240,'roe_example':12/100})
