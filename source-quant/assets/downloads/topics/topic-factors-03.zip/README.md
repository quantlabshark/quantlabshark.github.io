# topic-factors-03

本文件夹可独立运行。安装 requirements.txt 中的依赖后，执行 python topic-factors-03.py。结果写入当前目录，包括 results.json 与 SVG 图片。默认使用注明随机种子的模拟数据或题面给定数值。

如已有获授权的本地行情文件，可使用 --market-dir 数据目录。目录包含 universe-20180102.csv、000300.SH-index.csv、各代码-daily.csv 和各代码-adj_factor.csv。行情列为 ts_code,trade_date,open,close,amount；复权列为 ts_code,trade_date,adj_factor；日期为 YYYYMMDD。amount 原单位为千元。股票池形成于 2018-01-02，统计评价从 2018-01-03 开始。脚本不连接服务、不含令牌、不附带市场原始数据。
