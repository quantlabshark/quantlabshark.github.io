"""Two paths with equal displacement and different path efficiency."""
from timing_common import *
a=output_parser();smooth=np.linspace(100,110,21);zig=np.array([100+(.5*i)+2*((-1)**i) for i in range(21)],float);zig[0]=100;zig[-1]=110
eff=lambda p:abs(p[-1]-p[0])/np.abs(np.diff(p)).sum()
fig,ax=plt.subplots(figsize=(8,3.7));ax.plot(smooth,label=f'Smooth: efficiency {eff(smooth):.2f}',color=COLORS[0]);ax.plot(zig,label=f'Uneven: efficiency {eff(zig):.2f}',color=COLORS[1]);ax.set(xlabel='Observation',ylabel='Price');ax.legend(frameon=False);save(fig,a.output_dir,'trend-path-efficiency')
write(a.output_dir,'calculation-03.json',{'synthetic':True,'smooth_efficiency':eff(smooth),'uneven_efficiency':eff(zig),'same_return':.1})
