"""Synthetic MA and channel signals; no return claims."""
from timing_common import *
a=output_parser();rng=np.random.default_rng(703);n=340;r=np.r_[rng.normal(.002,.007,150),rng.normal(-.0015,.007,90),rng.normal(.002,.007,100)];p=pd.Series(100*np.exp(np.cumsum(r)));ma=p.rolling(60).mean();hi=p.shift(1).rolling(60).max();lo=p.shift(1).rolling(20).min();state=[];held=0
for i in p.index:
    if pd.notna(hi[i]) and p[i]>hi[i]:held=1
    elif pd.notna(lo[i]) and p[i]<lo[i]:held=0
    state.append(held)
fig,axs=plt.subplots(2,1,figsize=(8,4.7),sharex=True,gridspec_kw={'height_ratios':[3,1]});axs[0].plot(p,color=COLORS[0],label='Synthetic close');axs[0].plot(ma,color=COLORS[1],label='60-day mean');axs[0].plot(hi,color=COLORS[2],lw=.9,alpha=.8,label='Previous 60-day high');axs[0].legend(frameon=False,ncol=3,fontsize=8);axs[0].set_ylabel('Price');axs[1].step(p.index,state,color=COLORS[0],where='post');axs[1].set(xlabel='Observation',ylabel='Channel state',yticks=[0,1]);save(fig,a.output_dir,'moving-average-breakout')
assert not (p>p.rolling(60).max()).any()
write(a.output_dir,'calculation-02.json',{'synthetic':True,'channel_state_changes':int(np.abs(np.diff(state)).sum()),'same_day_inclusive_strict_breakout_impossible':True})
