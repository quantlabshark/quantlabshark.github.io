from pathlib import Path
from teaching_cases import run
if __name__ == '__main__':
    run(3, Path(__file__).resolve().parent / 'output')
