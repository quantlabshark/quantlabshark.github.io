"""Ten deterministic, offline teaching cases. No downloaded models or API keys.
Run: python teaching_cases.py --lesson 1 --out output
"""
from pathlib import Path
import argparse,json,math
from functools import lru_cache
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.special import expit,softmax
from scipy.stats import spearmanr,norm
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import Ridge

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.figsize':(7.4,3.8),'axes.grid':True,'grid.alpha':.18,'savefig.bbox':'tight'})
COLORS=['#2b7a78','#a66b2b','#6574a8','#c15e6d']

def run(k,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);r={};fig,ax=plt.subplots()
    if k==1:
        t=np.arange(6);prices=np.array([100,101,100.5,102,101.2,103.])
        gross=102/100.5-1;net=(102*(1-.001))/(100.5*(1+.001))-1
        ax.plot(t,prices,'o-',color=COLORS[0]);ax.axvspan(2,3,color=COLORS[0],alpha=.12)
        ax.set(xlabel='Trading-session index',ylabel='Adjusted open price');ax.set_xticks(t)
        r={'entry':100.5,'exit':102.,'gross_return':gross,'net_return_10bp_each_side':net}
        assert abs(gross-1/67)<1e-12
    elif k==2:
        x=np.array([-1.,0,1]);y=np.array([-1.,.2,.8]);a=np.logspace(-3,2,120)
        betas=np.dot(x,y)/(np.dot(x,x)+a)
        ax.semilogx(a,betas,color=COLORS[0]);ax.set(xlabel='Ridge penalty',ylabel='Slope')
        beta=float(x@y/(x@x+2));r={'ols':float(x@y/(x@x)),'ridge_alpha2':beta,'intercept':float(y.mean()),'prediction_x2':float(2*beta+y.mean())}
        assert np.isclose(beta,.45)
    elif k==3:
        x=np.linspace(-2,2,120);rng=np.random.default_rng(13);y=np.where(x<0,-1,1)+rng.normal(0,.15,len(x))
        ax.scatter(x,y,s=9,alpha=.35,color=COLORS[2])
        for dep,c in [(1,COLORS[0]),(4,COLORS[1])]:
            tree=DecisionTreeRegressor(max_depth=dep,min_samples_leaf=8,random_state=0).fit(x[:,None],y)
            ax.plot(x,tree.predict(x[:,None]),color=c,label=f'Depth {dep}')
        ax.legend(frameon=False);ax.set(xlabel='Feature',ylabel='Response (synthetic)')
        residual=np.array([-2.,-1,1,2]);G=-residual.sum();H=4;GL=-residual[:2].sum();GR=-residual[2:].sum();lam=1.
        gain=.5*(GL**2/(2+lam)+GR**2/(2+lam)-G**2/(H+lam))
        r={'left_weight':float(-GL/3),'right_weight':float(-GR/3),'gain_before_leaf_penalty':float(gain)};assert gain==3
    elif k==4:
        rng=np.random.default_rng(18);q=rng.normal(size=(8,3));K=rng.normal(size=(8,3));v=rng.normal(size=(8,2))
        scores=q@K.T/np.sqrt(3);mask=np.triu(np.ones((8,8),bool),1);scores[mask]=-np.inf
        w=softmax(scores,axis=1);im=ax.imshow(w,vmin=0,vmax=1,cmap='viridis',origin='upper');fig.colorbar(im,ax=ax,label='Attention weight')
        ax.grid(False);ax.set(xlabel='Input position',ylabel='Prediction position')
        assert np.allclose(w.sum(axis=1),1) and np.all(w[mask]==0)
        z=np.array([.3,-.2,.1]);u=.7;b=.4;target=.2
        def forward(bval):
            h=0.;hs=[h]
            for xx in z:h=np.tanh(u*xx+bval*h);hs.append(h)
            return .5*(h-target)**2,np.array(hs)
        loss,hs=forward(b);dh=hs[-1]-target;grad=0.
        for j in range(len(z)-1,-1,-1):
            da=dh*(1-hs[j+1]**2);grad+=da*hs[j];dh=da*b
        eps=1e-6;fd=(forward(b+eps)[0]-forward(b-eps)[0])/(2*eps)
        assert np.isclose(grad,fd,rtol=1e-7,atol=1e-10)
        r={'attention_two_values':softmax([0.,math.log(3)]).tolist(),'rnn_hidden':hs.tolist(),'rnn_loss':float(loss),'rnn_recurrent_gradient':float(grad),'finite_difference':float(fd)}
    elif k==5:
        scores=np.array([.02,.01,-.01,0]);future=np.array([.01,.03,-.02,0]);rank_s=np.argsort(np.argsort(scores))+1;rank_y=np.argsort(np.argsort(future))+1
        ax.scatter(rank_s,rank_y,s=90,color=COLORS[0]);ax.plot([.7,4.3],[.7,4.3],ls='--',color='gray',lw=1)
        for j in range(4):ax.annotate(chr(65+j),(rank_s[j]+.07,rank_y[j]+.04))
        ax.set(xlabel='Predicted rank',ylabel='Realized rank',xticks=range(1,5),yticks=range(1,5))
        loss=float(np.logaddexp(0,-(.01-.02)/.01));grad=float(-expit(-(.01-.02)/.01)/.01)
        r={'rank_ic':float(spearmanr(scores,future).statistic),'pair_loss_B_above_A_temperature_001':loss,'pair_derivative_B':grad};assert np.isclose(r['rank_ic'],.8)
    elif k==6:
        # Handmade examples demonstrate scores; they do not benchmark a language model.
        logits=np.array([1.2,.2,-.8]);p=softmax(logits);sent=p[0]-p[2]
        probs=np.array([[.8,.15,.05],[.1,.2,.7],[.1,.8,.1]])
        bottom=np.zeros(3)
        for j,label in enumerate(['Positive','Neutral','Negative']):ax.bar(np.arange(3),probs[:,j],bottom=bottom,color=COLORS[j],label=label);bottom+=probs[:,j]
        ax.set(xlabel='Hand-specified example',ylabel='Probability',xticks=range(3),xticklabels=['Growth','Loss','Unchanged'],ylim=(0,1));ax.legend(frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(.5,1.16))
        revenue=120.;consensus=115.;last=100.
        r={'softmax':p.tolist(),'sentiment':float(sent),'growth':revenue/last-1,'surprise':revenue/consensus-1,'probabilities_are_hand_specified':True}
        assert np.isclose(p.sum(),1)
    elif k==7:
        rng=np.random.default_rng(7);n=250;m=1000;y=rng.normal(size=n);z=rng.normal(size=(n,m));yv=rng.normal(size=n);zv=rng.normal(size=(n,m))
        yc=(y-y.mean())/np.linalg.norm(y-y.mean());zc=z-z.mean(0);zc/=np.linalg.norm(zc,axis=0)
        train=yc@zc;yvc=(yv-yv.mean())/np.linalg.norm(yv-yv.mean());zvc=zv-zv.mean(0);zvc/=np.linalg.norm(zvc,axis=0);val=yvc@zvc
        order=np.argsort(train)[::-1][:40];ax.plot(np.arange(1,41),train[order],color=COLORS[0],label='Selection sample');ax.scatter(np.arange(1,41),val[order],s=15,color=COLORS[1],label='New sample');ax.axhline(0,color='gray',lw=.7)
        ax.legend(frameon=False);ax.set(xlabel='Rank among 1,000 random candidates',ylabel='Correlation (synthetic)')
        R=np.array([[1,.8],[.8,1]]);b=np.array([.1,.12]);w=np.linalg.solve(R,b)
        r={'random_best_train_correlation':float(train[order[0]]),'same_candidate_validation_correlation':float(val[order[0]]),'two_factor_weights':w.tolist(),'single_factor_explained_variance':.1**2,'combined_explained_variance':float(b@w),'best_random_index':int(order[0])}
        assert np.allclose(R@w,b)
    elif k==8:
        eta=np.array([1.,3.]);P=np.array([[.75,.25],[.25,.75]]);T=4;Q=12;lam=.1
        policy={}
        @lru_cache(None)
        def V(t,q,s):
            if t==T:return 0. if q==0 else np.inf
            costs=[]
            for a in range(q+1):
                rem=q-a
                future=0. if t==T-1 and rem==0 else sum(P[s,sp]*V(t+1,rem,sp) for sp in range(2))
                costs.append(eta[s]*a*a+lam*rem*rem+future)
            a=int(np.argmin(costs));policy[t,q,s]=a;return float(costs[a])
        cost=V(0,Q,0)
        @lru_cache(None)
        def twap(t,q,s):
            if t==T:return 0.
            a=int(math.ceil(q/(T-t)));rem=q-a
            return float(eta[s]*a*a+lam*rem*rem+(sum(P[s,sp]*twap(t+1,rem,sp) for sp in range(2)) if t<T-1 else 0))
        q=Q;path=[q]
        for t in range(T):q-=policy[t,q,0];path.append(q)
        ax.step(range(T+1),path,where='post',color=COLORS[0],label='Optimal, liquid path');ax.plot(range(T+1),[12,9,6,3,0],'o--',color=COLORS[1],label='Equal slices')
        ax.set(xlabel='Execution step',ylabel='Shares remaining (units)');ax.legend(frameon=False)
        r={'optimal_expected_cost':cost,'equal_slice_expected_cost':twap(0,Q,0),'first_action_liquid':policy[0,Q,0],'first_action_illiquid':V(0,Q,1) and policy[0,Q,1],'deterministic_two_step_Q10_eta1_3':{'a1':7.5,'a2':2.5,'cost':75.}}
        assert cost<=twap(0,Q,0) and q==0
    elif k==9:
        days=np.arange(1,21);label_start=days+1;label_end=days+5;cut=13;eligible=(days<cut)&(label_end<cut)
        colors=np.where(days>=cut,COLORS[1],np.where(eligible,COLORS[0],COLORS[3]))
        for d,l,h,c in zip(days,label_start,label_end,colors):ax.plot([l,h],[d,d],color=c,lw=3)
        ax.axvline(cut,color='black',ls='--',lw=1);ax.set(xlabel='Trading-day index of label',ylabel='Feature date index')
        r={'cutoff':cut,'retained_training_feature_dates':days[eligible].tolist(),'purged_feature_dates':days[(days<cut)&~eligible].tolist(),'all_training_labels_known_before_cutoff':bool(np.all(label_end[eligible]<cut))}
        assert r['purged_feature_dates']==[8,9,10,11,12]
    elif k==10:
        rng=np.random.default_rng(10);t=np.arange(400);x=rng.normal(size=400);beta=np.where(t<200,.8,-.2);y=beta*x+rng.normal(0,.5,400);pred=.8*x;err=(y-pred)**2
        smoothed=np.convolve(err,np.ones(30)/30,mode='valid');ax.plot(np.arange(29,400),smoothed,color=COLORS[0]);ax.axvline(200,color=COLORS[1],ls='--');ax.set(xlabel='Observation index',ylabel='30-observation mean squared error')
        base=np.array([.5,.5]);new=np.array([.25,.75]);psi=float(np.sum((new-base)*np.log(new/base)))
        r={'psi_two_bins':psi,'mse_first_regime':float(err[:200].mean()),'mse_second_regime':float(err[200:].mean()),'population_mse_first':.25,'population_mse_second':1.25,'feature_distribution_unchanged_by_construction':True}
        assert np.isclose(psi,.25*np.log(3))
    else:raise ValueError(k)
    fig.savefig(out/f'topic-ai-{k:02d}.svg');fig.savefig(out/f'topic-ai-{k:02d}.png',dpi=130);plt.close(fig)
    (out/f'topic-ai-{k:02d}-results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(r,ensure_ascii=False));return r

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--lesson',type=int,required=True);ap.add_argument('--out',default='output');a=ap.parse_args();run(a.lesson,a.out)
