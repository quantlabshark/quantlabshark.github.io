"""Plot aggregate historical results; no raw market data required."""
from pathlib import Path
import argparse
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np

def run(results,out):
    results=Path(results);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.figsize':(7.4,3.8),'savefig.bbox':'tight'})
    d=pd.read_csv(results/'yearly-metrics.csv')
    fig,ax=plt.subplots()
    for offset,model,color in [(-.17,'ridge','#2b7a78'),(.17,'tree','#a66b2b')]:
        g=d[d.model==model];ax.bar(np.arange(3)+offset,g.mean_daily_rank_ic,width=.32,label=model.capitalize(),color=color)
    ax.axhline(0,lw=.7,color='gray');ax.set(xticks=range(3),xticklabels=['2023','2024','2025'],ylabel='Mean daily Rank IC',xlabel='Frozen test year');ax.legend(frameon=False);ax.grid(axis='y',alpha=.18)
    fig.savefig(out/'historical-yearly-rank-ic.svg');fig.savefig(out/'historical-yearly-rank-ic.png',dpi=130);plt.close(fig)
    f=pd.read_csv(results/'feature-drift.csv');fig,ax=plt.subplots()
    for name,color in [('vol20','#2b7a78'),('log_amount_ratio','#a66b2b')]:ax.plot(pd.to_datetime(f.month),f[name],color=color,label=name)
    ax.axhline(0,lw=.7,color='gray');ax.set(xlabel='Frozen test month',ylabel='Mean shift / training standard deviation');ax.legend(frameon=False);ax.grid(alpha=.18)
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=6));ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    fig.savefig(out/'historical-feature-shift.svg');fig.savefig(out/'historical-feature-shift.png',dpi=130);plt.close(fig)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--results',default='historical_results');ap.add_argument('--out',default='output');a=ap.parse_args();run(a.results,a.out)
