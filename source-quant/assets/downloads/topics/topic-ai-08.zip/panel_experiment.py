"""Offline teaching experiment. Default: synthetic data; --market: local licensed CSVs.
No API calls and no credentials. Python 3.11+, numpy pandas scipy scikit-learn matplotlib.
"""
from pathlib import Path
import argparse, json, platform
import numpy as np
import pandas as pd
import sklearn
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_squared_error
from scipy.stats import spearmanr
from threadpoolctl import threadpool_limits

FEATURES=['ret1','ret5','ret20','vol20','log_amount_ratio','range','gap']

def read_panel(root):
    root=Path(root)
    master=pd.read_csv(root/'universe-20180102.csv')
    frames=[]
    for code in master.ts_code:
        p=pd.read_csv(root/f'{code}-daily.csv',dtype={'trade_date':str})
        a=pd.read_csv(root/f'{code}-adj_factor.csv',dtype={'trade_date':str})
        p=p.merge(a[['trade_date','adj_factor']],on='trade_date',validate='one_to_one')
        p['date']=pd.to_datetime(p.trade_date)
        p=p.set_index('date').sort_index()
        frames.append((code,p))
    calendar=pd.DatetimeIndex(sorted(set().union(*(set(p.index) for _,p in frames))))
    calendar=calendar[(calendar>='2018-01-02')&(calendar<='2025-12-31')]
    chunks=[]
    for code,p in frames:
        p=p.reindex(calendar)
        c=p.close*p.adj_factor;o=p.open*p.adj_factor
        r=c.pct_change(fill_method=None)
        x=pd.DataFrame(index=calendar)
        x['ret1']=r;x['ret5']=c/c.shift(5)-1;x['ret20']=c/c.shift(20)-1
        x['vol20']=r.rolling(20,min_periods=20).std(ddof=1)
        x['log_amount_ratio']=np.log(p.amount/p.amount.rolling(20,min_periods=20).mean())
        x['range']=(p.high-p.low)*p.adj_factor/c.shift(1)
        x['gap']=o/c.shift(1)-1
        x['y']=o.shift(-2)/o.shift(-1)-1
        x['label_start']=pd.Series(calendar,index=calendar).shift(-1)
        x['label_end']=pd.Series(calendar,index=calendar).shift(-2)
        x['ticker']=code
        chunks.append(x.reset_index(names='date'))
    panel=pd.concat(chunks,ignore_index=True).replace([np.inf,-np.inf],np.nan)
    panel=panel.dropna(subset=FEATURES+['y','label_end']).sort_values(['date','ticker']).reset_index(drop=True)
    return panel,{'kind':'historical','formation_date':'2018-01-02','selection':'2018-01-02 amount top60 among Shanghai/Shenzhen main-board stocks listed before 2015-01-01; fixed universe, historical delistings retained where available','sample':'2018-01-02 to 2025-12-31','provider':'Tushare Pro local snapshot','adjustment':'ratios of price times daily adjustment factor; no fill across missing trading dates','raw_data_packaged':False}

def synthetic_panel():
    rng=np.random.default_rng(20261018);dates=pd.bdate_range('2018-01-02','2025-12-31');n=len(dates);m=30
    x=rng.normal(size=(n,m,len(FEATURES)));common=rng.normal(0,.008,(n,1))
    y=.002*x[:,:,0]-.001*x[:,:,2]+.002*(x[:,:,1]*x[:,:,4])+common+rng.normal(0,.018,(n,m))
    p=pd.DataFrame(x.reshape(-1,len(FEATURES)),columns=FEATURES)
    p['y']=y.ravel();p['date']=np.repeat(dates,m);p['ticker']=np.tile([f'SIM{i:02d}' for i in range(m)],n)
    p['label_start']=np.repeat(dates.to_series().shift(-1).values,m);p['label_end']=np.repeat(dates.to_series().shift(-2).values,m)
    return p.dropna(),{'kind':'synthetic','seed':20261018,'stocks':m,'note':'Artificial predictable data, not market returns'}

def daily_scores(frame,pred):
    q=frame[['date','y']].copy();q['pred']=pred
    out=[]
    for date,g in q.groupby('date'):
        if len(g)<5 or g.pred.nunique()<2 or g.y.nunique()<2:continue
        out.append({'date':date,'rank_ic':float(spearmanr(g.pred,g.y).statistic),'n':len(g)})
    return pd.DataFrame(out)

def run(panel,metadata,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    train=panel[(panel.date<'2022-01-01')&(panel.label_end<'2022-01-01')]
    val=panel[(panel.date>='2022-01-01')&(panel.date<'2023-01-01')&(panel.label_end<'2023-01-01')]
    test=panel[(panel.date>='2023-01-01')&(panel.label_end<='2025-12-31')]
    fit=panel[(panel.date<'2023-01-01')&(panel.label_end<'2023-01-01')]
    candidates=[]
    for alpha in [10.,1000.,100000.]:candidates.append((f'ridge_{alpha:g}',make_pipeline(StandardScaler(),Ridge(alpha=alpha))))
    for leaves in [7,15]:candidates.append((f'tree_{leaves}',HistGradientBoostingRegressor(max_leaf_nodes=leaves,max_iter=100,learning_rate=.05,min_samples_leaf=300,l2_regularization=10,early_stopping=False,random_state=17)))
    validation={};models={}
    for name,model in candidates:
        model.fit(train[FEATURES],train.y);validation[name]=mean_squared_error(val.y,model.predict(val[FEATURES]));models[name]=model
    picked={family:min((n for n in models if n.startswith(family)),key=validation.get) for family in ['ridge','tree']}
    pred={'zero':np.zeros(len(test)),'training_mean':np.full(len(test),float(fit.y.mean()))}
    for family,name in picked.items():
        models[name].fit(fit[FEATURES],fit.y);pred[family]=models[name].predict(test[FEATURES])
    metrics={};daily=[]
    denom=float(np.mean(test.y.to_numpy()**2))
    for name,p in pred.items():
        mse=mean_squared_error(test.y,p);d=daily_scores(test,p)
        metrics[name]={'rmse_bp':float(np.sqrt(mse)*10000),'r2_zero':float(1-mse/denom),'mean_daily_rank_ic':float(d.rank_ic.mean()) if len(d) else None}
        if len(d):d['model']=name;daily.append(d)
    daily=pd.concat(daily,ignore_index=True);daily.to_csv(out/'daily-rank-ic.csv',index=False)
    yearly=[]
    for year,idx in test.groupby(test.date.dt.year).groups.items():
        mask=test.index.isin(idx);y=test.y.to_numpy()[mask]
        for name,p in pred.items():
            dd=daily[(pd.to_datetime(daily.date).dt.year==year)&(daily.model==name)]
            yearly.append({'year':int(year),'model':name,'rows':int(mask.sum()),'rmse_bp':float(np.sqrt(np.mean((y-p[mask])**2))*10000),'r2_zero':float(1-np.mean((y-p[mask])**2)/np.mean(y*y)),'mean_daily_rank_ic':float(dd.rank_ic.mean()) if len(dd) else None})
    pd.DataFrame(yearly).to_csv(out/'yearly-metrics.csv',index=False)
    # Auditable aggregate drift: training mean/scale; observations remain private.
    mu=fit[FEATURES].mean();sd=fit[FEATURES].std(ddof=0)
    drift=[]
    for month,g in test.groupby(test.date.dt.to_period('M')):
        z=((g[FEATURES].mean()-mu)/sd)
        drift.append({'month':str(month),**{c:float(z[c]) for c in FEATURES}})
    pd.DataFrame(drift).to_csv(out/'feature-drift.csv',index=False)
    coef=models[picked['ridge']].named_steps['ridge'].coef_
    result={'data':metadata,'features':FEATURES,'label':'Adjusted open at t+2 / adjusted open at t+1 - 1; features after close t','split':{n:{'rows':len(g),'dates':g.date.nunique(),'first':str(g.date.min().date()),'last':str(g.date.max().date())} for n,g in [('train',train),('validation',val),('refit',fit),('test',test)]},'validation_mse':validation,'selected':picked,'metrics':metrics,'ridge_standardized_coefficients':dict(zip(FEATURES,map(float,coef))),'versions':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__},'protocol':'Choose within family by validation MSE; refit through matured labels in 2022; frozen test 2023-2025. No transaction-cost or fill simulation.'}
    (out/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--market');ap.add_argument('--out',default='output');args=ap.parse_args()
    panel,meta=read_panel(args.market) if args.market else synthetic_panel()
    with threadpool_limits(limits=2):run(panel,meta,args.out)
