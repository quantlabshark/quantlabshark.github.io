"""Known-parameter HMM: forward filtering and retrospective smoothing."""
from timing_common import *
a=output_parser();rng=np.random.default_rng(705);T=240;P=np.array([[.97,.03],[.04,.96]]);mu=np.array([.002,-.002]);sd=np.array([.008,.02]);s=np.zeros(T,dtype=int)
for t in range(1,T):s[t]=rng.choice(2,p=P[s[t-1]])
y=rng.normal(mu[s],sd[s]);filtered=np.empty((T,2));pred=np.empty((T,2));last=np.array([.5,.5])
for t in range(T):
    pred[t]=last@P;ll=np.exp(-.5*((y[t]-mu)/sd)**2)/sd;last=pred[t]*ll;last/=last.sum();filtered[t]=last
smooth=filtered.copy()
for t in range(T-2,-1,-1):smooth[t]=filtered[t]*(P@(smooth[t+1]/pred[t+1]));smooth[t]/=smooth[t].sum()
fig,ax=plt.subplots(figsize=(8,3.8));ax.fill_between(range(T),0,s,alpha=.12,color=COLORS[1],label='Simulated high-volatility state');ax.plot(filtered[:,1],color=COLORS[0],label='Filtered: past and present');ax.plot(smooth[:,1],color=COLORS[1],ls='--',label='Smoothed: uses future');ax.set(xlabel='Observation',ylabel='State probability',ylim=(-.02,1.02));ax.legend(frameon=False,fontsize=8);save(fig,a.output_dir,'filtered-smoothed-state')
prior=np.array([.8,.2])@np.array([[.9,.1],[.2,.8]]);posterior=prior*np.array([.2,.5]);posterior/=posterior.sum();assert np.allclose(posterior,[.5588235294117647,.4411764705882353]);write(a.output_dir,'calculation-05.json',{'synthetic':True,'prior':prior.tolist(),'posterior':posterior.tolist(),'max_filtered_smoothed_difference':float(np.abs(filtered-smooth).max())})
