from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

def clean(x,k=3):
    x=np.asarray(x,float);med=np.nanmedian(x);mad=np.nanmedian(np.abs(x-med));out=x.copy()
    if mad>0:out=np.clip(out,med-k*mad,med+k*mad)
    if np.nanstd(out,ddof=0)==0:return out,np.full_like(out,np.nan)
    return out,(out-np.nanmean(out))/np.nanstd(out,ddof=0)
x=np.array([1.,2.,3.,4.,100.]);clipped,z=clean(x)
assert np.allclose(clipped,[1,2,3,4,6]);assert abs(z.mean())<1e-12;assert np.isclose(np.mean(z*z),1)
_,constant=clean([2,2,2]);assert np.isnan(constant).all()
rng=np.random.default_rng(44);sample=np.r_[rng.standard_t(3,500),[-25,30]];c,_=clean(sample)
fig,axs=plt.subplots(1,2,figsize=(9,3.5));bins=np.linspace(-12,12,49)
axs[0].hist(sample,bins=bins,color=C[0],alpha=.8);axs[1].hist(c,bins=bins,color=C[1],alpha=.8)
axs[0].set(xlabel='Raw value',ylabel='Count');axs[1].set(xlabel='Clipped value',ylabel='Count');save(fig,'robust-preprocessing.svg')
emit({'data':'simulated','median':3,'mad':1,'clipped':clipped.tolist(),'mean':float(clipped.mean()),'std_ddof0':float(clipped.std()),'z':z.tolist(),'constant_is_missing':True})
