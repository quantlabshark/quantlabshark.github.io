"""Dependence-preserving bootstrap on synthetic serially correlated returns."""
from timing_common import *
a=output_parser();rng=np.random.default_rng(709);n=1500;eps=rng.normal(0,.01,n);r=np.zeros(n)
for i in range(1,n):r[i]=.4*r[i-1]+eps[i]
means=[];iid=[];L=20
walk=[]
# For target return r[t], train only on pairs ending at t-1. Refit every 20 days.
for t in range(253,n):
    if (t-253)%20==0:
        stop=t;train_y=r[stop-252:stop];train_x=np.column_stack([np.ones(252),r[stop-253:stop-1]])
        beta=np.linalg.lstsq(train_x,train_y,rcond=None)[0];last_train_target=stop-1
    forecast=float(beta@np.array([1.,r[t-1]]));assert last_train_target<t
    walk.append({'target_index':t,'last_training_label_index':last_train_target,'forecast':forecast,'observed':r[t]})
pd.DataFrame(walk).to_csv(a.output_dir/'synthetic-walk-forward.csv',index=False)
for b in range(2000):
    starts=rng.integers(0,n-L+1,size=int(np.ceil(n/L)));sample=np.concatenate([r[s:s+L] for s in starts])[:n];means.append(sample.mean());iid.append(r[rng.integers(0,n,n)].mean())
fig,ax=plt.subplots(figsize=(8,3.5));ax.hist(iid,bins=40,density=True,alpha=.45,color=COLORS[1],label='Independent resampling');ax.hist(means,bins=40,density=True,histtype='step',lw=1.7,color=COLORS[0],label='20-day blocks');ax.set(xlabel='Resampled daily mean',ylabel='Density');ax.legend(frameon=False);save(fig,a.output_dir,'block-bootstrap-uncertainty');write(a.output_dir,'calculation-09.json',{'synthetic':True,'seed':709,'block_length':20,'iid_se':float(np.std(iid,ddof=1)),'block_se':float(np.std(means,ddof=1)),'ar1_longrun_variance_multiplier':(1+.4)/(1-.4)})
