from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

def residualize(y,X,weights=None):
    if weights is None:weights=np.ones(len(y))
    root=np.sqrt(weights);coef=np.linalg.lstsq(X*root[:,None],y*root,rcond=None)[0]
    return y-X@coef,coef
rng=np.random.default_rng(55);N=120;industry=np.repeat([0,1,2],40);size=rng.normal(5,1,N)
X=np.column_stack([np.ones(N),industry==1,industry==2,size]);y=1+.7*(industry==1)-.5*(industry==2)+.9*size+rng.normal(0,.6,N)
e,b=residualize(y,X);assert np.max(abs(X.T@e))<1e-10
w=np.linspace(.5,2,N);ew,bw=residualize(y,X,w);assert np.max(abs(X.T@(w*ew)))<1e-10
fig,axs=plt.subplots(1,2,figsize=(9,3.7))
for j in range(3):
    m=industry==j;axs[0].scatter(size[m],y[m],s=20,color=C[j],label=f'Industry {j+1}');axs[1].scatter(size[m],e[m],s=20,color=C[j])
axs[0].set(xlabel='Log market capitalization',ylabel='Raw score');axs[1].set(xlabel='Log market capitalization',ylabel='Residual score');axs[1].axhline(0,color='.4',lw=.8);axs[0].legend(fontsize=9);save(fig,'neutralization.svg')
hand=np.array([1.,3.,4.,8.]);design=np.column_stack([np.ones(4),[0,0,1,1]]);h,_=residualize(hand,design);assert np.allclose(h,[-1,1,-2,2])
emit({'data':'simulated','ols_orthogonality_max':float(np.max(abs(X.T@e))),'wls_orthogonality_max':float(np.max(abs(X.T@(w*ew)))),'hand_residual':h.tolist()})
