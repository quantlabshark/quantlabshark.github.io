from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

rng=np.random.default_rng(1010);T,N,K=1200,60,3
X=rng.normal(size=(T,N,K));X[:,:,1]=.8*X[:,:,0]+.6*X[:,:,1]
beta=np.array([.003,-.001,.002]);Y=X@beta+rng.normal(0,.025,(T,N))+rng.normal(0,.008,(T,1))
# Label attached to signal date t becomes observable at t+1. Boundaries purge the final pre-boundary signal.
train=np.arange(0,599);valid=np.arange(600,799);test=np.arange(800,1199)
def fit(ids,alpha):
    xx=X[ids].reshape(-1,K);yy=(Y[ids]-Y[ids].mean(axis=1,keepdims=True)).ravel()
    return np.linalg.solve(xx.T@xx+alpha*np.eye(K),xx.T@yy)
validation={a:np.mean((Y[valid]-X[valid]@fit(train,a))**2) for a in [1.,100.,10000.]};alpha=min(validation,key=validation.get)
coef=fit(np.r_[train,valid],alpha);pred=X[test]@coef
ic=np.array([stats.spearmanr(a,b).statistic for a,b in zip(pred,Y[test])]);mse=float(np.mean((Y[test]-pred)**2))
sigma=np.diag([.04,.09]);res=optimize.minimize(lambda w:w@sigma@w,[.5,.5],bounds=[(0,1)]*2,constraints={'type':'eq','fun':lambda w:w.sum()-1},method='SLSQP',options={'ftol':1e-14})
assert res.success;assert np.allclose(res.x,[9/13,4/13],atol=1e-6)
fig,axs=plt.subplots(1,2,figsize=(10,3.5));axs[0].plot(test,pd.Series(ic).rolling(30,min_periods=30).mean(),color=C[0]);axs[0].axhline(0,color='.4',lw=.8);axs[0].set(xlabel='Holdout signal day',ylabel='30-day mean RankIC')
grid=np.linspace(0,1,201);variance=.04*grid**2+.09*(1-grid)**2;axs[1].plot(grid,variance,color=C[1]);axs[1].scatter([res.x[0]],[res.fun],color=C[2],zorder=3);axs[1].set(xlabel='Weight of asset A',ylabel='Annual variance');save(fig,'research-and-allocation.svg')
pd.DataFrame({'signal_day':test,'rank_ic':ic}).to_csv(OUT/'holdout-diagnostics.csv',index=False)
emit({'data':'simulated','train_signal_days':len(train),'validation_signal_days':len(valid),'test_signal_days':len(test),'selected_ridge_penalty':float(alpha),'holdout_mean_rank_ic':float(ic.mean()),'holdout_mse':mse,'minimum_variance_weights':res.x.tolist(),'minimum_variance':float(res.fun),'random_seed':1010})
