from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats, optimize
OUT=Path.cwd()
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.alpha":0.18,"svg.fonttype":"none","savefig.facecolor":"white"})
C=["#31798c","#bb713d","#687a4a","#775f8a"]
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/name,bbox_inches="tight");plt.close(fig)
def emit(d):
    (OUT/"results.json").write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(json.dumps(d,ensure_ascii=False,allow_nan=False))

p=np.array([.001,.009,.014,.020,.040,.200]);q=.05;m=len(p);order=np.argsort(p);rank=np.arange(1,m+1);H=np.sum(1/rank)
def selected(threshold):
    passing=np.flatnonzero(p[order]<=threshold)
    return order[:passing[-1]+1].tolist() if len(passing) else []
bh=selected(q*rank/m);by=selected(q*rank/(m*H));assert len(bh)==5 and len(by)==1
assert np.array_equal(stats.false_discovery_control(p,method='bh')<=q,np.isin(range(m),bh))
assert np.array_equal(stats.false_discovery_control(p,method='by')<=q,np.isin(range(m),by))
fig,axs=plt.subplots(1,2,figsize=(10,3.6));axs[0].plot(rank,p[order],'o-',color=C[0],label='Sorted p');axs[0].plot(rank,q*rank/m,'--',color=C[1],label='BH');axs[0].plot(rank,q*rank/(m*H),':',color=C[2],label='BY');axs[0].set(xlabel='Rank',ylabel='p value',ylim=(0,.065));axs[0].legend()
tests=np.arange(1,151);axs[1].plot(tests,1-.95**tests,color=C[3]);axs[1].set(xlabel='Independent null tests',ylabel='Probability of at least one false rejection',ylim=(0,1));save(fig,'multiple-testing.svg')
emit({'data':'constructed valid-p-value illustration','bh_selected':len(bh),'by_selected':len(by),'harmonic_m6':float(H),'null_120_expected_false':6,'null_120_any_false':float(1-.95**120)})
