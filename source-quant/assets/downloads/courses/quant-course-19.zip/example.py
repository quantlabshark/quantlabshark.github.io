# -*- coding: utf-8 -*-
# 19 · 从收盘信号到下一次成交的账户路径
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
opens = [100,101,103,100,105]
closes = [100,102,101,104,103]
cash, shares, next_target = 2000.0,0,0
for i,(open_price,close_price) in enumerate(zip(opens,closes)):
    trade = next_target-shares
    cash -= trade*open_price
    if trade:
        cash -= 1
    shares = next_target
    equity = cash+shares*close_price
    next_target = 10 if i>0 and closes[i]>closes[i-1] else 0
    print(i+1,"订单",trade,"持仓",shares,"现金",cash,"总资产",equity)
assert cash == 917 and shares == 10 and equity == 1947
