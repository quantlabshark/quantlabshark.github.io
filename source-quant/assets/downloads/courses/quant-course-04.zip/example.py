# -*- coding: utf-8 -*-
# 04 · 收益率、现金流与复利净值
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from math import prod, log1p, exp
returns = [0.10, -0.10, 0.05]
growth = prod(1+r for r in returns)
arithmetic = sum(returns)/len(returns)
geometric = growth**(1/len(returns))-1
log_total = sum(log1p(r) for r in returns)
print(f"最终净值 {growth:.4f}，累计收益 {growth-1:.2%}")
print(f"算术均值 {arithmetic:.4%}，几何均值 {geometric:.4%}")
assert abs(exp(log_total)-growth) < 1e-12
