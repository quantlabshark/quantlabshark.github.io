# -*- coding: utf-8 -*-
# 15 · 样本均值有多精确：标准误与重抽样
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
from scipy.stats import t
sample = np.array([1,2,3,4,5],dtype=float)/100
n = len(sample)
mean, sd = sample.mean(),sample.std(ddof=1)
se = sd/np.sqrt(n)
critical = t.ppf(0.975,n-1)
interval = mean + np.array([-1,1])*critical*se
rng = np.random.default_rng(2026)
boot_means = rng.choice(sample,size=(20000,n),replace=True).mean(axis=1)
print(f"均值 {mean:.2%}，标准差 {sd:.4%}，标准误 {se:.4%}")
print("t区间(%):",np.round(interval*100,4))
print("Bootstrap百分位区间(%):",np.quantile(boot_means,[0.025,0.975])*100)
assert np.isclose(se,0.007071067811865475)
