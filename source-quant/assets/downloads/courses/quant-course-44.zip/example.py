# -*- coding: utf-8 -*-
# 44 · 马尔可夫链、动态规划与HJB
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
Qmax, T = 2, 2
impact, risk = [4.0, 1.0], 0.5
V = np.full((T+1, Qmax+1), np.inf)
V[T, 0] = 0.0
policy = np.zeros((T, Qmax+1), dtype=int)
for k in range(T-1, -1, -1):
    for q in range(Qmax+1):
        values = [impact[k]*v*v + risk*(q-v)**2 + V[k+1, q-v]
                  for v in range(q+1)]
        policy[k, q] = int(np.argmin(values))
        V[k, q] = values[policy[k, q]]
print('最小成本', V[0, 2], '首期卖出', policy[0, 2])
assert V[0, 2] == 5.5 and policy[0, 2] == 1
