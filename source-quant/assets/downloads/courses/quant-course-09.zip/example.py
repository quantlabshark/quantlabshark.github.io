# -*- coding: utf-8 -*-
# 09 · NumPy 数组怎样计算多资产收益
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
prices = np.array([[100,50],[102,49],[101,51]],dtype=float)
returns = prices[1:]/prices[:-1]-1
weights = np.array([0.6,0.4])
contributions = returns*weights
portfolio = returns@weights
print("形状:",prices.shape,returns.shape,portfolio.shape)
print("资产收益(%):\n",np.round(returns*100,4))
print("组合收益(%):",np.round(portfolio*100,4))
assert np.allclose(contributions.sum(axis=1),portfolio)
assert np.isclose(weights.sum(),1)
