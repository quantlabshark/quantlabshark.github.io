# -*- coding: utf-8 -*-
# 45 · 泊松过程、自激过程与模拟
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import numpy as np
rng = np.random.default_rng(45)
mu, alpha, beta, horizon = 1.0, 0.6, 1.5, 2000.0
t, excitation, events = 0.0, 0.0, []
while True:
    upper = mu + excitation
    wait = rng.exponential(1.0/upper)
    t += wait
    if t > horizon:
        break
    excitation *= np.exp(-beta*wait)
    if rng.random() < (mu + excitation)/upper:
        events.append(t)
        excitation += alpha
print('模拟强度', round(len(events)/horizon, 3))
print('平稳平均强度', round(mu/(1-alpha/beta), 3))
assert np.all(np.diff(events) > 0)
