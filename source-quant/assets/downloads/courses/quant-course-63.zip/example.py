# -*- coding: utf-8 -*-
# 63 · 市场规则与交易约束的核查
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
from decimal import Decimal
def valid_order(side,quantity,price,available_sell,
                lot=100,tick=Decimal('0.01')):
    price=Decimal(str(price))
    if side not in ('buy','sell'):return False
    if quantity<=0 or quantity%lot:return False
    if price<=0 or price%tick:return False
    if side=='sell' and quantity>available_sell:return False
    return True
assert valid_order('buy',200,'10.02',300)
assert not valid_order('buy',150,'10.02',300)
assert not valid_order('sell',400,'10.02',300)
assert not valid_order('buy',200,'10.025',300)
print([valid_order(s,q,p,300) for s,q,p in [("buy",200,"10.02"),("buy",150,"10.02"),("sell",400,"10.02"),("buy",200,"10.025")]])
