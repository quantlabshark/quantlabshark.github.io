# -*- coding: utf-8 -*-
def prefix(pattern):
    pi=[0]*len(pattern);q=0
    for i in range(1,len(pattern)):
        while q and pattern[i]!=pattern[q]:q=pi[q-1]
        if pattern[i]==pattern[q]:q+=1
        pi[i]=q
    return pi
def kmp(text,pattern):
    if not pattern:return list(range(len(text)+1))
    pi=prefix(pattern);q=0;positions=[]
    for i,ch in enumerate(text):
        while q and ch!=pattern[q]:q=pi[q-1]
        if ch==pattern[q]:q+=1
        if q==len(pattern):
            positions.append(i-len(pattern)+1);q=pi[q-1]
    return positions
assert prefix('ababaca')==[0,0,1,2,3,0,1]
assert kmp('ababa','aba')==[0,2]
assert kmp('aaaaa','aaa')==[0,1,2]
print(kmp('ababa','aba'))
