# -*- coding: utf-8 -*-
def balanced(text):
    stack=[];pairs={')':'(',']':'[','}':'{'}
    for ch in text:
        if ch in '([{':stack.append(ch)
        elif ch in pairs:
            if not stack or stack.pop()!=pairs[ch]:return False
    return not stack
for s,expected in [('([{}])',True),('([)]',False),('',True),('(',False)]:
    assert balanced(s)==expected
    print(s,balanced(s))
