# -*- coding: utf-8 -*-
def knight_tour(n=5,start=(0,0)):
    moves=((1,2),(2,1),(2,-1),(1,-2),(-1,-2),(-2,-1),(-2,1),(-1,2))
    def neighbors(p):
        return [(p[0]+dx,p[1]+dy) for dx,dy in moves
                if 0<=p[0]+dx<n and 0<=p[1]+dy<n]
    path=[start];seen={start}
    def search():
        if len(path)==n*n:return True
        options=[q for q in neighbors(path[-1]) if q not in seen]
        options.sort(key=lambda q:sum(v not in seen for v in neighbors(q)))
        for q in options:
            path.append(q);seen.add(q)
            if search():return True
            seen.remove(q);path.pop()
        return False
    return path.copy() if search() else None
path=knight_tour()
assert path is not None and len(set(path))==25
assert all(sorted((abs(a[0]-b[0]),abs(a[1]-b[1])))==[1,2]
           for a,b in zip(path,path[1:]))
for row in range(5):
    print([path.index((row,col))+1 for col in range(5)])
