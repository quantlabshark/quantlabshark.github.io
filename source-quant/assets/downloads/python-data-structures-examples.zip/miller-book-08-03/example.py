# -*- coding: utf-8 -*-
from math import gcd
p,q,e=5,11,3
n=p*q;phi=(p-1)*(q-1)
assert gcd(e,phi)==1
d=pow(e,-1,phi)
cipher=pow(7,e,n);plain=pow(cipher,d,n)
assert (d,cipher,plain)==(27,13,7)
assert all(pow(pow(m,e,n),d,n)==m for m in range(n))
print('public',(n,e),'private exponent',d,'cipher',cipher,'decoded',plain)
