# -*- coding: utf-8 -*-
def shell_sort(values):
    a=list(values);gap=len(a)//2
    while gap:
        for i in range(gap,len(a)):
            key=a[i];j=i
            while j>=gap and a[j-gap]>key:
                a[j]=a[j-gap];j-=gap
            a[j]=key
        assert all(a[i]<=a[i+gap] for i in range(len(a)-gap))
        gap//=2
    return a
a=[9,8,3,7,5,6,4,1]
assert shell_sort(a)==sorted(a)
print(shell_sort(a))
