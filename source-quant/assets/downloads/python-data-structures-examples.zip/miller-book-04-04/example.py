# -*- coding: utf-8 -*-
def find_path(grid,start,end):
    rows,cols=len(grid),len(grid[0]);seen=set();path=[]
    def visit(r,c):
        if not(0<=r<rows and 0<=c<cols) or grid[r][c]=='#' or (r,c) in seen:return False
        seen.add((r,c));path.append((r,c))
        if (r,c)==end:return True
        for dr,dc in [(1,0),(0,1),(-1,0),(0,-1)]:
            if visit(r+dr,c+dc):return True
        path.pop();return False
    return path if visit(*start) else None
grid=['...','##.','...']
path=find_path(grid,(0,0),(2,2))
assert path==[(0,0),(0,1),(0,2),(1,2),(2,2)]
print(path)
