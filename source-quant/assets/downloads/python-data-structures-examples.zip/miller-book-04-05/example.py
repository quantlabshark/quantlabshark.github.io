# -*- coding: utf-8 -*-
def change(amount,coins):
    if amount<0 or any(c<=0 for c in coins):raise ValueError('invalid amount or denomination')
    dp=[float('inf')]*(amount+1);choice=[None]*(amount+1);dp[0]=0
    for a in range(1,amount+1):
        for c in coins:
            if c<=a and dp[a-c]+1<dp[a]:
                dp[a]=dp[a-c]+1;choice[a]=c
    if choice[amount] is None and amount:return None
    answer=[];a=amount
    while a:
        c=choice[a];answer.append(c);a-=c
    return dp[amount],answer
assert change(6,[1,3,4])==(2,[3,3])
assert change(3,[2,5]) is None
print(change(6,[1,3,4]))
