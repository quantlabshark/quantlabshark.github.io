# -*- coding: utf-8 -*-
from dataclasses import dataclass,field
@dataclass
class Node:
    depth:int=0
    count:int=0
    sums:list=field(default_factory=lambda:[0,0,0])
    children:dict=field(default_factory=dict)

def octree_quantize(pixels,k=8,depth=5):
    if k<1 or not 1<=depth<=8:raise ValueError('invalid palette size or depth')
    root=Node()
    for rgb in pixels:
        if len(rgb)!=3 or any(not 0<=c<=255 for c in rgb):raise ValueError('invalid RGB')
        node=root
        for level in range(depth+1):
            node.count+=1
            for c in range(3):node.sums[c]+=rgb[c]
            if level<depth:
                shift=7-level
                key=sum(((rgb[c]>>shift)&1)<<(2-c) for c in range(3))
                node=node.children.setdefault(key,Node(level+1))
    def leaves(node):
        return 1 if not node.children else sum(leaves(v) for v in node.children.values())
    def candidates(node):
        result=[]
        if node.children:
            if all(not child.children for child in node.children.values()):result.append(node)
            for child in node.children.values():result.extend(candidates(child))
        return result
    if not pixels:return [],[]
    while leaves(root)>k:
        node=max(candidates(root),key=lambda n:(n.depth,-n.count))
        node.children.clear()
    palette=[]
    def color(node):
        return tuple(round(s/node.count) for s in node.sums)
    def collect(node):
        if not node.children:palette.append(color(node))
        for child in node.children.values():collect(child)
    collect(root)
    output=[]
    for rgb in pixels:
        node=root
        for level in range(depth):
            if not node.children:break
            shift=7-level
            key=sum(((rgb[c]>>shift)&1)<<(2-c) for c in range(3))
            node=node.children[key]
        output.append(color(node))
    return output,palette
pixels=[(r,g,80) for r in range(0,256,16) for g in range(0,256,16)]
output,palette=octree_quantize(pixels,8)
assert len(output)==len(pixels) and len(set(palette))<=8
assert all(p in palette for p in output)
print('palette',palette)
print('mean squared error',sum((a-b)**2 for p,q in zip(pixels,output) for a,b in zip(p,q))/(3*len(pixels)))
