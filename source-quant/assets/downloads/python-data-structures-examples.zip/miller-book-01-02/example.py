# -*- coding: utf-8 -*-
a=[1,2];b=a;b.append(3)
assert a==[1,2,3]
rows=[[0]]*3;rows[0][0]=7
independent=[[0] for _ in range(3)];independent[0][0]=7
print('shared',rows,'independent',independent)
assert independent==[[7],[0],[0]]
