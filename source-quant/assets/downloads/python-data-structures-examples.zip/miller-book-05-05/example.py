# -*- coding: utf-8 -*-
def merge_sort(values):
    if len(values)<2:return list(values)
    mid=len(values)//2
    left=merge_sort(values[:mid]);right=merge_sort(values[mid:])
    out=[];i=j=0
    while i<len(left) and j<len(right):
        if left[i]<=right[j]:out.append(left[i]);i+=1
        else:out.append(right[j]);j+=1
    return out+left[i:]+right[j:]
a=[7,2,5,1,2]
assert merge_sort(a)==sorted(a)
print(merge_sort(a))
