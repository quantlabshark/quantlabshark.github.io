# -*- coding: utf-8 -*-
from collections import deque
def palindrome(text):
    q=deque(text)
    while len(q)>1:
        if q.popleft()!=q.pop():return False
    return True
assert palindrome('radar') and palindrome('')
assert not palindrome('python')
q=deque(['A','B','C'])
q.append(q.popleft())
print(list(q))
assert list(q)==['B','C','A']
