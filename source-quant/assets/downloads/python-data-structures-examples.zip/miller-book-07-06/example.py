# -*- coding: utf-8 -*-
import heapq
def dijkstra(graph,start):
    if any(w<0 for vs in graph.values() for _,w in vs):raise ValueError('negative edge')
    distance={start:0};parent={start:None};heap=[(0,start)]
    while heap:
        d,u=heapq.heappop(heap)
        if d!=distance[u]:continue
        for v,w in graph.get(u,[]):
            candidate=d+w
            if candidate<distance.get(v,float('inf')):
                distance[v]=candidate;parent[v]=u
                heapq.heappush(heap,(candidate,v))
    return distance,parent
g={'A':[('B',4),('C',1)],'C':[('B',2),('D',5)],'B':[('D',1)],'D':[]}
distance,parent=dijkstra(g,'A')
assert distance['D']==4 and parent['D']=='B'
print(distance)
