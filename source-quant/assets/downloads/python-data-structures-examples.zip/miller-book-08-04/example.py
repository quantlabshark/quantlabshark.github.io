# -*- coding: utf-8 -*-
import random
class Node:
    def __init__(self,key,value,height):
        self.key,self.value=key,value;self.next=[None]*height
class SkipMap:
    def __init__(self,max_level=16,seed=20261018):
        self.max_level=max_level;self.head=Node(None,None,max_level)
        self.level=1;self.rng=random.Random(seed)
    def predecessors(self,key):
        update=[self.head]*self.max_level;node=self.head
        for level in range(self.level-1,-1,-1):
            while node.next[level] and node.next[level].key<key:node=node.next[level]
            update[level]=node
        return update
    def put(self,key,value):
        update=self.predecessors(key);node=update[0].next[0]
        if node and node.key==key:node.value=value;return
        height=1
        while height<self.max_level and self.rng.random()<.5:height+=1
        if height>self.level:
            for i in range(self.level,height):update[i]=self.head
            self.level=height
        node=Node(key,value,height)
        for i in range(height):
            node.next[i]=update[i].next[i];update[i].next[i]=node
    def get(self,key):
        node=self.predecessors(key)[0].next[0]
        if node is None or node.key!=key:raise KeyError(key)
        return node.value
    def items(self):
        node=self.head.next[0]
        while node:
            yield node.key,node.value;node=node.next[0]
m=SkipMap()
for key in [7,2,9,1,5]:m.put(key,str(key))
m.put(5,'five')
assert m.get(5)=='five' and [k for k,v in m.items()]==[1,2,5,7,9]
print(list(m.items()))
