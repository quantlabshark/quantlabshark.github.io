# -*- coding: utf-8 -*-
from dataclasses import dataclass
@dataclass
class Node:
    key:int
    left:object=None
    right:object=None
    height:int=0
def h(x):return x.height if x else -1
def update(x):x.height=1+max(h(x.left),h(x.right));return x
def right(y):
    x=y.left;y.left=x.right;x.right=y
    update(y);return update(x)
def left(x):
    y=x.right;x.right=y.left;y.left=x
    update(x);return update(y)
def insert(root,key):
    if root is None:return Node(key)
    if key<root.key:root.left=insert(root.left,key)
    elif key>root.key:root.right=insert(root.right,key)
    else:return root
    update(root);balance=h(root.left)-h(root.right)
    if balance>1:
        if h(root.left.left)<h(root.left.right):root.left=left(root.left)
        return right(root)
    if balance< -1:
        if h(root.right.right)<h(root.right.left):root.right=right(root.right)
        return left(root)
    return root
def check(root,low=float('-inf'),high=float('inf')):
    if root is None:return []
    assert low<root.key<high
    assert root.height==1+max(h(root.left),h(root.right))
    assert abs(h(root.left)-h(root.right))<=1
    return check(root.left,low,root.key)+[root.key]+check(root.right,root.key,high)
root=None
for x in range(1,16):root=insert(root,x);check(root)
assert check(root)==list(range(1,16))
print('height',root.height,'root',root.key)

import random
for seed in range(20):
    values=list(range(80));random.Random(seed).shuffle(values);root=None
    for value in values:root=insert(root,value)
    assert check(root)==list(range(80))
print("20 random insertion orders passed")
