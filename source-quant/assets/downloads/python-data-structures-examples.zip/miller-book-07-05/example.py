# -*- coding: utf-8 -*-
def components(graph):
    vertices=set(graph)
    for vs in graph.values():vertices.update(vs)
    seen=set();order=[]
    def dfs(u):
        seen.add(u)
        for v in graph.get(u,[]):
            if v not in seen:dfs(v)
        order.append(u)
    for u in sorted(vertices):
        if u not in seen:dfs(u)
    reverse={u:[] for u in vertices}
    for u,vs in graph.items():
        for v in vs:reverse[v].append(u)
    seen.clear();groups=[]
    def collect(u,group):
        seen.add(u);group.add(u)
        for v in reverse[u]:
            if v not in seen:collect(v,group)
    for u in reversed(order):
        if u not in seen:
            group=set();collect(u,group);groups.append(group)
    return groups
g={'A':['B'],'B':['C'],'C':['A','D'],'D':['E'],'E':['D','F'],'F':[]}
groups=components(g)
assert {frozenset(x) for x in groups}=={frozenset('ABC'),frozenset('DE'),frozenset('F')}
print([sorted(x) for x in groups])
