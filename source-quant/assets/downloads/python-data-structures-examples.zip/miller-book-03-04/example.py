# -*- coding: utf-8 -*-
def schedule(arrivals):
    finish=0;rows=[]
    for arrival,duration in arrivals:
        start=max(arrival,finish)
        rows.append((arrival,start,start-arrival))
        finish=start+duration
    return rows,finish
rows,finish=schedule([(0,3),(1,2),(4,1)])
assert [r[2] for r in rows]==[0,2,1]
assert finish==6
print(rows,finish)
