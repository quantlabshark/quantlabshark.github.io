# -*- coding: utf-8 -*-
def insertion_sort(values):
    a=list(values)
    for i in range(1,len(a)):
        key=a[i];j=i-1
        while j>=0 and a[j]>key:
            a[j+1]=a[j];j-=1
        a[j+1]=key
    return a
for a in [[],[1],[5,2,4,1],[2,2,1],list(range(8))]:
    assert insertion_sort(a)==sorted(a)
print(insertion_sort([5,2,4,1]))
