# -*- coding: utf-8 -*-
from math import gcd
class Fraction:
    def __init__(self,num,den):
        if not isinstance(num,int) or not isinstance(den,int):
            raise TypeError('integer numerator and denominator required')
        if den==0: raise ZeroDivisionError('zero denominator')
        g=gcd(num,den);num//=g;den//=g
        if den<0:num,den=-num,-den
        self.num,self.den=num,den
    def __add__(self,other):
        if not isinstance(other,Fraction):return NotImplemented
        return Fraction(self.num*other.den+other.num*self.den,self.den*other.den)
    def __eq__(self,other):
        if not isinstance(other,Fraction):return NotImplemented
        return self.num==other.num and self.den==other.den
    def __str__(self):return f'{self.num}/{self.den}'
print(Fraction(1,2)+Fraction(1,3))
assert Fraction(2,4)==Fraction(-2,-4)
assert str(Fraction(0,5))=='0/1'
