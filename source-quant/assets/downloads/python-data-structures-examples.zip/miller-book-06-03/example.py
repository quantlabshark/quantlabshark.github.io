# -*- coding: utf-8 -*-
from collections import deque
tree=('A',('B',('D',None,None),('E',None,None)),('C',None,None))
def traverse(node,order):
    if node is None:return []
    value,left,right=node
    a=traverse(left,order);b=traverse(right,order)
    if order=='pre':return [value]+a+b
    if order=='in':return a+[value]+b
    return a+b+[value]
def breadth(root):
    if root is None:return []
    q=deque([root]);out=[]
    while q:
        value,left,right=q.popleft();out.append(value)
        if left:q.append(left)
        if right:q.append(right)
    return out
assert traverse(tree,'in')==list('DBEAC')
assert breadth(tree)==list('ABCDE')
print(traverse(tree,'pre'),traverse(tree,'post'),breadth(tree))
