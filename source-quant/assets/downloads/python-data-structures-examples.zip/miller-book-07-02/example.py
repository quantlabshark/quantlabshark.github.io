# -*- coding: utf-8 -*-
from collections import deque
def bfs(graph,start):
    parent={start:None};distance={start:0};q=deque([start])
    while q:
        u=q.popleft()
        for v in graph.get(u,[]):
            if v not in distance:
                parent[v]=u;distance[v]=distance[u]+1;q.append(v)
    return distance,parent
graph={'A':['B','C'],'B':['D'],'C':['D','E'],'D':[],'E':[]}
distance,parent=bfs(graph,'A')
assert distance=={'A':0,'B':1,'C':1,'D':2,'E':2}
path=[];v='D'
while v is not None:path.append(v);v=parent[v]
print(list(reversed(path)),distance)

def word_graph(words):
    buckets={}
    for word in words:
        for i in range(len(word)):
            buckets.setdefault(word[:i]+'_'+word[i+1:],[]).append(word)
    graph={w:set() for w in words}
    for group in buckets.values():
        for word in group:graph[word].update(set(group)-{word})
    return graph
graph=word_graph(['cold','cord','card','ward','warm','word'])
print('word graph',graph)
