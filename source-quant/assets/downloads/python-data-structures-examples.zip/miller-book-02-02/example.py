# -*- coding: utf-8 -*-
def counts(s):
    result={}
    for c in s:result[c]=result.get(c,0)+1
    return result
def anagram(a,b):return len(a)==len(b) and counts(a)==counts(b)
assert anagram('silent','listen')
assert anagram('abca','caba')
assert not anagram('abca','abcc')
print(counts('abca'))
