# -*- coding: utf-8 -*-
from dataclasses import dataclass
@dataclass
class Node:
    key:int
    left:object=None
    right:object=None
def insert(root,key):
    if root is None:return Node(key)
    if key<root.key:root.left=insert(root.left,key)
    elif key>root.key:root.right=insert(root.right,key)
    return root
def delete(root,key):
    if root is None:raise KeyError(key)
    if key<root.key:root.left=delete(root.left,key)
    elif key>root.key:root.right=delete(root.right,key)
    else:
        if root.left is None:return root.right
        if root.right is None:return root.left
        successor=root.right
        while successor.left:successor=successor.left
        root.key=successor.key;root.right=delete(root.right,successor.key)
    return root
def inorder(root):
    return inorder(root.left)+[root.key]+inorder(root.right) if root else []
root=None
for x in [5,3,8,2,4,6,9,7]:root=insert(root,x)
root=delete(root,5)
assert inorder(root)==[2,3,4,6,7,8,9]
print(inorder(root))

def search(root,key):
    while root is not None:
        if key==root.key:return root
        root=root.left if key<root.key else root.right
    return None
assert search(root,7).key==7 and search(root,5) is None
