# -*- coding: utf-8 -*-
import random
def quick_sort(values,rng):
    if len(values)<2:return list(values)
    pivot=values[rng.randrange(len(values))]
    lower=[];equal=[];upper=[]
    for x in values:
        if x<pivot:lower.append(x)
        elif x>pivot:upper.append(x)
        else:equal.append(x)
    return quick_sort(lower,rng)+equal+quick_sort(upper,rng)
rng=random.Random(20261018)
for a in [[],[3,1,3,2,3],list(range(100)),[7]*100]:
    assert quick_sort(a,rng)==sorted(a)
print(quick_sort([3,1,3,2,3],rng))
