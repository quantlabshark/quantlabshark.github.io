# -*- coding: utf-8 -*-
from timeit import repeat
def append_build(n):
    result=[]
    for i in range(n):result.append(i)
    return result
def concat_build(n):
    result=[]
    for i in range(n):result=result+[i]
    return result
for n in (500,1000,2000):
    a=min(repeat(lambda:append_build(n),number=5,repeat=3))
    b=min(repeat(lambda:concat_build(n),number=5,repeat=3))
    print(n,'append',a,'concatenation',b)
    assert append_build(n)==concat_build(n)
