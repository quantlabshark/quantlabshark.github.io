# -*- coding: utf-8 -*-
class HashMap:
    EMPTY=object();DELETED=object()
    def __init__(self,size=11):
        self.slots=[self.EMPTY]*size
    def put(self,key,value):
        m=len(self.slots);first_deleted=None
        for step in range(m):
            i=(hash(key)+step)%m;entry=self.slots[i]
            if entry is self.DELETED:
                if first_deleted is None:first_deleted=i
            elif entry is self.EMPTY:
                self.slots[first_deleted if first_deleted is not None else i]=(key,value);return
            elif entry[0]==key:
                self.slots[i]=(key,value);return
        if first_deleted is not None:self.slots[first_deleted]=(key,value);return
        raise OverflowError('table full')
    def get(self,key):
        for step in range(len(self.slots)):
            entry=self.slots[(hash(key)+step)%len(self.slots)]
            if entry is self.EMPTY:break
            if entry is not self.DELETED and entry[0]==key:return entry[1]
        raise KeyError(key)
    def delete(self,key):
        for step in range(len(self.slots)):
            i=(hash(key)+step)%len(self.slots);entry=self.slots[i]
            if entry is self.EMPTY:break
            if entry is not self.DELETED and entry[0]==key:self.slots[i]=self.DELETED;return
        raise KeyError(key)
table=HashMap(7)
for x in [10,17,24]:table.put(x,str(x))
table.delete(17);assert table.get(24)=='24'
table.put(24,'updated');assert table.get(24)=='updated'
print(table.get(24))
