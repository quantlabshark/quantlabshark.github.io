# -*- coding: utf-8 -*-
def mod_power(a,n,m):
    if n<0 or m<=0:raise ValueError('require n>=0 and m>0')
    result=1%m;a%=m
    while n:
        if n&1:result=result*a%m
        a=a*a%m;n//=2
    return result
def extended_gcd(a,b):
    if b==0:return a,1,0
    g,x,y=extended_gcd(b,a%b)
    return g,y,x-(a//b)*y
assert mod_power(3,13,17)==12
g,x,y=extended_gcd(5,18)
assert 5*x+18*y==g==1 and x%18==11
print(mod_power(3,13,17),x%18)
