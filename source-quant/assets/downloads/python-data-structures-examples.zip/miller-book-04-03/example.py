# -*- coding: utf-8 -*-
def hanoi(n,source='A',target='C',spare='B'):
    if n<0:raise ValueError('n must be nonnegative')
    if n==0:return
    yield from hanoi(n-1,source,spare,target)
    yield source,target
    yield from hanoi(n-1,spare,target,source)
moves=list(hanoi(3));assert len(moves)==7
pegs={'A':[3,2,1],'B':[],'C':[]}
for source,target in moves:
    disk=pegs[source].pop()
    assert not pegs[target] or pegs[target][-1]>disk
    pegs[target].append(disk)
assert pegs['C']==[3,2,1]
print(moves)
