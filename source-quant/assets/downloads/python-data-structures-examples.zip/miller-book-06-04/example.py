# -*- coding: utf-8 -*-
class MinHeap:
    def __init__(self,values=()):
        self.a=list(values)
        for i in range(len(self.a)//2-1,-1,-1):self.down(i)
    def down(self,i):
        a=self.a
        while 2*i+1<len(a):
            child=2*i+1
            if child+1<len(a) and a[child+1]<a[child]:child+=1
            if a[i]<=a[child]:break
            a[i],a[child]=a[child],a[i];i=child
    def push(self,value):
        a=self.a;a.append(value);i=len(a)-1
        while i and a[i]<a[(i-1)//2]:
            p=(i-1)//2;a[i],a[p]=a[p],a[i];i=p
    def pop(self):
        if not self.a:raise IndexError('empty heap')
        answer=self.a[0];last=self.a.pop()
        if self.a:self.a[0]=last;self.down(0)
        return answer
heap=MinHeap([9,5,6,2,3]);heap.push(1)
out=[heap.pop() for _ in range(6)]
assert out==[1,2,3,5,6,9]
print(out)
