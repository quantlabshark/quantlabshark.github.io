# -*- coding: utf-8 -*-
import ctypes
class DynamicArray:
    def __init__(self):
        self.size=0;self.capacity=1;self.data=(ctypes.py_object*self.capacity)()
    def append(self,value):
        if self.size==self.capacity:
            capacity=2*self.capacity;new=(ctypes.py_object*capacity)()
            for i in range(self.size):new[i]=self.data[i]
            self.data=new;self.capacity=capacity
        self.data[self.size]=value;self.size+=1
    def __getitem__(self,index):
        if not 0<=index<self.size:raise IndexError(index)
        return self.data[index]
a=DynamicArray()
for i in range(10):a.append(i)
assert [a[i] for i in range(a.size)]==list(range(10))
assert a.capacity==16
print(a.size,a.capacity)
