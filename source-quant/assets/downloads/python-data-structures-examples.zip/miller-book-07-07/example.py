# -*- coding: utf-8 -*-
import heapq
def prim(graph,start):
    seen={start};heap=[(w,start,v) for v,w in graph[start]];heapq.heapify(heap)
    edges=[];total=0
    while heap and len(seen)<len(graph):
        w,u,v=heapq.heappop(heap)
        if v in seen:continue
        seen.add(v);edges.append((u,v,w));total+=w
        for z,cost in graph[v]:
            if z not in seen:heapq.heappush(heap,(cost,v,z))
    if len(seen)!=len(graph):raise ValueError('disconnected graph')
    return edges,total
g={'A':[('B',2),('C',3)],'B':[('A',2),('C',2)],'C':[('A',3),('B',2)]}
edges,total=prim(g,'A')
assert len(edges)==2 and total==4
print(edges,total)
