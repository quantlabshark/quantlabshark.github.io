# -*- coding: utf-8 -*-
def lower_bound(a,target):
    lo,hi=0,len(a)
    while lo<hi:
        mid=(lo+hi)//2
        if a[mid]<target:lo=mid+1
        else:hi=mid
    return lo
from bisect import bisect_left
for a in [[],[1],[1,3,3,5,8]]:
    for x in range(10):
        assert lower_bound(a,x)==bisect_left(a,x)
print(lower_bound([1,3,3,5,8],3))
