function [theStruct] = LoadMarketData(aPath, aFilePrefix, aDate)
%LOADMARKETDATA Load recorded csv feed file into a struct.  
%   Detailed explanation goes here
    myFile = fullfile(aPath, [aFilePrefix '_' num2str(aDate) '.csv']);
    myDayData = ReadCSV(myFile);
    theStruct = FilterStructure(myDayData, myDayData.AskVol ~= 0 & myDayData.BidVol ~= 0);
end

