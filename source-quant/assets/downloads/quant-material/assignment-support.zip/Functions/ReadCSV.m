function [ theStruct ] = ReadCSV(aFileName)
%READCSV Load a csv file into a structure
%   Detailed explanation goes here
myData = importdata(aFileName);
myHeaders = myData.colheaders;

for i = 1:numel(myHeaders)
    theStruct.(myHeaders{i}) = myData.data(:, i);
end
end

