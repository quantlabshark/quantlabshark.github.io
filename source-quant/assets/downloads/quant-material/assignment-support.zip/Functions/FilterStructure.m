function [ theStruct ] = FilterStructure(aStruct, aFilter)
%FILTERSTRUCTURE Given a struct, filter all fields based on aFilter index. 
%   Detailed explanation goes here
myFieldNames = fieldnames(aStruct);

for i=1:numel(myFieldNames)
    myField = aStruct.(myFieldNames{i});
    theStruct.(myFieldNames{i}) = myField(aFilter);
end 
end

