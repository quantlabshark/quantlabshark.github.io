from pathlib import Path
import pandas as pd,numpy as np,json
w=Path(__file__).resolve().parent;p=w
x=pd.read_csv(p/'stock_price.csv').drop(columns=['Unnamed: 0']);h=pd.read_csv(p/'热门股票.csv')
x['TRADE_DATE']=pd.to_datetime(x.TRADE_DATE.astype(str),format='%Y%m%d')
assert not x.duplicated(['CODE','TRADE_DATE']).any()
x=x.sort_values(['CODE','TRADE_DATE']).reset_index(drop=True)
x['DailyReturn']=x.CLOSE/x.PRECLOSE.where(x.PRECLOSE>0)-1
x['AveragePriceLast5Days']=x.groupby('CODE').CLOSE.transform(lambda v:v.shift(1).rolling(5,min_periods=5).mean())
x['AverageReturnLast5Days']=x.groupby('CODE').DailyReturn.transform(lambda v:v.shift(1).rolling(5,min_periods=5).mean())
h=h[~h.is_del.astype(str).str.lower().isin(['t','true','1'])].drop_duplicates('id').copy()
times=pd.to_datetime(h.create_time,dayfirst=True,utc=True,format='mixed',errors='coerce');assert times.notna().all()
h['TRADE_DATE']=times.dt.tz_convert('Asia/Shanghai').dt.tz_localize(None).dt.normalize()
freq=h.groupby(['TRADE_DATE','ts_code']).size().rename('HotCount').reset_index().rename(columns={'ts_code':'CODE'})
daily=h.groupby('TRADE_DATE').size().rename('TotalMentions')
freq=freq.merge(daily,on='TRADE_DATE',validate='many_to_one');freq['DailyHotRateRaw']=freq.HotCount/freq.TotalMentions
x=x.merge(freq[['CODE','TRADE_DATE','HotCount','DailyHotRateRaw']],on=['CODE','TRADE_DATE'],how='left',validate='one_to_one')
covered=x.TRADE_DATE.isin(daily.index)
x.loc[covered,['HotCount','DailyHotRateRaw']]=x.loc[covered,['HotCount','DailyHotRateRaw']].fillna(0)
x['DailyHotRate']=x.groupby('TRADE_DATE').DailyHotRateRaw.transform(lambda v:v.clip(v.quantile(.01),v.quantile(.99)))
correlations=[]
for day,g in x.groupby('TRADE_DATE'):
 z=g[['DailyHotRate','AveragePriceLast5Days']].dropna();a=z.DailyHotRate;b=z.AveragePriceLast5Days
 valid=len(z)>=3 and a.nunique()>1 and b.nunique()>1
 correlations.append({'TRADE_DATE':day,'pair_count':len(z),'corr1':a.corr(b) if valid else np.nan,'corr2':a.corr(b,method='spearman') if valid else np.nan})
c=pd.DataFrame(correlations);x=x.merge(c[['TRADE_DATE','corr1','corr2']],on='TRADE_DATE',validate='many_to_one')
out=w/'result.csv';x.to_csv(out,index=False,encoding='utf-8-sig',date_format='%Y-%m-%d');c.to_csv(w/'wanyan-correlations.csv',index=False,date_format='%Y-%m-%d')
summary={'price_rows':len(x),'stocks':x.CODE.nunique(),'days':x.TRADE_DATE.nunique(),'date_from':str(x.TRADE_DATE.min().date()),'date_to':str(x.TRADE_DATE.max().date()),'hot_rows':len(h),'hot_days':len(daily),'valid_average_price':int(x.AveragePriceLast5Days.notna().sum()),'valid_hot_rate':int(x.DailyHotRate.notna().sum()),'result_rows':len(x),'definitions':{'AveragePriceLast5Days':'mean of preceding five observed trading-day CLOSE values, excluding current row','AverageReturnLast5Days':'mean of preceding five CLOSE/PRECLOSE-1, excluding current row','DailyHotRate':'share of mentions in supplied undeleted feed each Shanghai calendar day; absent stock=0 only on covered feed dates; winsorize cross-section at1%/99%','corr1':'same-day cross-sectional Pearson between DailyHotRate and AveragePriceLast5Days','corr2':'same-day cross-sectional Spearman between DailyHotRate and AveragePriceLast5Days'},'correlations':json.loads(c.assign(TRADE_DATE=c.TRADE_DATE.dt.strftime('%Y-%m-%d')).to_json(orient='records'))}
(w/'wanyan-market-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(summary,ensure_ascii=False))
