from pathlib import Path
import pandas as pd,numpy as np,json
from scipy.stats import chi2_contingency
w=Path(__file__).resolve().parent
a=pd.read_csv(w/'transaction-anonymous.csv')
a['Transaction_date']=pd.to_datetime(a.Transaction_date,format='mixed')

def date(v):
 if isinstance(v,(float,int)):return pd.Timestamp('1899-12-30')+pd.to_timedelta(v,unit='D')
 return pd.to_datetime(v,errors='coerce')
a['Account_Created']=a['Account_Created'].map(date)
assert (a['Price']*a['Volume']==a['销售额']).all()
def rank(keys):
 b=a.groupby(keys,dropna=False).agg(sales=('销售额','sum'),units=('Volume','sum'),transactions=('Price','size'),mean_transaction_price=('Price','mean'));b['unit_price']=b.sales/b.units
 return b.sort_values('unit_price',ascending=False).reset_index().to_dict('records')
counts=a.Country.value_counts();a['Country_group']=a.Country.where(a.Country.map(counts)>=20,'Other')
table=pd.crosstab(a.Country_group,a.Payment_Type);chi,pvalue,dof,exp=chi2_contingency(table)
age=(a.Transaction_date-a.Account_Created).dt.total_seconds()/86400
valid=age.ge(0)&age.notna();x=pd.DataFrame({'age':age[valid],'sales':a.loc[valid,'销售额']})
report={'rows':len(a),'sales_total':int(a['销售额'].sum()),'units':int(a.Volume.sum()),'city_sales_top':a.groupby(['Country','State','City'])['销售额'].sum().sort_values(ascending=False).head(10).reset_index().to_dict('records'),'country_unit_price':rank(['Country']),'state_unit_price':rank(['Country','State']),'payment_counts':table.reset_index().to_dict('records'),'chi_square':float(chi),'p_value':float(pvalue),'dof':int(dof),'cramers_v':float((chi/(len(a)*min(table.shape[0]-1,table.shape[1]-1)))**.5),'min_expected_count':float(exp.min()),'age_valid_rows':int(valid.sum()),'negative_age_rows':int((age<0).sum()),'age_missing':int(age.isna().sum()),'pearson':float(x.corr(method='pearson').iloc[0,1]),'spearman':float(x.corr(method='spearman').iloc[0,1])}
(w/'transaction-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

print(json.dumps({k:v for k,v in report.items() if k not in ['country_unit_price','state_unit_price','payment_counts']},ensure_ascii=False))

ci,categories=pd.factorize(a.Country_group);pi,methods=pd.factorize(a.Payment_Type);shape=(len(categories),len(methods))
tab=np.bincount(ci*shape[1]+pi,minlength=shape[0]*shape[1]).reshape(shape)
ex=tab.sum(1)[:,None]*tab.sum(0)[None,:]/tab.sum();obs=((tab-ex)**2/ex).sum()
rng=np.random.default_rng(17);exceed=0
for _ in range(9999):
 z=np.bincount(ci*shape[1]+rng.permutation(pi),minlength=shape[0]*shape[1]).reshape(shape)
 exceed+=((z-ex)**2/ex).sum()>=obs
report['permutation_p_value']=float((exceed+1)/10000)
report['permutations']=9999;report['permutation_seed']=17
(w/'transaction-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
