顽岩数据分析题配套资料
来源：QuantMaterial/顽岩.zip内附件。
transaction-anonymous.csv已移除原Name字段。
原Excel第989行Account_Created为2018-02-29，无效日期保留为空。
交易汇总998行；账户存续期相关997个有效样本。
平均单价按总销售额/总销量计算，同时保留交易单价均值。
安装numpy pandas scipy后运行：
python analyze_transactions.py
python analyze_market.py
前一程序生成transaction-results.json，后一程序生成完整result.csv。
股价62331行，4462股票，14个交易日；热门股票91896条记录。
5日均值采用此前5条交易记录，排除当日，最少5条。
DailyReturn保留CLOSE/PRECLOSE-1定义。
热门时间从UTC转换上海自然日。热度为供应数据中的日出现频次占比。
仅有该日热门记录时，未出现股票补0；按股价截面1%/99%分位缩尾。
corr1/corr2分别定义为同日截面Pearson/Spearman相关。
8月31日缩尾后热度为常数，相关性未定义，结果为空。
同期热度与股价水平相关不代表未来收益预测力。
