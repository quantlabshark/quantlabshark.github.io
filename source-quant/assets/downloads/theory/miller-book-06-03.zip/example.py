# -*- coding: utf-8 -*-
from collections import deque
tree=('A',('B',('D',None,None),('E',None,None)),('C',None,None))
def traverse(node,order):
    if order not in ('pre','in','post'):raise ValueError('unknown traversal')
    out=[]
    def visit(current):
        if current is None:return
        value,left,right=current
        if order=='pre':out.append(value)
        visit(left)
        if order=='in':out.append(value)
        visit(right)
        if order=='post':out.append(value)
    visit(node)
    return out
def breadth(root):
    if root is None:return []
    q=deque([root]);out=[]
    while q:
        value,left,right=q.popleft();out.append(value)
        if left:q.append(left)
        if right:q.append(right)
    return out
assert traverse(tree,'in')==list('DBEAC')
assert breadth(tree)==list('ABCDE')
print(traverse(tree,'pre'),traverse(tree,'post'),breadth(tree))
