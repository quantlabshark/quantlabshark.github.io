from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(401);n=12000;x=np.r_[0,np.cumsum(rng.normal(0,.01/np.sqrt(n),n))];y=x+rng.normal(0,.0001,n+1)
steps=np.unique(np.geomspace(1,500,45).astype(int));rv=[np.sum(np.diff(y[::k])**2) for k in steps]
fig,ax=plt.subplots(figsize=(7,3.6));ax.semilogx(steps,rv,label='观测价格');ax.axhline(.01**2,color='#b05b52',ls='--',label='生成方差');ax.set(xlabel='抽样间隔（事件数）',ylabel='已实现方差');ax.legend(frameon=False);save(fig,'volatility-signature.svg')
assert np.isclose(-2e-6/5e-6,-.4)
print('10000笔的噪声偏差',2*10000*1e-8)
