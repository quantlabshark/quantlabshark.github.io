# -*- coding: utf-8 -*-
def insertion_sort(values):
    a=list(values)
    for i in range(1,len(a)):
        key=a[i];j=i-1
        while j>=0 and a[j]>key:
            a[j+1]=a[j];j-=1
        a[j+1]=key
    return a
for a in [[],[1],[5,2,4,1],[2,2,1],list(range(8))]:
    assert insertion_sort(a)==sorted(a)
print(insertion_sort([5,2,4,1]))

def bubble_sort(values):
    a=list(values)
    for end in range(len(a)-1,0,-1):
        changed=False
        for i in range(end):
            if a[i]>a[i+1]:a[i],a[i+1]=a[i+1],a[i];changed=True
        if not changed:break
    return a
def selection_sort(values):
    a=list(values)
    for i in range(len(a)-1):
        smallest=min(range(i,len(a)),key=a.__getitem__)
        a[i],a[smallest]=a[smallest],a[i]
    return a
from itertools import product
for length in range(6):
    for values in product(range(3),repeat=length):
        assert bubble_sort(values)==selection_sort(values)==insertion_sort(values)==sorted(values)
print('three basic sorts checked on all 364 short inputs')
