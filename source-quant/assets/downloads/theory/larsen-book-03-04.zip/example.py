# -*- coding: utf-8 -*-
import numpy as np
x=np.array([-1.,0.,3.]);p=np.array([.4,.3,.3])
mean=np.dot(x,p)
print('E(X)',mean,'E(X^2)',np.dot(x*x,p),'E(X)^2',mean**2)
print('E(3X+2)',np.dot(3*x+2,p))
