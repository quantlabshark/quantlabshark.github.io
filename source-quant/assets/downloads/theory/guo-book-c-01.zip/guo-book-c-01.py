"""Exponential Hawkes thinning, log likelihood, gradient, and Hessian checks."""
from pathlib import Path
import argparse
import json
import numpy as np
from scipy.optimize import minimize
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def simulate(mu, alpha, beta, horizon, seed=20261018):
    rng = np.random.default_rng(seed)
    time, intensity = 0.0, mu
    events = []
    while True:
        upper = intensity
        delay = rng.exponential(1 / upper)
        time += delay
        if time > horizon:
            return np.array(events)
        intensity = mu + (intensity-mu)*np.exp(-beta*delay)
        if rng.random()*upper <= intensity:
            events.append(time)
            intensity += alpha

def likelihood(theta, events, horizon, direct=False):
    mu, alpha, beta = theta
    if mu <= 0 or alpha < 0 or beta <= 0:
        raise ValueError("Need mu > 0, alpha >= 0, beta > 0")
    A = np.zeros(len(events)); B = A.copy(); C = A.copy()
    for i in range(1, len(events)):
        if direct:
            gaps = events[i]-events[:i]
            weights = np.exp(-beta*gaps)
            A[i], B[i], C[i] = weights.sum(), gaps@weights, (gaps*gaps)@weights
        else:
            gap = events[i]-events[i-1]
            decay = np.exp(-beta*gap)
            A[i] = decay*(1+A[i-1])
            B[i] = decay*(B[i-1]+gap*(1+A[i-1]))
            C[i] = decay*(C[i-1]+2*gap*B[i-1]+gap*gap*(1+A[i-1]))
    u = horizon-events
    expu = np.exp(-beta*u)
    D = np.sum(-np.expm1(-beta*u)/beta)
    D1 = np.sum(u*expu/beta + np.expm1(-beta*u)/beta**2)
    D2 = np.sum(-u*u*expu/beta - 2*u*expu/beta**2
                - 2*np.expm1(-beta*u)/beta**3)
    intensity = mu+alpha*A
    value = -mu*horizon-alpha*D + np.log(intensity).sum()
    derivatives = np.column_stack([np.ones(len(A)), A, -alpha*B])
    gradient = np.array([-horizon, -D, -alpha*D1]) + (derivatives/intensity[:, None]).sum(axis=0)
    hessian = -(derivatives.T / intensity**2) @ derivatives
    hessian[1, 2] += -D1-np.sum(B/intensity)
    hessian[2, 1] += -D1-np.sum(B/intensity)
    hessian[2, 2] += -alpha*D2 + np.sum(alpha*C/intensity)
    return float(value), gradient, hessian

def main(output):
    output.mkdir(parents=True, exist_ok=True)
    theta = np.array([0.4, 0.6, 1.0]); horizon = 60.0
    events = simulate(*theta, horizon)
    assert len(events) > 5 and np.all(np.diff(events)>0)
    value, gradient, hessian = likelihood(theta, events, horizon)
    direct = likelihood(theta, events, horizon, direct=True)
    assert np.isclose(value, direct[0])
    assert np.allclose(gradient, direct[1]) and np.allclose(hessian, direct[2])
    eps = 1e-5; grad_fd = []; hess_fd = []
    for i in range(3):
        shift = np.eye(3)[i]*eps
        plus, minus = likelihood(theta+shift, events, horizon), likelihood(theta-shift, events, horizon)
        grad_fd.append((plus[0]-minus[0])/(2*eps))
        hess_fd.append((plus[1]-minus[1])/(2*eps))
    gradient_error = float(np.max(np.abs(gradient-grad_fd)))
    hessian_error = float(np.max(np.abs(hessian-np.array(hess_fd).T)))
    assert gradient_error < 1e-5 and hessian_error < 1e-4
    assert np.allclose(hessian, hessian.T)
    fits = []
    for beta in [0.5, 1.0, 2.0]:
        def objective(x):
            out = likelihood([x[0], x[1], beta], events, horizon)
            return -out[0], -out[1][:2]
        fit = minimize(objective, [0.4, min(0.4, 0.5*beta)], jac=True,
                       bounds=[(1e-6, None), (0, 0.99*beta)], method="L-BFGS-B")
        assert fit.success, fit.message
        fits.append(dict(mu=float(fit.x[0]), alpha=float(fit.x[1]), beta=beta, log_likelihood=float(-fit.fun)))
    assert max(f["log_likelihood"] for f in fits) >= value-1e-8
    report = dict(events=len(events), horizon=horizon, log_likelihood=value,
                  gradient_error=gradient_error, hessian_error=hessian_error,
                  fitted_grid=fits, branching_ratio=float(theta[1]/theta[2]),
                  stationary_mean=float(theta[0]/(1-theta[1]/theta[2])))
    (output/"guo-appendix-c-results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    np.savetxt(output/"guo-appendix-c-events.csv", events, delimiter=",", header="time_seconds", comments="")
    grid = np.linspace(0, min(30, horizon), 2000)
    gaps = grid[:, None]-events
    intensity = theta[0]+theta[1]*np.sum(np.exp(-theta[2]*np.maximum(gaps, 0))*(gaps>0), axis=1)
    plt.rcParams.update({"font.size": 12, "axes.spines.top": False,
                         "axes.spines.right": False, "svg.fonttype": "none"})
    fig, ax = plt.subplots(figsize=(9, 3.8), facecolor="#f7f8f6")
    ax.set_facecolor("#f7f8f6")
    ax.plot(grid, intensity, color="#347b7a", lw=1.8, label=r"$\lambda(t)$")
    ax.axhline(theta[0], color="#b28a57", ls="--", lw=1, label=r"$\mu$")
    ax.eventplot(events[events<=grid[-1]], lineoffsets=-0.12, linelengths=0.12, colors="#263747")
    ax.set(xlabel="Time (s)", ylabel="Events per second", ylim=(-0.25, max(intensity)*1.12))
    ax.legend(frameon=False);ax.grid(alpha=0.14)
    fig.tight_layout();fig.savefig(output/"guo-appendix-c.svg", bbox_inches="tight")
    plt.close(fig)
    print(json.dumps(report))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("outputs"))
    main(parser.parse_args().output)
