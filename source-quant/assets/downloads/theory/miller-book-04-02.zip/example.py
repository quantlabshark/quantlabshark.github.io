# -*- coding: utf-8 -*-
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def sierpinski(a,b,c,depth,ax):
    if depth<0:raise ValueError('negative depth')
    if depth==0:
        ax.fill([a[0],b[0],c[0]],[a[1],b[1],c[1]],color='#31778b')
        return
    mid=lambda p,q:((p[0]+q[0])/2,(p[1]+q[1])/2)
    ab,ac,bc=mid(a,b),mid(a,c),mid(b,c)
    for corners in ((a,ab,ac),(ab,b,bc),(ac,bc,c)):
        sierpinski(*corners,depth-1,ax)
fig,ax=plt.subplots(figsize=(7,6))
sierpinski((0,0),(1,0),(.5,3**.5/2),4,ax)
ax.set_aspect('equal');ax.axis('off');fig.tight_layout()
fig.savefig('sierpinski.png',dpi=180)
print('Saved sierpinski.png')
