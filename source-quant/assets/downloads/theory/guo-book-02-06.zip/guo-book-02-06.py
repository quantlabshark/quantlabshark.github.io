from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
omega=1e-6;alpha=.08;beta=.90;v=omega/(1-alpha-beta)
first=omega+alpha*.03**2+beta*v
h=np.arange(90);forecast=v+(first-v)*(alpha+beta)**h
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(h,np.sqrt(forecast)*100,color='#257b88');ax.axhline(np.sqrt(v)*100,color='#b05b52',ls='--');ax.set(xlabel='冲击后的期数',ylabel='条件标准差（%）');save(fig,'garch-response.svg')
assert np.isclose(first,.000118)
print('长期方差',v,'次期方差',first,'半衰期',np.log(.5)/np.log(.98))
