# -*- coding: utf-8 -*-
from scipy.stats import chisquare
observed=[20,30,25,25];expected=[25]*4
result=chisquare(observed,expected)
assert abs(result.statistic-2)<1e-12
print(result)
