# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import t
rng=np.random.default_rng(9);x=rng.normal(size=(50000,5))
values=x.mean(axis=1)/(x.std(axis=1,ddof=1)/5**.5)
print('simulated quantiles',np.quantile(values,[.025,.975]))
print('theoretical quantiles',t.ppf([.025,.975],4))
