# -*- coding: utf-8 -*-
class Gate:
    def __init__(self,label):self.label=label
    def output(self,active=None):
        active=set() if active is None else active
        if self in active:raise ValueError('circuit cycle')
        active.add(self)
        try:return self.compute(active)
        finally:active.remove(self)
    @staticmethod
    def read(pin,active):
        if isinstance(pin,Gate):return pin.output(active)
        if not isinstance(pin,bool):raise TypeError('boolean or gate required')
        return pin
class BinaryGate(Gate):
    def __init__(self,label,a,b):
        super().__init__(label);self.a,self.b=a,b
class AndGate(BinaryGate):
    def compute(self,active):
        a,b=self.read(self.a,active),self.read(self.b,active)
        return a and b
class OrGate(BinaryGate):
    def compute(self,active):
        a,b=self.read(self.a,active),self.read(self.b,active)
        return a or b
class NotGate(Gate):
    def __init__(self,label,pin):super().__init__(label);self.pin=pin
    def compute(self,active):return not self.read(self.pin,active)
from itertools import product
for a,b,c,d in product([False,True],repeat=4):
    gate=NotGate('result',OrGate('or',AndGate('ab',a,b),AndGate('cd',c,d)))
    assert gate.output()==(not ((a and b) or (c and d)))
print('16 combinations checked; sample',NotGate('Y',OrGate('O',AndGate('L',True,False),AndGate('R',True,True))).output())
loop=NotGate('loop',False);loop.pin=loop
try:loop.output()
except ValueError:print('cycle detected')
else:raise AssertionError('cycle not detected')
