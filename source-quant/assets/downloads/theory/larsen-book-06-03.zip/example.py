# -*- coding: utf-8 -*-
import math
n=10;s=8;p0=.5;phat=s/n
log_lr=s*math.log(p0/phat)+(n-s)*math.log((1-p0)/(1-phat))
print('likelihood ratio',math.exp(log_lr),'minus 2 log ratio',-2*log_lr)
