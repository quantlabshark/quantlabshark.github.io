# 比例、计数与首达时间分布

Python 3.10 或更高版本。

安装依赖：

    python -m pip install numpy scipy matplotlib

运行：

    python calin-book-02-06.py

示例使用模拟数据或题面给出的数据。参数和单位见脚本注释。
