"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

alpha,beta=3,4
mean=integrate.quad(lambda x:x*stats.invgamma.pdf(x,alpha,scale=beta),0,np.inf)[0]
second=integrate.quad(lambda x:x*x*stats.invgamma.pdf(x,alpha,scale=beta),0,np.inf)[0]
mu,lam=2,8
def ig(x):return np.sqrt(lam/(2*np.pi*x**3))*np.exp(-lam*(x-mu)**2/(2*mu**2*x))
mass=integrate.quad(ig,0,np.inf)[0];igmean=integrate.quad(lambda x:x*ig(x),0,np.inf)[0]
assert np.isclose(mean,2) and np.isclose(second-mean**2,4)
assert np.isclose(mass,1) and np.isclose(igmean,mu)
report(inverse_gamma_mean=mean,inverse_gamma_variance=second-mean**2,inverse_gaussian_mass=mass,inverse_gaussian_mean=igmean)
