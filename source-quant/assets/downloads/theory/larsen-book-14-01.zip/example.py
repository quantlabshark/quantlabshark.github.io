# -*- coding: utf-8 -*-
from scipy.stats import binomtest
data=[-2,1,4,3,-1,2,6,1]
positive=sum(x>0 for x in data);n=sum(x!=0 for x in data)
print(binomtest(positive,n,.5))
