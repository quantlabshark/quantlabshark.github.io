# -*- coding: utf-8 -*-
from scipy.stats import binomtest,binom
print('nine positives among ten',binomtest(9,10,.5))
print('median interval X_(2),X_(9) coverage',1-2*binom.cdf(1,10,.5))
