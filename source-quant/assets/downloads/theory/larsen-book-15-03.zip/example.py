# -*- coding: utf-8 -*-
import numpy as np
from itertools import product
levels=np.array(list(product([-1,1],repeat=3)))
a,b,c=levels.T
design=np.column_stack([np.ones(8),a,b,c,a*b,a*c,b*c,a*b*c])
assert np.allclose(design.T@design,8*np.eye(8))
y=10+2*a-b+3*a*b
coef=design.T@y/8
print('coefficients',coef,'effects',2*coef[1:])
