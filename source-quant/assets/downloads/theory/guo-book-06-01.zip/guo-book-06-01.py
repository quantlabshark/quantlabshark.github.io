from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
n=40;t=np.arange(n);volume=1+2*((t-(n-1)/2)/((n-1)/2))**2;twap=np.full(n,100/n);vwap=100*volume/volume.sum()
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(np.r_[0,twap.cumsum()],label='等时等量');ax.plot(np.r_[0,vwap.cumsum()],label='给定成交量曲线');ax.set(xlabel='时段',ylabel='累计买入量');ax.legend(frameon=False);save(fig,'execution-schedules.svg')
cost=lambda q:.01/2*(sum(q)**2+sum(x*x for x in q))
assert np.isclose(cost([25]*4),62.5) and np.isclose(cost([50,0,0,50]),75)
print('两方案冲击成本',cost([25]*4),cost([50,0,0,50]))
