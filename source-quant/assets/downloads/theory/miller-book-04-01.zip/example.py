# -*- coding: utf-8 -*-
def recursive_sum(a,i=0):
    if i==len(a):return 0
    return a[i]+recursive_sum(a,i+1)
assert recursive_sum([2,3,5])==10
assert recursive_sum([])==0
print(recursive_sum([2,3,5]))
