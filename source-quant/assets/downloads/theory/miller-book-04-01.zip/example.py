# -*- coding: utf-8 -*-
def recursive_sum(a,i=0):
    if i==len(a):return 0
    return a[i]+recursive_sum(a,i+1)
assert recursive_sum([2,3,5])==10
assert recursive_sum([])==0
print(recursive_sum([2,3,5]))

def recursive_base(n,base):
    if n<0 or not 2<=base<=16:raise ValueError('require n>=0, base 2..16')
    digits='0123456789ABCDEF'
    if n<base:return digits[n]
    return recursive_base(n//base,base)+digits[n%base]
assert recursive_base(13,2)=='1101'
print('recursive conversion',recursive_base(13,2))
