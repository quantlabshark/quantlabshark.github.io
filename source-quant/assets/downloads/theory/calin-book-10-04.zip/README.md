# Girsanov 定理与漂移变换

Python 3.10 或更高版本。

安装依赖：

    python -m pip install numpy scipy matplotlib

运行：

    python calin-book-10-04.py

示例使用模拟数据或题面给出的数据。参数和单位见脚本注释。
