from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
a=.02;h=.1;fee=.18;q=np.arange(-12,13);target=[]
for x in q:
    z=np.arange(-12,13);cost=a*z*z+h*np.abs(x-z)+fee*(z!=x);target.append(z[np.argmin(cost)])
fig,ax=plt.subplots(figsize=(7,3.8));ax.step(q,target,where='mid',label='最优调整后库存');ax.plot(q,q,'--',color='.6',label='保持库存');ax.axvspan(-5.5,5.5,color='#9ebbb0',alpha=.25);ax.set(xlabel='交易前库存（股）',ylabel='交易后库存（股）');ax.legend(frameon=False);save(fig,'impulse-inventory-band.svg')
assert target[list(q).index(5)]==5 and target[list(q).index(6)] in (2,3)
print('连续库存触发点',h/(2*a)+np.sqrt(fee/a),'卖3股现金增加',300-.03-.05)
