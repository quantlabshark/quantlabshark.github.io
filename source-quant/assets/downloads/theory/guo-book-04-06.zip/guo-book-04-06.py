from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
C=np.array([[1,.9,.9],[.9,1,-.9],[.9,-.9,1.]])
v,U=np.linalg.eigh(C);Cp=(U*np.maximum(v,0))@U.T;d=np.sqrt(np.diag(Cp));Cp=Cp/d[:,None]/d[None,:]
fig,ax=plt.subplots(figsize=(7,3.6));i=np.arange(3);ax.bar(i-.18,v,.35,label='修正前');ax.bar(i+.18,np.linalg.eigvalsh(Cp),.35,label='修正后');ax.axhline(0,color='gray',lw=.7);ax.set(xlabel='特征值序号',ylabel='特征值');ax.legend(frameon=False);save(fig,'covariance-eigenvalues.svg')
assert np.linalg.eigvalsh(Cp).min()>-1e-12
assert (19-7)/4==3
print('修正前特征值',v,'修正后',np.linalg.eigvalsh(Cp))
