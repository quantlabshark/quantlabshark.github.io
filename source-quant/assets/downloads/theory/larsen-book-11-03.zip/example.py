# -*- coding: utf-8 -*-
rho=.6;mu_x,mu_y=100,50;sigma_x,sigma_y=10,8;x=120
conditional_mean=mu_y+rho*sigma_y/sigma_x*(x-mu_x)
conditional_variance=sigma_y**2*(1-rho**2)
print('Y|X=120 mean',conditional_mean,'variance',conditional_variance)
