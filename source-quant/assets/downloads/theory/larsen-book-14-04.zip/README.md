# 游程检验与非参数方法的效率

需要 Python 3.10 或更新版本。

在解压目录打开终端：

本示例仅使用 Python 标准库。

~~~text
python example.py
~~~

程序重现教学示例。检查输出与 expected-output.txt；数值库版本变化可能影响末尾小数。
