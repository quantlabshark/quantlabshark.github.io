# -*- coding: utf-8 -*-
sequence=[1,1,0,0,0,1,1,0]
runs=1+sum(a!=b for a,b in zip(sequence,sequence[1:]))
n1=sum(sequence);n0=len(sequence)-n1;n=n0+n1
mean=1+2*n0*n1/n
variance=2*n0*n1*(2*n0*n1-n)/(n*n*(n-1))
print('runs',runs,'null mean',mean,'variance',variance)
