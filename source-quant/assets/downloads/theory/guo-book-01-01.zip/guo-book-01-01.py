from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
import matplotlib.pyplot as plt
buyers=np.array([106,103,101,98]);sellers=np.array([95,99,102,105])
k=int(np.sum(buyers>=sellers));assert k==2
grid=np.arange(94,108,.05)
buy=(buyers[:,None]>=grid).sum(axis=0);sell=(sellers[:,None]<=grid).sum(axis=0)
fig,ax=plt.subplots(figsize=(7.2,3.8))
ax.step(grid,buy,where='post',label='可买数量',color='#387ca3')
ax.step(grid,sell,where='post',label='可卖数量',color='#b98a49')
ax.set(xlabel='价格',ylabel='单位数',yticks=range(5));ax.legend(frameon=False)
save(fig,'auction-curves.svg')
for alpha in (.2,.4):print('知情比例',alpha,'买价',100-10*alpha,'卖价',100+10*alpha)
print('可成交数量',k)
