# 双向拍卖、交易机制与逆向选择

Python 3.10 或更高版本。

安装依赖：

    python -m pip install numpy matplotlib

运行：

    python guo-book-01-01.py

示例使用模拟数据或题面给出的数据。参数和单位见脚本注释。
