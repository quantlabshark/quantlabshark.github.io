from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(405);n=18000;z=rng.normal(size=(n,2));inc=np.c_[z[:,0],.8*z[:,0]+.6*z[:,1]]/np.sqrt(n);x=np.vstack([np.zeros(2),inc.cumsum(0)]);idx=np.arange(n+1);obs=[]
for prob in [.8,.12]:
    events=np.r_[0,idx[1:][rng.random(n)<prob]];last=events[np.searchsorted(events,idx,side='right')-1];obs.append(last)
y=np.c_[x[obs[0],0],x[obs[1],1]];ks=np.unique(np.geomspace(1,150,35).astype(int));corr=[np.corrcoef(np.diff(y[::k],axis=0).T)[0,1] for k in ks]
fig,ax=plt.subplots(figsize=(7,3.6));ax.semilogx(ks,corr,color='#257b88');ax.axhline(.8,color='#b05b52',ls='--');ax.set(xlabel='公共采样间隔',ylabel='相关系数',ylim=(0,1));save(fig,'epps-effect.svg')
assert np.isclose(.01*(.005+.015)+.02*(.015-.005),.0004)
print('重叠区间协变差',.0004)
