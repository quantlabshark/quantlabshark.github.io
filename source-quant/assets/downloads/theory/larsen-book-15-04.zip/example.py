# -*- coding: utf-8 -*-
import numpy as np
from itertools import product
ab=np.array(list(product([-1,1],repeat=2)));a,b=ab.T;c=a*b
assert np.array_equal(a,b*c) and np.array_equal(a*b,c)
print('A B C',np.column_stack([a,b,c]),'A aliased with BC')
