from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
m=0.;out=[m]
for _ in range(18):m=.5*m+.5*(1-.5*m);out.append(m)
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(out,'o-',color='#257b88');ax.axhline(2/3,color='#b05b52',ls='--');ax.set(xlabel='迭代次数',ylabel='平均交易量');save(fig,'mean-field-fixedpoint.svg')
assert abs(out[-1]-2/3)<1e-9
print('固定点',out[-1],'理论值',2/3)
