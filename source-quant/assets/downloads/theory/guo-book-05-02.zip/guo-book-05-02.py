from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(502);mu=np.array([.4,.3]);G=np.array([[.3,.1],[.2,.25]]);beta=1.5;A=G*beta;t=0.;z=np.zeros(2);events=[];T=100
while t<T:
    bound=(mu+z).sum();dt=rng.exponential(1/bound);t+=dt;z*=np.exp(-beta*dt)
    if t>T:break
    l=mu+z
    if rng.random()<l.sum()/bound:
        j=rng.choice(2,p=l/l.sum());events.append((t,j));z+=A[:,j]
grid=np.linspace(0,T,1500);curves=np.tile(mu[:,None],(1,len(grid)))
for e,j in events:curves+=A[:,j,None]*np.exp(-beta*np.maximum(grid-e,0))[None,:]*(grid>e)
fig,axs=plt.subplots(2,1,figsize=(7,4.4),sharex=True)
for i,ax in enumerate(axs):ax.plot(grid,curves[i],color=['#257b88','#b05b52'][i]);ax.set_ylabel(f'类型{i+1}强度')
axs[-1].set_xlabel('秒');save(fig,'multivariate-hawkes.svg')
mean=np.linalg.solve(np.eye(2)-G,mu);assert np.max(abs(np.linalg.eigvals(G)))<1
print('平均强度',mean,'对称例题',.5/(1-.6))
