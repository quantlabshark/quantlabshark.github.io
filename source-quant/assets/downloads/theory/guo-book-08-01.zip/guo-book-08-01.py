from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--output',default='outputs');args=p.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True)

def fifo(quantities,requested):
    left=min(requested,sum(quantities));result=[]
    for q in quantities:
        fill=min(q,left);result.append(fill);left-=fill
    return result

def pro_rata(quantities,requested):
    total=sum(quantities);requested=min(requested,total)
    if not total:return [0]*len(quantities)
    result=[requested*q//total for q in quantities]
    left=requested-sum(result)
    for i,q in enumerate(quantities):
        extra=min(q-result[i],left);result[i]+=extra;left-=extra
    return result

assert fifo([100,200,300],240)==[100,140,0]
assert pro_rata([100,200,300],240)==[40,80,120]
assert fifo([80,120,200],100)==[80,20,0]
assert pro_rata([80,120,200],100)==[20,30,50]
for requested in range(701):
    for fn in (fifo,pro_rata):
        x=fn([100,200,300],requested)
        assert sum(x)==min(requested,600)
        assert all(0<=v<=q for v,q in zip(x,[100,200,300]))
result={'fifo':fifo([100,200,300],240),'pro_rata':pro_rata([100,200,300],240),'exercise_cash':100*(25+0.003)}
(out/'matching.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
