# -*- coding: utf-8 -*-
from scipy import stats
for n in (16,25,36):
    df=n-1;delta=n**0.5/2;critical=stats.t.ppf(.975,df)
    power=stats.nct.cdf(-critical,df,delta)+stats.nct.sf(critical,df,delta)
    print('n',n,'delta',delta,'power',power)
