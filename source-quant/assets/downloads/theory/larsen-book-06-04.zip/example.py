# -*- coding: utf-8 -*-
from scipy.stats import norm
effect=.1;sigma=1
for n in [25,100,10000]:
    z=effect*n**.5/sigma
    print(n,'same effect',effect,'two-sided p',2*norm.sf(abs(z)))
