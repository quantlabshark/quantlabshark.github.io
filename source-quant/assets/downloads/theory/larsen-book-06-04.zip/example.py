# -*- coding: utf-8 -*-
from scipy.stats import norm
effect=.1;sigma=1
for n in [25,100,10000]:
    z=effect*n**.5/sigma
    print(n,'same effect',effect,'two-sided p',2*norm.sf(abs(z)))

for n,effect in [(10000,.3),(25,3.)]:
    z=effect/(10/n**.5)
    print('article comparison',n,effect,'z',z,'p',2*norm.sf(abs(z)))
print('20 independent tests: at least one false rejection',1-.95**20)
