# -*- coding: utf-8 -*-
import numpy as np
values=np.array([0,1,2]);prob=np.array([.2,.5,.3])
cdf=np.cumsum(prob)
assert np.isclose(prob.sum(),1)
for q in [.25,.5,.8]:
    print(q,values[np.searchsorted(cdf,q,side='left')])
