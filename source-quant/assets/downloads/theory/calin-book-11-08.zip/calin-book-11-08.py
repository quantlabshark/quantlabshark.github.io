"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-08'

k=.6;b=.4;beta=.5;h=.002;n=4000;M=3000;x=rng.normal(size=M);xh=np.zeros(M);P=1.;path=[];err=[];theory=[]
for j in range(n):
    dy=x*h+beta*np.sqrt(h)*rng.normal(size=M);K=P/beta**2;xh+=-k*xh*h+K*(dy-xh*h);x+=-k*x*h+b*np.sqrt(h)*rng.normal(size=M);P+=(-2*k*P+b*b-P*P/beta**2)*h
    if j%10==0:path.append((x[0],xh[0]));err.append(np.mean((x-xh)**2));theory.append(P)
stationary=beta**2*(-k+np.sqrt(k*k+b*b/beta**2));check('Riccati stationary',P,stationary,.001);check('empirical filter error',err[-1],P,.012)
path=np.array(path);t=np.arange(len(path))*h*10;fig,axs=plt.subplots(1,2,figsize=(10,3.7));axs[0].plot(t,path[:,0],alpha=.55,label='Hidden state');axs[0].plot(t,path[:,1],label='Filtered');axs[0].set(xlabel='Time',ylabel='State');axs[0].legend();axs[1].plot(t,theory,label='Riccati');axs[1].plot(t,err,alpha=.7,label='Empirical error');axs[1].set(xlabel='Time',ylabel='Mean square error');axs[1].legend();finish(fig)
