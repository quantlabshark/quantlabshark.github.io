# -*- coding: utf-8 -*-
from collections import deque
def topological(graph):
    vertices=set(graph)
    for neighbors in graph.values():vertices.update(neighbors)
    degree={v:0 for v in vertices}
    for neighbors in graph.values():
        for v in neighbors:degree[v]+=1
    q=deque(sorted(v for v in vertices if degree[v]==0));out=[]
    while q:
        u=q.popleft();out.append(u)
        for v in graph.get(u,[]):
            degree[v]-=1
            if degree[v]==0:q.append(v)
    if len(out)!=len(vertices):raise ValueError('directed cycle')
    return out
graph={'A':['C'],'B':['C'],'C':['D'],'D':[]}
order=topological(graph);position={v:i for i,v in enumerate(order)}
assert all(position[u]<position[v] for u,vs in graph.items() for v in vs)
print(order)

def depth_first(graph):
    color={};discovered={};finished={};clock=0;order=[]
    def visit(u):
        nonlocal clock
        color[u]='gray';clock+=1;discovered[u]=clock
        for v in graph.get(u,[]):
            if color.get(v)=='gray':raise ValueError('directed cycle')
            if v not in color:visit(v)
        color[u]='black';clock+=1;finished[u]=clock;order.append(u)
    vertices=set(graph)
    for neighbors in graph.values():vertices.update(neighbors)
    for u in sorted(vertices):
        if u not in color:visit(u)
    return discovered,finished,order[::-1]
g={'A':['B','C'],'B':['D'],'C':['D'],'D':[]}
d,f,order=depth_first(g)
assert {v:(d[v],f[v]) for v in d}=={'A':(1,8),'B':(2,5),'D':(3,4),'C':(6,7)}
print('discovery',d,'finish',f,'topological',order)
