"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-11-05'

k=.5;theta=.04;sigma=.01;r=.03;t=np.linspace(.01,15,400)
def bond(t):
    mean=theta*t+(r-theta)*(-np.expm1(-k*t))/k
    var=sigma*sigma/k**2*(t-2*(-np.expm1(-k*t))/k+(-np.expm1(-2*k*t))/(2*k))
    return 100*np.exp(-mean+var/2)
check('two year zero coupon price',bond(2),93.49237046504939)
fig,axs=plt.subplots(1,2,figsize=(9,3.7));axs[0].plot(t,bond(t));axs[0].set(xlabel='Maturity',ylabel='Price per 100');axs[1].plot(t,-np.log(bond(t)/100)/t*100);axs[1].set(xlabel='Maturity',ylabel='Continuous yield (%)');finish(fig)
