"""Run with Python 3; requires numpy, scipy and matplotlib.
Optional: --output-dir DIRECTORY. Uses fixed random seeds for reproducibility.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.integrate import quad
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',type=Path,default=Path(__file__).with_suffix(''))
out=parser.parse_args().output_dir
out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261018)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#253e42','xtick.color':'#43585c','ytick.color':'#43585c','axes.edgecolor':'#9aabad','axes.grid':True,'grid.alpha':.18,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'path','savefig.dpi':150,'axes.prop_cycle':plt.cycler(color=['#267e79','#d99a39','#6a75ad','#ba6959','#74a798'])})
metrics={}
def check(name,value,expected,atol=1e-10):
    assert abs(value-expected)<=atol,(name,value,expected,atol)
    metrics[name]={'value':float(value),'expected':float(expected),'tolerance':float(atol)}
def finish(fig):
    fig.tight_layout()
    fig.savefig(out/(SLUG+'.svg'),bbox_inches='tight')
    fig.savefig(out/(SLUG+'.png'),bbox_inches='tight')
    (out/(SLUG+'-checks.json')).write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    print(json.dumps(metrics))
    plt.close(fig)

SLUG='calin-book-08-08'

mu=.08;sigma=.35;x0=1;t=np.linspace(0,4,400);m=x0*np.exp(mu*t);v=x0*x0*np.exp(2*mu*t)*np.expm1(sigma*sigma*t)
z=rng.normal(size=200000);x=x0*np.exp((mu-.5*sigma*sigma)*4+sigma*2*z)
check('GBM mean',x.mean(),m[-1],.015);check('GBM variance',x.var(),v[-1],.05)
fig,ax=plt.subplots(figsize=(7,3.7));median=x0*np.exp((mu-.5*sigma*sigma)*t);lo=median*np.exp(sigma*np.sqrt(t)*norm.ppf(.05));hi=median*np.exp(sigma*np.sqrt(t)*norm.ppf(.95));ax.fill_between(t,lo,hi,alpha=.16,label='5–95% quantiles');ax.plot(t,m,label='Mean');ax.plot(t,median,label='Median');ax.set(xlabel='Time',ylabel='State');ax.legend();finish(fig)
