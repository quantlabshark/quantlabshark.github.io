# -*- coding: utf-8 -*-
import numpy as np
rng=np.random.default_rng(20261018)
n=10000
u=rng.random(n)
x=-np.log1p(-u)/2
print('mean',x.mean(),'variance',x.var(ddof=1),'mean SE',0.5/n**0.5)
print('tail P(X>1)',np.mean(x>1),'theory',np.exp(-2))

def repair_cost(rng,years=2,rate=.8):
    elapsed=0.;total=0
    while True:
        elapsed+=rng.exponential(1/rate)
        if elapsed>years:return total
        total+=rng.choice([80,120])
costs=np.array([repair_cost(rng) for _ in range(10000)])
print('repair mean',costs.mean(),'theory',160,'Monte Carlo SE',(16640/len(costs))**.5)
print('P(cost>200)',np.mean(costs>200))
