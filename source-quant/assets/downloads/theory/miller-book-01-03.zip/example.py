# -*- coding: utf-8 -*-
def mean(values):
    if not values:
        raise ValueError('values must not be empty')
    return sum(values)/len(values)

print(mean([2,4,6]))
assert mean([2,4,6])==4
try:
    mean([])
except ValueError:
    print('empty input rejected')
else:
    raise AssertionError('missing validation')
