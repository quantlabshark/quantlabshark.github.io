# -*- coding: utf-8 -*-
from scipy.stats import beta
a,b=2,2;s,n=6,10
posterior=beta(a+s,b+n-s)
print('posterior mean',posterior.mean())
print('equal-tail credible interval',posterior.ppf([.025,.975]))
