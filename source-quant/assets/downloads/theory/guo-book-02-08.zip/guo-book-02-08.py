from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
rng=np.random.default_rng(208);x=np.r_[rng.normal(size=100),rng.normal(.6,1,100)]
g=[];v=0
for a in x:v=max(0,v+.6*a-.6**2/2);g.append(v)
fig,axs=plt.subplots(2,1,figsize=(7,4.5),sharex=True);axs[0].plot(x,lw=.8);axs[0].axvline(100,color='#b05b52',ls='--');axs[0].set_ylabel('标准化观测');axs[1].plot(g,color='#257b88');axs[1].axhline(5,color='#b05b52',ls='--');axs[1].set(xlabel='时点',ylabel='CUSUM');save(fig,'cusum-change.svg')
assert np.isclose(2*.8**5,.65536)
print('半衰期',np.log(.5)/np.log(.8),'概率门槛',1.1/3)
