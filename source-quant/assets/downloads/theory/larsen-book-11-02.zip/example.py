# -*- coding: utf-8 -*-
import numpy as np
from scipy.stats import t
x=np.array([0.,1.,2.,3.]);y=np.array([1.,2.,2.,4.])
sxx=((x-x.mean())**2).sum();sxy=((x-x.mean())*(y-y.mean())).sum()
b=sxy/sxx;a=y.mean()-b*x.mean();s2=((y-a-b*x)**2).sum()/(len(x)-2)
se=(s2/sxx)**.5;critical=t.ppf(.975,len(x)-2)
assert np.isclose(s2,.35)
print('slope interval',b-critical*se,b+critical*se)
print('at x=mean(x): mean SE',(s2/len(x))**.5,'prediction SE',(s2*(1+1/len(x)))**.5)

from scipy.stats import chi2
se_intercept=(s2*(1/len(x)+x.mean()**2/sxx))**.5
print('intercept CI',a+np.array([-1,1])*critical*se_intercept)
print('variance CI',(s2*(len(x)-2))/chi2.ppf([.975,.025],len(x)-2))
pooled=(3+3)/(5+5-4);se_difference=(pooled*(1/10+1/10))**.5
print('two slopes t',(1.2-.4)/se_difference,'df',6)
