# -*- coding: utf-8 -*-
from scipy.stats import norm
sigma=2;n=25;delta=1;alpha=.05
critical=norm.ppf(1-alpha)
power=norm.sf(critical-delta*n**.5/sigma)
print('critical z',critical,'power',power)
