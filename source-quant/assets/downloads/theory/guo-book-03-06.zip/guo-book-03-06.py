from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
qs=np.arange(11);actions=[]
for q in qs:
    costs=[u*u+1.5*(q-u)**2 for u in range(q+1)];actions.append(int(np.argmin(costs)))
fig,ax=plt.subplots(figsize=(7,3.6));ax.step(qs,actions,where='mid',color='#257b88');ax.set(xlabel='初始剩余量',ylabel='第一期最优买入量');save(fig,'bellman-action.svg')
assert np.argmin([6,2.5,4])==1
assert np.argmin([16,5,4])==2
print('两组风险参数的最优行动',1,2)
