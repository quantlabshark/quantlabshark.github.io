from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
m=np.arange(1,101);prob=1-.95**m
fig,ax=plt.subplots(figsize=(7,3.6));ax.plot(m,prob,color='#257b88');ax.set(xlabel='独立候选策略数量',ylabel='至少一次假阳性概率',ylim=(0,1));save(fig,'multiple-testing.svg')
p=np.array([.008,.020,.040]);holm=p<=.05/np.arange(3,0,-1)
assert holm.all() and (p<=.05/3).sum()==1
print('20项独立检验的总体错误概率',1-.95**20,'Holm拒绝数',holm.sum())
