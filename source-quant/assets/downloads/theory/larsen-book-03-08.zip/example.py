# -*- coding: utf-8 -*-
from scipy.stats import beta
from scipy.integrate import quad
p=quad(lambda x:6*x*(1-x),.25,.75)[0]
assert abs(p-11/16)<1e-12
assert abs(p-(beta.cdf(.75,2,2)-beta.cdf(.25,2,2)))<1e-12
print('middle order statistic probability',p)
