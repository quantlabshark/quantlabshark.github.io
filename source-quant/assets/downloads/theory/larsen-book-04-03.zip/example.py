# -*- coding: utf-8 -*-
from scipy.stats import geom,nbinom
p=.2;r=3
print('trial of first success: mean',geom.mean(p))
print('failures before 3 successes: mean',nbinom.mean(r,p))
print('total trials for 3 successes: mean',nbinom.mean(r,p)+r)
assert abs(nbinom.mean(r,p)+r-r/p)<1e-12
