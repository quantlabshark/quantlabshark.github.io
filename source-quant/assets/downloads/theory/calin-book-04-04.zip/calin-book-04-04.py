"""Independent numerical companion. Run: python this_file.py
Dependencies: numpy, scipy, matplotlib. Figures are saved beside this file in outputs/.
All stochastic examples are simulations with a fixed random seed.
"""
from pathlib import Path
import json
import numpy as np
from scipy import stats, integrate, special
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
OUT = Path(__file__).resolve().parent / "outputs"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#64748b", "axes.labelcolor": "#334155",
    "xtick.color": "#475569", "ytick.color": "#475569",
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.bbox": "tight", "svg.fonttype": "path"})
BLUE, GREEN, ORANGE = "#3478a3", "#238b74", "#ca7b35"
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)
def report(**values):
    print(json.dumps(values, ensure_ascii=False))

u=np.linspace(.001,.999,600);density=1/(np.pi*np.sqrt(u*(1-u)))
fig,ax=plt.subplots(figsize=(8,4.2));ax.plot(u,density,color=BLUE,lw=2)
ax.fill_between(u,0,density,where=(u<=.1)|(u>=.9),color=GREEN,alpha=.25)
ax.set(xlabel="Fraction of observation time",ylabel="Density",ylim=(0,5));save(fig,"arcsine")
tail=4/np.pi*np.arcsin(np.sqrt(.1));central=2/np.pi*(np.arcsin(np.sqrt(.6))-np.arcsin(np.sqrt(.4)))
report(two_extreme_deciles=float(tail),central_fifth=float(central),last_zero_probability=1/3)
