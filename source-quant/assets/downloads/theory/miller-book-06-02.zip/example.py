# -*- coding: utf-8 -*-
from dataclasses import dataclass
import operator
@dataclass
class Node:
    value:object
    left:object=None
    right:object=None
def parse_postfix(tokens):
    stack=[];ops={'+','-','*','/'}
    for token in tokens:
        if token in ops:
            if len(stack)<2:raise ValueError('missing operand')
            right,left=stack.pop(),stack.pop()
            stack.append(Node(token,left,right))
        else:stack.append(Node(float(token)))
    if len(stack)!=1:raise ValueError('invalid expression')
    return stack[0]
def evaluate(node):
    if node.left is None:return node.value
    op={'+':operator.add,'-':operator.sub,'*':operator.mul,'/':operator.truediv}[node.value]
    return op(evaluate(node.left),evaluate(node.right))
root=parse_postfix('3 4 5 * +'.split())
assert evaluate(root)==23
print(evaluate(root))
