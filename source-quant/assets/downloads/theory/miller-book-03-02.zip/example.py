# -*- coding: utf-8 -*-
import operator
def postfix(tokens):
    stack=[];ops={'+':operator.add,'-':operator.sub,'*':operator.mul,'/':operator.truediv}
    for token in tokens:
        if token in ops:
            if len(stack)<2:raise ValueError('missing operand')
            right=stack.pop();left=stack.pop()
            stack.append(ops[token](left,right))
        else:stack.append(float(token))
    if len(stack)!=1:raise ValueError('invalid expression')
    return stack[0]
assert postfix('3 4 2 * +'.split())==11
assert postfix('8 2 -'.split())==6
print(postfix('3 4 + 5 * 6 -'.split()))

def to_postfix(tokens):
    precedence={'+':1,'-':1,'*':2,'/':2}
    operators=[];output=[]
    for token in tokens:
        if token.isalnum():output.append(token)
        elif token=='(':operators.append(token)
        elif token==')':
            while operators and operators[-1]!='(':output.append(operators.pop())
            if not operators:raise ValueError('unmatched closing parenthesis')
            operators.pop()
        elif token in precedence:
            while operators and operators[-1]!='(' and precedence[operators[-1]]>=precedence[token]:
                output.append(operators.pop())
            operators.append(token)
        else:raise ValueError('unknown token')
    if '(' in operators:raise ValueError('unmatched opening parenthesis')
    return output+operators[::-1]
assert to_postfix('A + B * C'.split())==['A','B','C','*','+']
assert to_postfix('( A + B ) * C'.split())==['A','B','+','C','*']
print(to_postfix('A + B * C'.split()))
