from pathlib import Path
import argparse,json
p=argparse.ArgumentParser();p.add_argument('--output',default='outputs');args=p.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=True)

class Arbiter:
    def __init__(self,next_sequence):self.next=next_sequence;self.pending={};self.applied=[]
    def receive(self,sequence,payload):
        if sequence<self.next:return []
        if sequence in self.pending and self.pending[sequence]!=payload:raise ValueError('Conflicting redundant feeds')
        self.pending[sequence]=payload;released=[]
        while self.next in self.pending:
            released.append((self.next,self.pending.pop(self.next)));self.next+=1
        self.applied.extend(released);return released

a=Arbiter(101);events=[('A',101),('A',103),('B',101),('B',102),('B',103),('A',104)]
log=[]
for channel,seq in events:log.append({'channel':channel,'received':seq,'released':a.receive(seq,{'value':seq})})
assert [seq for seq,_ in a.applied]==[101,102,103,104]
gap=Arbiter(101);assert gap.receive(103,{})==[] and gap.next==101
assert 103 in gap.pending
distance=1_200_000
result={'events':log,'air_lower_bound_ms':1000*distance/3e8,'fiber_lower_bound_ms':1000*distance/2e8}
(out/'feed-arbitration.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
