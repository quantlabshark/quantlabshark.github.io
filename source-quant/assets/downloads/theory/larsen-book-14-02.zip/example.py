# -*- coding: utf-8 -*-
from scipy.stats import wilcoxon,mannwhitneyu
print('paired differences',wilcoxon([1.,-2.,3.,4.,-5.],method='exact'))
print('independent groups',mannwhitneyu([1,3,5],[2,6,8],method='exact'))
