# -*- coding: utf-8 -*-
from scipy.stats import wilcoxon,mannwhitneyu
print('paired differences',wilcoxon([-2.,1.,4.,-3.,5.],method='exact'))
print('independent groups',mannwhitneyu([1,4,6],[2,3,5],method='exact'))
