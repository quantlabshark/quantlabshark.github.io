# -*- coding: utf-8 -*-
from scipy.stats import f
ratio=9/4;d1=9;d2=9
print('two-sided equal-tail p',min(1,2*min(f.cdf(ratio,d1,d2),f.sf(ratio,d1,d2))))
print('variance-ratio CI',ratio/f.ppf(.975,d1,d2),ratio/f.ppf(.025,d1,d2))
