from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
from scipy.linalg import eigh
gamma=.1;k=1.;sigma=.2;A=1.;tau=1.;Q=15
q=np.arange(-Q,Q+1);eta=A*(1+gamma/k)**(-(1+k/gamma));c=np.log1p(gamma/k)/gamma
M=np.diag(k*gamma*sigma**2*q*q/2)+np.diag(np.full(2*Q,-eta),1)+np.diag(np.full(2*Q,-eta),-1)
eigenvalues,eigenvectors=eigh(M)
f=eigenvectors@(np.exp(-tau*eigenvalues)*(eigenvectors.T@np.ones(2*Q+1)));assert np.all(f>0)
theta=np.log(f)/k;ask=c+theta[1:]-theta[:-1];bid=c+theta[:-1]-theta[1:]
fig,ax=plt.subplots(figsize=(7,3.8));ax.plot(q[1:],ask,label='卖价相对中间价');ax.plot(q[:-1],-bid,label='买价相对中间价');ax.axhline(0,color='.65',lw=.7);ax.set(xlabel='库存（股）',ylabel='报价偏移');ax.legend(frameon=False);save(fig,'market-making-quotes.svg')
assert np.allclose(theta,theta[::-1]);print('近似中心偏移',-10*gamma*sigma**2*tau,'近似价差',2*c+gamma*sigma**2*tau)
