# -*- coding: utf-8 -*-
n=50;p=.3
information=n/(p*(1-p))
bound=1/information
print('Fisher information',information,'variance lower bound',bound)
assert abs(bound-p*(1-p)/n)<1e-15
