# -*- coding: utf-8 -*-
import numpy as np
x=np.array([[8.,10.,13.],[10.,11.,15.]])
grand=x.mean()
ss_t=x.shape[1]*((x.mean(axis=1)-grand)**2).sum()
ss_b=x.shape[0]*((x.mean(axis=0)-grand)**2).sum()
ss_total=((x-grand)**2).sum();ss_e=ss_total-ss_t-ss_b
stat=ss_t/(ss_e/2)
assert np.isclose(stat,25)
print('treatment, blocks, residual',ss_t,ss_b,ss_e,'F',stat)
