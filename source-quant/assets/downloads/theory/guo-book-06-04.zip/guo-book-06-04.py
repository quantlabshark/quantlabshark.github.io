from pathlib import Path
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
for font_path in ['C:/Windows/Fonts/msyh.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']:
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
        break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'path','axes.labelsize':10,'font.size':10,'figure.facecolor':'white','axes.facecolor':'white'})
OUTPUT=Path(os.environ.get('GUO_FIGURE_DIR','outputs'));OUTPUT.mkdir(parents=True,exist_ok=True)
def save(fig,name):
    fig.tight_layout()
    fig.savefig(OUTPUT/name,format='svg',bbox_inches='tight')
    plt.close(fig)

import numpy as np
t=np.linspace(0,10,300);fig,axs=plt.subplots(1,2,figsize=(8,3.5));axs[0].plot(t,np.exp(-.5*t),color='#257b88');axs[0].set(xlabel='等待时间',ylabel='残留冲击比例');axs[1].plot(t,100*(1-np.exp(-.5*t)),color='#b05b52');axs[1].set(xlabel='往返间隔',ylabel='往返成本');save(fig,'transient-impact.svg')
times=np.arange(8);K=np.exp(-.5*abs(times[:,None]-times[None,:]));assert np.linalg.eigvalsh(K).min()>0
print('例题成本',100*(1-np.exp(-1)),'半衰期',np.log(2)/.5)
