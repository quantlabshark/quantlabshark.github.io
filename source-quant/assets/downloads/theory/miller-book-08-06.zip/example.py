# -*- coding: utf-8 -*-
def prefix(pattern):
    pi=[0]*len(pattern);q=0
    for i in range(1,len(pattern)):
        while q and pattern[i]!=pattern[q]:q=pi[q-1]
        if pattern[i]==pattern[q]:q+=1
        pi[i]=q
    return pi
def kmp(text,pattern):
    if not pattern:return list(range(len(text)+1))
    pi=prefix(pattern);q=0;positions=[]
    for i,ch in enumerate(text):
        while q and ch!=pattern[q]:q=pi[q-1]
        if ch==pattern[q]:q+=1
        if q==len(pattern):
            positions.append(i-len(pattern)+1);q=pi[q-1]
    return positions
assert prefix('ababaca')==[0,0,1,2,3,0,1]
assert kmp('ababa','aba')==[0,2]
assert kmp('aaaaa','aaa')==[0,1,2]
print(kmp('ababa','aba'))

def dfa_table(pattern,alphabet):
    # A direct construction is used to make the state definition visible.
    table={}
    for state in range(len(pattern)+1):
        for char in alphabet:
            candidate=pattern[:state]+char
            table[state,char]=max(q for q in range(len(pattern)+1) if candidate.endswith(pattern[:q]))
    return table
def dfa_match(text,pattern):
    if not pattern:return list(range(len(text)+1))
    table=dfa_table(pattern,set(text)|set(pattern));state=0;positions=[]
    for i,char in enumerate(text):
        state=table[state,char]
        if state==len(pattern):positions.append(i-len(pattern)+1)
    return positions
table=dfa_table('aba','abx')
for q in range(4):print('state',q,[table[q,c] for c in 'abx'])
from itertools import product
for n in range(7):
    for chars in product('ab',repeat=n):
        text=''.join(chars)
        for pattern in ('','a','aba','aaa','ababa'):
            expected=[i for i in range(len(text)-len(pattern)+1) if text[i:i+len(pattern)]==pattern]
            assert kmp(text,pattern)==dfa_match(text,pattern)==expected
print('DFA and KMP agree with direct matching on 127 texts')
