QuantLab 系统课程示例

按课号运行对应 .py 文件，正文见 https://quantlabshark.github.io/courses/ 。
建议 Python 3.11 或更高版本；安装 numpy pandas scipy scikit-learn matplotlib。
示例数据为文中手算数据或固定随机种子产生的模拟数据，不需要行情账号。
代码用于解释计算过程，具体假设、时序和练习解答请结合课程正文。
index.json 列出每课示例数量及原书对应章节。
