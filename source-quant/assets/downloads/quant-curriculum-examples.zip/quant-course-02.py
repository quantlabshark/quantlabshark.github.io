# 02 · 交易品种、收益来源与研究岗位
# https://quantlabshark.github.io/read/?slug=quant-course-02

# 示例 1
stock_profit = 103 - 100 + 2
option_payoff = max(108 - 100, 0)
option_profit = option_payoff - 4
print(stock_profit, option_payoff, option_profit)
