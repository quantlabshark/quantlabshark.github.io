# 01 · 量化研究的基本流程
# https://quantlabshark.github.io/read/?slug=quant-course-01

# 示例 1
strategy_return = 101 / 102 - 1
benchmark_return = 103 / 102 - 1
print(round(strategy_return * 100, 4))
print(round(benchmark_return * 100, 4))
