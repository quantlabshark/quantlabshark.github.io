# 15 · 估计、置信区间与重抽样
# https://quantlabshark.github.io/read/?slug=quant-course-15

# 示例 1
import numpy as np

x = np.array([0.01, -0.02, 0.03, 0.00, 0.02])
mean = x.mean()
se = x.std(ddof=1) / np.sqrt(len(x))
t_critical = 2.7764451052  # df=4, two-sided 95%
print("t interval:", mean - t_critical*se, mean + t_critical*se)

rng = np.random.default_rng(2024)
resamples = rng.choice(x, size=(5000, len(x)), replace=True)
means = resamples.mean(axis=1)
print("percentile interval:", np.quantile(means, [0.025, 0.975]))
assert np.isclose(mean, 0.008)
