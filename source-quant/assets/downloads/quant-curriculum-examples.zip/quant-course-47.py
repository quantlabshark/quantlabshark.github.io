# 47 · 订单不平衡与价格预测
# https://quantlabshark.github.io/read/?slug=quant-course-47

# 示例 1
import numpy as np
imbalance = np.array([-0.9, -0.7, -0.4, -0.1, 0.1, 0.4, 0.7, 0.9])
y = np.array([0, 0, 1, 0, 1, 0, 1, 1], dtype=float)
X = np.column_stack([np.ones(len(y)), imbalance])
beta = np.zeros(2)
for _ in range(2000):
    probability = 1/(1+np.exp(-X@beta))
    gradient = X.T@(probability-y)/len(y)
    gradient[1] += 0.05*beta[1]
    beta -= 0.1*gradient
print('系数', beta.round(4))
print('I=-0.5 与 0.5 的上涨概率', (1/(1+np.exp(-np.array([[1,-0.5],[1,0.5]])@beta))).round(4))
