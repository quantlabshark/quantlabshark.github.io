# 10 · pandas时间序列与数据清洗
# https://quantlabshark.github.io/read/?slug=quant-course-10

# 示例 1
import pandas as pd

raw = pd.DataFrame({
    "date": ["2024-01-03", "2024-01-02", "2024-01-02", "2024-01-04"],
    "close": ["102", "100", "100", "bad"]
})
clean = raw.drop_duplicates().copy()
clean["date"] = pd.to_datetime(clean["date"], errors="coerce")
clean["close"] = pd.to_numeric(clean["close"], errors="coerce")
bad = clean["date"].isna() | clean["close"].isna() | (clean["close"] <= 0)
print("rejected rows:")
print(clean.loc[bad])
clean = clean.loc[~bad].sort_values("date").set_index("date")
assert clean.index.is_unique
clean["return"] = clean["close"].pct_change(fill_method=None)
print(clean)
assert abs(clean["return"].iloc[-1] - 0.02) < 1e-12
