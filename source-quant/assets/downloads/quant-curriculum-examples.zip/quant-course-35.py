# 35 · 神经网络、CNN与LSTM
# https://quantlabshark.github.io/read/?slug=quant-course-35

# 示例 1
import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

x = np.array([1.0, -1.0])
W = np.array([[1.0, 0.5], [-0.5, 1.0]])
v = np.array([1.0, -1.0])
z = x @ W
hidden = np.maximum(z, 0)
prob = sigmoid(hidden @ v)
loss_before = -np.log(prob)  # label y=1
error = prob - 1.0
grad_v = hidden * error
grad_W = np.outer(x, (v * error) * (z > 0))
v -= 0.1 * grad_v
W -= 0.1 * grad_W
prob_after = sigmoid(np.maximum(x @ W, 0) @ v)
print("MLP:", prob, prob_after)
assert -np.log(prob_after) < loss_before

sequence = np.array([1.0, 2.0, 0.0, 3.0])
kernel = np.array([1.0, -1.0])
conv = np.array([sequence[i:i+2] @ kernel for i in range(3)])
activated = np.maximum(conv, 0)
print("CNN local values:", conv, "max pooling:", activated.max())
assert np.allclose(conv, [-1.0, 2.0, -3.0])

h, cell = 0.0, 0.0
for value in [1.0, -1.0]:
    forget = input_gate = output_gate = sigmoid(0.0)
    candidate = np.tanh(value + h)
    cell = forget*cell + input_gate*candidate
    h = output_gate*np.tanh(cell)
    print("LSTM state:", cell, h)
