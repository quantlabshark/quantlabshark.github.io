# 19 · 信号、持仓与回测时序
# https://quantlabshark.github.io/read/?slug=quant-course-19

# 示例 1
import pandas as pd

frame = pd.DataFrame({
    "open": [100.0, 101.0, 103.0, 102.0, 105.0],
    "close": [100.0, 102.0, 101.0, 104.0, 103.0]
})
frame["signal_close"] = (frame["close"].diff() > 0).astype(int)
frame["weight_at_open"] = frame["signal_close"].shift(1).fillna(0)
frame["next_open_return"] = frame["open"].shift(-1) / frame["open"] - 1
intervals = frame.iloc[:-1].copy()
intervals["strategy_return"] = intervals["weight_at_open"] * intervals["next_open_return"]
nav = (1 + intervals["strategy_return"]).cumprod()
print(intervals)
print("total return:", nav.iloc[-1] - 1)
assert abs(nav.iloc[-1] - 102/103) < 1e-12
