# 28 · 线性模型、Ridge与Lasso
# https://quantlabshark.github.io/read/?slug=quant-course-28

# 示例 1
import numpy as np
from sklearn.linear_model import LinearRegression, Ridge, Lasso

X = np.array([[-1.0], [0.0], [1.0]])
y = np.array([-2.0, 0.0, 2.0])
ols = LinearRegression(fit_intercept=False).fit(X, y)
ridge = Ridge(alpha=2.0, fit_intercept=False).fit(X, y)
lasso = Lasso(alpha=1/3, fit_intercept=False, tol=1e-12).fit(X, y)
print(ols.coef_, ridge.coef_, lasso.coef_)
assert np.allclose([ols.coef_[0], ridge.coef_[0], lasso.coef_[0]], [2., 1., 1.5])
