# 22 · 配对、均值回归与季节性
# https://quantlabshark.github.io/read/?slug=quant-course-22

# 示例 1
import numpy as np

training_spread = np.array([2.0, 1.0, 3.0, 2.0])
mu = training_spread.mean()
sd = training_spread.std(ddof=1)
entry_a, entry_b = 104.0, 50.0
exit_a, exit_b = 103.0, 50.5
z = (entry_a - 2*entry_b - mu) / sd
pnl = -(exit_a-entry_a) + 2*(exit_b-entry_b)
print("z:", z, "gross pnl:", pnl)
assert np.isclose(pnl, 2.0)
