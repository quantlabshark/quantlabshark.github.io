# 25 · 因子定义与截面选股
# https://quantlabshark.github.io/read/?slug=quant-course-25

# 示例 1
import pandas as pd

frame = pd.DataFrame({
    "symbol": ["A", "B", "C", "D"],
    "price": [10., 20., 25., 40.],
    "eps_known": [1., 1., 2., 2.]
})
frame["factor"] = frame["eps_known"] / frame["price"]
ranked = frame.sort_values(["factor", "symbol"], ascending=[False, True])
selected = ranked.head(2).copy()
selected["weight"] = 1 / len(selected)
selected["shares_ideal"] = 1000 * selected["weight"] / selected["price"]
print(selected)
assert selected["symbol"].tolist() == ["A", "C"]
assert selected["shares_ideal"].tolist() == [50., 20.]
