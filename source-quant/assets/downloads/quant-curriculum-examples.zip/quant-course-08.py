# 08 · 变量、容器与函数
# https://quantlabshark.github.io/read/?slug=quant-course-08

# 示例 1
def simple_return(start, end):
    if start <= 0 or end <= 0:
        raise ValueError("prices must be positive")
    return end / start - 1

prices = [20.0, 21.0, 20.5]
returns = []
for previous, current in zip(prices[:-1], prices[1:]):
    returns.append(simple_return(previous, current))

account = {"cash": 1000.0, "shares": 0}
quantity = 10
account["cash"] -= quantity * prices[0]
account["shares"] += quantity
wealth = account["cash"] + account["shares"] * prices[-1]

print([round(x, 6) for x in returns])
print(account, wealth)
assert abs(wealth - 1005.0) < 1e-10
