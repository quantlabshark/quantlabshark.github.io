# 17 · 时间序列、平稳性与自相关
# https://quantlabshark.github.io/read/?slug=quant-course-17

# 示例 1
import numpy as np

small = np.array([1.0, 2.0, 1.0, 2.0])
z = small - small.mean()
print("small-sample acf:", (z[1:] @ z[:-1]) / (z @ z))

rng = np.random.default_rng(7)
noise = rng.normal(0, 0.01, 600)
x = np.zeros(600)
for t in range(1, len(x)):
    x[t] = 0.5*x[t-1] + noise[t]
x = x[100:]
z = x - x.mean()
acf1 = (z[1:] @ z[:-1]) / (z @ z)
print("simulated acf:", round(acf1, 4))
assert len(x) == 500
