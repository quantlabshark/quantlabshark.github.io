# 33 · 文本向量化与主题模型
# https://quantlabshark.github.io/read/?slug=quant-course-33

# 示例 1
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation

texts = ["利润 增长", "利润 下降", "订单 增长"]
count = CountVectorizer(tokenizer=str.split, token_pattern=None, lowercase=False)
counts = count.fit_transform(texts)
tfidf = TfidfVectorizer(tokenizer=str.split, token_pattern=None,
                       lowercase=False, norm=None)
weighted = tfidf.fit_transform(texts)
print(count.get_feature_names_out())
print(counts.toarray())
print("idf:", dict(zip(tfidf.get_feature_names_out(), tfidf.idf_)))
assert np.isclose(tfidf.idf_[list(tfidf.get_feature_names_out()).index("利润")], np.log(4/3)+1)

corpus = ["利润 增长 订单", "订单 扩张 收入", "收入 利润 增长",
          "降雨 洪水 天气", "天气 降雨 风暴", "洪水 风暴 救援"]
vectorizer = CountVectorizer(tokenizer=str.split, token_pattern=None, lowercase=False)
X = vectorizer.fit_transform(corpus)
lda = LatentDirichletAllocation(n_components=2, max_iter=30,
                               learning_method="batch", random_state=3)
mixtures = lda.fit_transform(X)
terms = vectorizer.get_feature_names_out()
for topic in lda.components_:
    print("top terms:", terms[np.argsort(topic)[-4:][::-1]])
print("document topic weights:", np.round(mixtures, 3))
assert np.allclose(mixtures.sum(axis=1), 1.0)
