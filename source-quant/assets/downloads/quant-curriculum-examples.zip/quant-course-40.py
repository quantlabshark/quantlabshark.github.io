# 40 · 参数不确定性与重抽样组合
# https://quantlabshark.github.io/read/?slug=quant-course-40

# 示例 1
import numpy as np
returns = np.array([[0.02, 0.01], [-0.01, 0.03], [0.03, -0.02],
                    [0.01, 0.02], [-0.02, -0.01], [0.02, 0.04]])
rng = np.random.default_rng(2026)
grid = np.linspace(0, 1, 1001)
weights = np.column_stack([grid, 1 - grid])
chosen = []
for _ in range(500):
    sample = returns[rng.integers(0, len(returns), len(returns))]
    cov = np.cov(sample, rowvar=False) + 1e-8 * np.eye(2)
    risk = np.einsum('ij,jk,ik->i', weights, cov, weights)
    chosen.append(weights[np.argmin(risk)])
chosen = np.array(chosen)
print('mean weights:', chosen.mean(axis=0))
print('A weight percentiles:', np.quantile(chosen[:, 0], [0.1, 0.5, 0.9]))
