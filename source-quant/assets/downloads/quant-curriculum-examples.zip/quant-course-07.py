# 07 · Python环境与第一个实验
# https://quantlabshark.github.io/read/?slug=quant-course-07

# 示例 1
import sys

prices = [100.0, 110.0, 99.0]
first_price = prices[0]
last_price = prices[-1]
total_return = last_price / first_price - 1

print("Python:", sys.version.split()[0])
print("prices:", prices)
print("total return:", round(total_return, 6))
assert abs(total_return - (-0.01)) < 1e-12
