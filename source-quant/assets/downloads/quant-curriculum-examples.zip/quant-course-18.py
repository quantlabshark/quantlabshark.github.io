# 18 · 假设检验与多重比较
# https://quantlabshark.github.io/read/?slug=quant-course-18

# 示例 1
from math import comb

def upper_tail(k, n):
    return sum(comb(n, j) for j in range(k, n + 1)) / 2**n

print(upper_tail(8, 10))
print(upper_tail(9, 10))
print("20 independent tests:", 1 - 0.95**20)
print("Bonferroni threshold:", 0.05 / 20)
assert upper_tail(8, 10) == 56/1024
