# 14 · 期望、方差与协方差
# https://quantlabshark.github.io/read/?slug=quant-course-14

# 示例 1
import numpy as np

a = np.array([-0.02, 0.00, 0.02])
b = np.array([0.01, 0.00, -0.01])
cov = np.cov(np.vstack([a, b]), ddof=1)
weights = np.array([0.5, 0.5])
portfolio = 0.5*a + 0.5*b
print(cov)
print(np.corrcoef(a, b)[0, 1])
print(portfolio.std(ddof=1))
assert np.isclose(weights @ cov @ weights, portfolio.var(ddof=1))
