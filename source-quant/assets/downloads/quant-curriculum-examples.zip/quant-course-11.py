# 11 · 行情、财务与文本数据
# https://quantlabshark.github.io/read/?slug=quant-course-11

# 示例 1
import pandas as pd

prices = pd.DataFrame({"symbol": ["A", "B"], "close": [40.0, 25.0]})
fundamentals = pd.DataFrame({"symbol": ["A", "B"], "eps_known": [2.0, 1.0]})
joined = prices.merge(fundamentals, on="symbol", validate="one_to_one")
joined["earnings_yield"] = joined["eps_known"] / joined["close"]
print(joined[["symbol", "earnings_yield"]])
assert joined["earnings_yield"].round(6).tolist() == [0.05, 0.04]
