# 43 · 随机游走、布朗运动与鞅
# https://quantlabshark.github.io/read/?slug=quant-course-43

# 示例 1
import numpy as np
rng = np.random.default_rng(43)
n, paths, T = 252, 20000, 1.0
dw = rng.normal(0.0, np.sqrt(T/n), (paths, n))
wT = dw.sum(axis=1)
qv = (dw*dw).sum(axis=1)
S0, mu, sigma = 100.0, 0.06, 0.20
ST = S0*np.exp((mu-0.5*sigma*sigma)*T + sigma*wT)
print('平均二次变差', round(qv.mean(), 4))
print('终值样本均值、理论均值', round(ST.mean(), 3), round(S0*np.exp(mu*T), 3))
