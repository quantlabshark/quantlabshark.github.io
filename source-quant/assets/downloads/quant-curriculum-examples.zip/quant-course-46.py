# 46 · 订单簿重建与成交机制
# https://quantlabshark.github.io/read/?slug=quant-course-46

# 示例 1
from collections import deque
ask = {10000: deque([['A', 60], ['B', 40]]),
       10001: deque([['C', 150]])}
def buy_market(quantity):
    fills = []
    for price in sorted(list(ask)):
        queue = ask[price]
        while queue and quantity:
            oid, available = queue[0]
            size = min(quantity, available)
            fills.append((oid, price, size))
            quantity -= size
            queue[0][1] -= size
            if queue[0][1] == 0:
                queue.popleft()
        if not queue:
            del ask[price]
        if not quantity:
            break
    return fills, quantity
fills, unfilled = buy_market(180)
cost = sum(price*size for _, price, size in fills)
print(fills, '未成交', unfilled)
print('成交均价', cost/180/100)
assert fills == [('A', 10000, 60), ('B', 10000, 40), ('C', 10001, 80)]
assert ask[10001][0][1] == 70
