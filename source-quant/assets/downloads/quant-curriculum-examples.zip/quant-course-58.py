# 58 · 做市报价、库存与脉冲控制
# https://quantlabshark.github.io/read/?slug=quant-course-58

# 示例 1
import math
s, gamma, sigma, tau, k = 100.0, 0.1, 2.0, 1.0, 1.5
spread = gamma*sigma*sigma*tau + 2/gamma*math.log1p(gamma/k)
for inventory in [-1,0,1]:
    reservation = s-inventory*gamma*sigma*sigma*tau
    bid, ask = reservation-spread/2, reservation+spread/2
    print('库存',inventory,'保留价',round(reservation,4),
          '买价',round(bid,4),'卖价',round(ask,4))
assert spread > 0
