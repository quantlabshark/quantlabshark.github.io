# 34 · 朴素贝叶斯与情绪分类
# https://quantlabshark.github.io/read/?slug=quant-course-34

# 示例 1
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import confusion_matrix

texts = ["利润 增长", "订单 增长", "利润 下降", "订单 下降"]
labels = [1, 1, 0, 0]
model = make_pipeline(
    CountVectorizer(tokenizer=str.split, token_pattern=None, lowercase=False),
    MultinomialNB(alpha=1.0)
)
model.fit(texts, labels)
prob = model.predict_proba(["利润 增长"])[0]
print("probability for classes 0,1:", prob)
assert np.allclose(prob, [0.25, 0.75])
check_texts = ["订单 增长", "利润 下降"]
check_labels = [1, 0]
print(confusion_matrix(check_labels, model.predict(check_texts), labels=[0, 1]))
print("negation example:", model.predict_proba(["利润 不 增长"])[0])
