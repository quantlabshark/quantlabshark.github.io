# 09 · NumPy数组与向量运算
# https://quantlabshark.github.io/read/?slug=quant-course-09

# 示例 1
import numpy as np

prices = np.array([100, 102, 101, 104], dtype=float)
returns = prices[1:] / prices[:-1] - 1
wealth = np.concatenate(([1.0], np.cumprod(1 + returns)))
print(np.round(returns, 6))
print(np.round(wealth, 6))
assert np.isclose(wealth[-1], 1.04)

# 示例 2
matrix = np.array([[0.02, 0.00], [-0.01, 0.01], [0.03, -0.01]])
weights = np.array([0.6, 0.4])
portfolio = matrix @ weights
print(matrix.shape)
print(np.round(portfolio, 6))
print(np.round(matrix.mean(axis=0), 6))
assert np.allclose(portfolio, [0.012, -0.002, 0.014])
