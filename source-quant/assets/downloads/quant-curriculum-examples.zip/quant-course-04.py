# 04 · 收益、复利与净值
# https://quantlabshark.github.io/read/?slug=quant-course-04

# 示例 1
import math
wealth = 10000 * 1.10 * 0.90
log_total = math.log(1.10) + math.log(0.90)
print(round(wealth, 2))
print(round(math.exp(log_total) - 1, 6))
