# 16 · 回归与残差分析
# https://quantlabshark.github.io/read/?slug=quant-course-16

# 示例 1
import numpy as np

x = np.array([0.0, 1.0, 2.0, 3.0])
y = np.array([1.0, 2.0, 2.0, 4.0])
X = np.column_stack([np.ones(len(x)), x])
coef, _, rank, _ = np.linalg.lstsq(X, y, rcond=None)
fitted = X @ coef
residual = y - fitted
print("intercept, slope:", coef)
print("residual:", residual)
print("prediction at x=4:", np.array([1.0, 4.0]) @ coef)
assert rank == 2
assert np.allclose(coef, [0.9, 0.9])
assert np.isclose(residual @ residual, 0.7)
