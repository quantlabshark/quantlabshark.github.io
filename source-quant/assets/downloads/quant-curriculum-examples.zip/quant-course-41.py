# 41 · 多期配置、再平衡与成本
# https://quantlabshark.github.io/read/?slug=quant-course-41

# 示例 1
def rebalance_with_cost(current, target, risk_curvature, fee):
    gap = target - current
    distance = max(abs(gap) - fee / risk_curvature, 0.0)
    return current + (distance if gap >= 0 else -distance)

for target in [0.51, 0.54, 0.65]:
    result = rebalance_with_cost(0.50, target, 2.0, 0.05)
    print(target, result)
