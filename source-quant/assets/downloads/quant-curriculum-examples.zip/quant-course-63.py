# 63 · 市场规则与交易约束的核查
# https://quantlabshark.github.io/read/?slug=quant-course-63

# 示例 1
from decimal import Decimal
def valid_order(side,quantity,price,available_sell,
                lot=100,tick=Decimal('0.01')):
    price=Decimal(str(price))
    if side not in ('buy','sell'):return False
    if quantity<=0 or quantity%lot:return False
    if price<=0 or price%tick:return False
    if side=='sell' and quantity>available_sell:return False
    return True
assert valid_order('buy',200,'10.02',300)
assert not valid_order('buy',150,'10.02',300)
assert not valid_order('sell',400,'10.02',300)
assert not valid_order('buy',200,'10.025',300)
