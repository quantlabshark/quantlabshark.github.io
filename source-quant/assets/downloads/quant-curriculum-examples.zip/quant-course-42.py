# 42 · 资本增长、风险预算与组合检验
# https://quantlabshark.github.io/read/?slug=quant-course-42

# 示例 1
import math
import numpy as np
for f in [0.1, 0.5]:
    growth = 0.55 * math.log1p(f) + 0.45 * math.log1p(-f)
    print(f, growth)
w = np.array([2 / 3, 1 / 3])
cov = np.diag([0.1 ** 2, 0.2 ** 2])
vol = math.sqrt(float(w @ cov @ w))
contribution = w * (cov @ w) / vol
print('volatility:', vol, 'risk contributions:', contribution)
