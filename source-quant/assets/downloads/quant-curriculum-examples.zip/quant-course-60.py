# 60 · 暗池、删失数据与流动性分配
# https://quantlabshark.github.io/read/?slug=quant-course-60

# 示例 1
import numpy as np
orders = np.array([2,4,3,4,5])
fills = np.array([2,1,3,4,2])
survival = 1.0
for j in range(5):
    at_risk = (orders>j)&(fills>=j)
    count = int(at_risk.sum())
    failures = int(((orders>j)&(fills==j)).sum())
    if count == 0:
        print('从数量',j+1,'开始尾概率未识别')
        break
    survival *= 1-failures/count
    print('T(',j+1,')=',round(survival,6),'风险集',count)
tails = [[0.9,0.5,0.2,0.0],[0.8,0.7,0.1,0.0]]
allocation = [0,0]
for _ in range(4):
    marginal = [tails[i][allocation[i]] for i in range(2)]
    chosen = int(np.argmax(marginal))
    allocation[chosen] += 1
expected = sum(sum(tails[i][:allocation[i]]) for i in range(2))
print('最优整数分配',allocation,'期望成交',expected)
assert allocation == [2,2] and np.isclose(expected,2.9)
