# 37 · 均值方差与有效前沿
# https://quantlabshark.github.io/read/?slug=quant-course-37

# 示例 1
import numpy as np
mu = np.array([0.08, 0.12])
cov = np.array([[0.04, 0.03], [0.03, 0.09]])
rows = []
for a in np.linspace(0, 1, 1001):
    w = np.array([a, 1 - a])
    rows.append((float(w @ cov @ w), float(w @ mu), a))
best = min(rows)
print('minimum variance:', best)
for a in [0, 0.25, 0.5, 0.75, 1]:
    w = np.array([a, 1 - a])
    print(a, w @ mu, np.sqrt(w @ cov @ w))
