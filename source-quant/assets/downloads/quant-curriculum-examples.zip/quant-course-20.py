# 20 · 移动平均与趋势策略
# https://quantlabshark.github.io/read/?slug=quant-course-20

# 示例 1
import pandas as pd

frame = pd.DataFrame({
    "open": [100., 100., 101., 102., 101., 100., 103., 105.],
    "close": [100., 101., 102., 101., 100., 103., 105., 104.]
})
frame["fast"] = frame["close"].rolling(2, min_periods=2).mean()
frame["slow"] = frame["close"].rolling(3, min_periods=3).mean()
ready = frame["fast"].notna() & frame["slow"].notna()
frame["target_close"] = (ready & (frame["fast"] > frame["slow"])).astype(int)
frame["position_open"] = frame["target_close"].shift(1).fillna(0)
forward = frame["open"].shift(-1) / frame["open"] - 1
result = frame.iloc[:-1].copy()
result["return"] = result["position_open"] * forward.iloc[:-1]
print(result[["fast", "slow", "target_close", "position_open", "return"]])
assert frame.loc[2, "target_close"] == 1
assert frame.loc[4, "target_close"] == 0
