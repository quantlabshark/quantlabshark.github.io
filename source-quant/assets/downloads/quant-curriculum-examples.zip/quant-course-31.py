# 31 · 支持向量机与动态选因子
# https://quantlabshark.github.io/read/?slug=quant-course-31

# 示例 1
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline

rng = np.random.default_rng(31)
X = rng.normal(size=(120, 4))
y = (X[:, 0] - 0.7*X[:, 1] + 0.3*rng.normal(size=120) > 0).astype(int)
for cutoff in [60, 80]:
    model = Pipeline([
        ("select", SelectFromModel(
            DecisionTreeClassifier(max_depth=3, random_state=1),
            threshold=-np.inf, max_features=2)),
        ("scale", StandardScaler()),
        ("svm", SVC(kernel="rbf", C=1.0, gamma="scale"))
    ])
    model.fit(X[:cutoff], y[:cutoff])
    chosen = np.flatnonzero(model.named_steps["select"].get_support())
    print("cutoff:", cutoff, "selected:", chosen)
    print("next block:", model.predict(X[cutoff:cutoff+10]))
    assert len(chosen) == 2
