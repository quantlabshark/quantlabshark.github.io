# 32 · 新闻数据、分词与发布时间
# https://quantlabshark.github.io/read/?slug=quant-course-32

# 示例 1
import re
import html
import unicodedata
import pandas as pd

def clean_text(text):
    text = unicodedata.normalize("NFKC", html.unescape(text))
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def segment(text):
    vocabulary = sorted(["公司", "利润", "下降", "增长", "亏损", "改善", "不"], key=len, reverse=True)
    tokens, i = [], 0
    while i < len(text):
        if text[i].isspace():
            i += 1
            continue
        token = next((w for w in vocabulary if text.startswith(w, i)), text[i])
        tokens.append(token)
        i += len(token)
    return [w for w in tokens if w not in {"公司"}]

news = pd.DataFrame({
    "event": ["E1", "E1", "E2"],
    "received": pd.to_datetime(["2024-01-02 09:02", "2024-01-02 09:05", "2024-01-02 09:06"], utc=True),
    "text": ["<p>公司利润不下降</p>", "公司利润不下降", "公司利润下降"]
})
news["clean"] = news["text"].map(clean_text)
news = news.sort_values("received").drop_duplicates(["event", "clean"])
known = news.loc[news["received"] <= pd.Timestamp("2024-01-02 09:03", tz="UTC")].copy()
known["tokens"] = known["clean"].map(segment)
print(known[["event", "tokens"]])
assert known["tokens"].iloc[0] == ["利润", "不", "下降"]
