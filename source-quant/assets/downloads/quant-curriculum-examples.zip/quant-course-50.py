# 50 · 噪声修正、双尺度与已实现核
# https://quantlabshark.github.io/read/?slug=quant-course-50

# 示例 1
import numpy as np
rng = np.random.default_rng(50)
n, T, true_v, noise_var = 400, 1.0, 0.04, 0.0001
x = np.r_[0., np.cumsum(rng.normal(0, np.sqrt(true_v/n), n))]
y = x + rng.normal(0, np.sqrt(noise_var), n+1)
r = np.diff(y)
K = 20
rv = np.array([np.sum(np.diff(y[j::K])**2) for j in range(K)])
nbar = np.mean([len(y[j::K])-1 for j in range(K)])
all_rv = r@r
ts = (rv.mean() - nbar/n*all_rv)/(1-nbar/n)
# 三对角噪声矩阵的特征值、正交正弦基
j = np.arange(1, n+1)
U = np.sqrt(2/(n+1))*np.sin(np.pi*np.outer(j,j)/(n+1))
eigen_noise = 2-2*np.cos(np.pi*j/(n+1))
z2 = (U.T@r)**2
best = (np.inf, None, None)
for v in np.linspace(0.01, 0.08, 71):
    for eta2 in np.linspace(0.00002, 0.0002, 73):
        eig = v*T/n + eta2*eigen_noise
        loss = 0.5*np.sum(np.log(eig)+z2/eig)
        if loss < best[0]:
            best = (loss, v, eta2)
print('真实 IV、原始 RV、双尺度', true_v*T, all_rv, ts)
print('QMLE 方差率、噪声方差', best[1:])
