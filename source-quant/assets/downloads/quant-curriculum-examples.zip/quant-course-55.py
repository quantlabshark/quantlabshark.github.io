# 55 · TWAP、VWAP与最优执行
# https://quantlabshark.github.io/read/?slug=quant-course-55

# 示例 1
import numpy as np
Q, T, eta, risk = 1.0, 1.0, 1.0, 4.0  # risk = lambda*sigma^2
kappa = np.sqrt(risk/eta)
t = np.linspace(0,T,2001)
x = Q*np.sinh(kappa*(T-t))/np.sinh(kappa*T)
speed = Q*kappa*np.cosh(kappa*(T-t))/np.sinh(kappa*T)
integrand = eta*speed**2 + risk*x**2
cost = np.sum((integrand[1:]+integrand[:-1])*np.diff(t)/2)
twap_cost = eta*Q**2/T + risk*Q**2*T/3
print('最优目标、TWAP目标', cost, twap_cost)
print('四段成交比例', -np.diff(Q*np.sinh(kappa*(T-np.linspace(0,T,5)))/np.sinh(kappa*T)))
assert np.isclose(x[0],Q) and np.isclose(x[-1],0)
assert cost < twap_cost
