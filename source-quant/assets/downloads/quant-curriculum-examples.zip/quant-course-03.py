# 03 · 报价、订单与成交
# https://quantlabshark.github.io/read/?slug=quant-course-03

# 示例 1
cash_paid = 100 * 100.10 + 50 * 100.20
average_price = cash_paid / 150
mid_price = (99.90 + 100.10) / 2
print(round(average_price, 4))
print(round(cash_paid - 150 * mid_price, 2))
