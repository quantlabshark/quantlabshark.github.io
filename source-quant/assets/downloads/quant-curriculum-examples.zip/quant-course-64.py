# 64 · 衍生品、波动率与后续学习
# https://quantlabshark.github.io/read/?slug=quant-course-64

# 示例 1
def payoffs(spot,strike):
    call=max(spot-strike,0)
    put=max(strike-spot,0)
    return call,put,spot-strike
for s in [70,100,130]:
    c,p,f=payoffs(s,100)
    assert c-p==f
