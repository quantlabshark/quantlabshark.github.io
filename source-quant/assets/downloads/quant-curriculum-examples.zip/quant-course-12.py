# 12 · 信息时间与可复现的数据集
# https://quantlabshark.github.io/read/?slug=quant-course-12

# 示例 1
import pandas as pd

releases = pd.DataFrame({
    "available_at": pd.to_datetime(["2024-02-28 16:00", "2024-03-01 09:00"], utc=True),
    "value": [1.0, 1.2]
})
decisions = pd.DataFrame({
    "decision_at": pd.to_datetime(["2024-03-01 08:00", "2024-03-01 10:00"], utc=True)
})
result = pd.merge_asof(
    decisions.sort_values("decision_at"),
    releases.sort_values("available_at"),
    left_on="decision_at", right_on="available_at", direction="backward"
)
print(result)
assert result["value"].tolist() == [1.0, 1.2]
assert (result["available_at"] <= result["decision_at"]).all()
