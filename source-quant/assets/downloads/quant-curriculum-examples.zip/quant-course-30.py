# 30 · 决策树与随机森林
# https://quantlabshark.github.io/read/?slug=quant-course-30

# 示例 1
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance

X = np.array([[1.0], [2.0], [3.0], [4.0]])
y = np.array([0, 0, 1, 1])
stump = DecisionTreeClassifier(max_depth=1, random_state=1).fit(X, y)
print("threshold:", stump.tree_.threshold[0])
assert np.isclose(stump.tree_.threshold[0], 2.5)

rng = np.random.default_rng(11)
features = rng.normal(size=(120, 3))
labels = ((features[:, 0] > 0) != (features[:, 1] > 0)).astype(int)
forest = RandomForestClassifier(n_estimators=100, max_depth=4,
                                min_samples_leaf=3, random_state=11)
forest.fit(features[:80], labels[:80])
print("later-sample accuracy:", forest.score(features[80:], labels[80:]))
importance = permutation_importance(forest, features[80:], labels[80:],
                                   n_repeats=10, random_state=11)
print("permutation importance:", importance.importances_mean)
