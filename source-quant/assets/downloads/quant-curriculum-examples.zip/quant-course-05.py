# 05 · 波动、回撤与分散投资
# https://quantlabshark.github.io/read/?slug=quant-course-05

# 示例 1
import math
mean = (-0.02 + 0 + 0.02 + 0.04) / 4
variance = ((-0.02-mean)**2 + (0-mean)**2
            + (0.02-mean)**2 + (0.04-mean)**2) / 4
print(round(math.sqrt(variance), 6))
print(round(0.90 / 1.20 - 1, 6))
