# 62 · 操作风险、策略风险与监控
# https://quantlabshark.github.io/read/?slug=quant-course-62

# 示例 1
def check_buy(current,pending,new,price,max_quantity,max_notional):
    if any(x<0 for x in (pending,new)) or price<=0:
        return False,'字段不合法'
    worst=current+pending+new
    if worst>max_quantity:return False,'数量超过上限'
    if worst*price>max_notional:return False,'金额超过上限'
    return True,'通过'
assert check_buy(200,100,100,10,300,10000)[0] is False
assert check_buy(100,50,50,10,300,10000)[0] is True
