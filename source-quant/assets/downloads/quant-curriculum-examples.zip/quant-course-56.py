# 56 · 价格冲击与订单簿恢复
# https://quantlabshark.github.io/read/?slug=quant-course-56

# 示例 1
import numpy as np
Q, depth, a = 1000.0, 10000.0, 0.5
def cost(trades):
    u = np.asarray(trades,dtype=float)
    index = np.arange(len(u))
    kernel = a**np.abs(index[:,None]-index[None,:])
    return u@kernel@u/(2*depth)
print('一次、两次、三次最优', cost([Q]), cost([Q/2,Q/2]), cost([400,200,400]))
print('三次等量', cost([Q/3]*3))
assert np.isclose(cost([Q]),50)
assert np.isclose(cost([Q/2,Q/2]),37.5)
assert np.isclose(cost([400,200,400]),30)
