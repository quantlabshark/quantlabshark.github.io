# 06 · 研究问题、数据与检验
# https://quantlabshark.github.io/read/?slug=quant-course-06

# 示例 1
negative_group_mean = (0.01 + 0.02 - 0.01) / 3
other_group_mean = (-0.01 + 0 + 0.01) / 3
print(round(negative_group_mean, 6))
print(round(negative_group_mean - other_group_mean, 6))
