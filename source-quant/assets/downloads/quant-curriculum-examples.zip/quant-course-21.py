# 21 · 突破、海龟与仓位管理
# https://quantlabshark.github.io/read/?slug=quant-course-21

# 示例 1
import pandas as pd

frame = pd.DataFrame({
    "high": [10.5, 11.5, 12.5, 11.5, 12.5, 13.5, 14.5, 13.5],
    "low": [9.5, 10.5, 11.5, 10.5, 11.5, 12.5, 13.5, 12.5],
    "close": [10., 11., 12., 11., 12., 13., 14., 13.]
})
frame["upper"] = frame["high"].rolling(3).max().shift(1)
frame["lower"] = frame["low"].rolling(3).min().shift(1)
previous = frame["close"].shift(1)
true_range = pd.concat([
    frame["high"]-frame["low"],
    (frame["high"]-previous).abs(),
    (frame["low"]-previous).abs()
], axis=1).max(axis=1)
frame["atr"] = true_range.rolling(3).mean()
state = 0
targets = []
for row in frame.itertuples():
    if pd.notna(row.upper):
        if row.close > row.upper:
            state = 1
        elif row.close < row.lower:
            state = 0
    targets.append(state)
frame["target_close"] = targets
print(frame)
assert frame.loc[5, "target_close"] == 1
