# 49 · 买卖价反弹与已实现波动率
# https://quantlabshark.github.io/read/?slug=quant-course-49

# 示例 1
import numpy as np
rng = np.random.default_rng(49)
n, repetitions = 10000, 300
sigma, noise_sd = 0.02, 0.001
results = {k: [] for k in [1, 5, 20, 100]}
for _ in range(repetitions):
    x = np.r_[0.0, np.cumsum(rng.normal(0, sigma/np.sqrt(n), n))]
    y = x + rng.normal(0, noise_sd, n+1)
    for k in results:
        results[k].append(np.sum(np.diff(y[::k])**2))
for k, values in results.items():
    theoretical = sigma*sigma + 2*(n//k)*noise_sd**2
    print(k, round(np.mean(values), 6), round(theoretical, 6))
