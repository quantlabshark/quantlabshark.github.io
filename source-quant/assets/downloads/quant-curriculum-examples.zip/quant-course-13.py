# 13 · 概率、条件概率与抽样
# https://quantlabshark.github.io/read/?slug=quant-course-13

# 示例 1
signal_up = 7
signal_days = 10
print(signal_up / signal_days)
posterior = 0.90 * 0.01 / (0.90 * 0.01 + 0.05 * 0.99)
print(round(posterior, 6))
assert abs(posterior - 2/13) < 1e-12
