# -*- coding: utf-8 -*-

# 示例 1
import random, math
rng=random.Random(17)
M=100000
hits=0
for _ in range(M):
    t=[rng.random() for _ in range(3)]
    hits += max(t)-min(t) <= 1/6
p=hits/M
assert abs(p-2/27) < 6*math.sqrt((2/27)*(25/27)/M)

