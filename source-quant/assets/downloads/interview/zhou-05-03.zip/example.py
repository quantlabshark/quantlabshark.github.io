# -*- coding: utf-8 -*-

# 示例 1
from functools import lru_cache

@lru_cache(None)
def value(b, r):
    if b == 0:
        return 0.0
    if r == 0:
        return float(b)
    continuation = (b * value(b - 1, r) + r * value(b, r - 1)) / (b + r)
    return max(b - r, continuation)

def should_stop(b, r):
    if r == 0:
        return True
    if b == 0:
        return r == 0
    continuation = (b * value(b - 1, r) + r * value(b, r - 1)) / (b + r)
    return b - r >= continuation

print(value(26, 26))
for r in range(27):
    print([round(value(b, r), 2) for b in range(27)])

