# -*- coding: utf-8 -*-

# 示例 1
import math

def estimate_time_mean(n,m):
    if not 1 <= m <= n:
        raise ValueError('楼层不合法')
    if m == 1:
        return 0.0
    A,B = n-m,m-2
    move = 2*(n-1)
    E = [[0.0]*(B+1) for _ in range(A+1)]
    for a in range(A+1):
        for b in range(B+1):
            a0,a1 = 2.0**(-a),a*2.0**(-a)
            b0,b1 = 2.0**(-b),b*2.0**(-b)
            events = []
            # 概率、移除上方人数、移除下方人数、目标是否搭乘。
            if a>=2: events.append((1-a0-a1,2,0,False))
            if a>=1:
                events += [(a1/2,1,0,True),(a1*b0/2,1,0,False)]
                if b: events.append((a1*(1-b0)/2,1,1,False))
            events += [(a0*b0/2,0,0,True)]
            if b: events.append((a0*(1-b0)/2,0,1,True))
            if b: events.append((a0*b1/2,0,1,False))
            if b>=2: events.append((a0*(1-b0-b1)/2,0,2,False))
            empty = a0*b0/2
            value = empty*(2*move)
            for prob,da,db,hit in events:
                boarded = da+db+int(hit)
                duration = move+3*boarded+3
                value += prob*(duration if hit else duration+move+E[a-da][b-db])
            E[a][b] = value/(1-empty)
    return E[A][B]

def estimate_time(n:int,m:int)->int:
    return math.ceil(estimate_time_mean(n,m))

assert estimate_time(1,1)==0
assert estimate_time_mean(2,2)==12
assert estimate_time(3,2)>0

