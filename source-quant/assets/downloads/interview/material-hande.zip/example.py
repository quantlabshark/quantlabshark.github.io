# -*- coding: utf-8 -*-

# 示例 1
def trace():
    ctrl = odds = 0
    lines = []
    def rr(x):
        nonlocal ctrl, odds
        odds += 1
        if x < 9:
            ctrl += 1
            q = int(x / (2 if ctrl < 3 else 3))
            if ctrl > 1:
                q += ctrl
        else:
            left = rr(x - 2)
            right = rr(int(x / 3))
            q = left + right
        lines.append(('I like ' if (odds + q) % 2 == 0 else 'I hate ') + str(q))
        return q
    result = rr(rr(rr(13) - 3) - 5)
    return lines, result
assert trace()[1] == 70


# 示例 2
import numpy as np
def covariance(flat, n, m):
    if n < 2 or len(flat) != n*m:
        raise ValueError('至少两次观测，且数据长度等于 n*m')
    x = np.asarray(flat, dtype=float).reshape(n, m)
    z = x - x.mean(axis=0)
    return z.T @ z / (n-1)
assert np.allclose(covariance([1,2,3,4,5,6], 3, 2), [[4,4],[4,4]])


# 示例 3
from functools import cache
from fractions import Fraction
@cache
def capital(i, j):
    if i == 4: return Fraction(2000)
    if j == 4: return Fraction(0)
    return (capital(i+1,j)+capital(i,j+1))/2
def stake(i,j):
    return (capital(i+1,j)-capital(i,j+1))/2
assert capital(0,0) == 1000 and stake(0,0) == Fraction(625,2)
for i in range(4):
    for j in range(4):
        assert capital(i,j)+stake(i,j) == capital(i+1,j)
        assert capital(i,j)-stake(i,j) == capital(i,j+1)


# 示例 4
def sqrt2(tol=1e-12):
    x=1.0
    while True:
        y=(x+2/x)/2
        if abs(y-x)<tol: return y
        x=y
assert abs(sqrt2()**2-2)<1e-12

