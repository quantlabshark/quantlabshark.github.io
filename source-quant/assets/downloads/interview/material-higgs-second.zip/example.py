# -*- coding: utf-8 -*-

# 示例 1
grid=[[3,1,3,2,4,1],[2,3,4,1,3,2],[1,5,2,3,1,3],
      [2,4,1,4,2,4],[1,3,2,5,3,1],[2,4,1,1,4,2]]
assert sum(map(sum,grid))==90
for r in range(6):
    for c in range(6):
        near={grid[a][b] for a,b in [(r-1,c),(r+1,c),(r,c-1),(r,c+1)]
              if 0<=a<6 and 0<=b<6}
        assert set(range(1,grid[r][c])).issubset(near)

