# -*- coding: utf-8 -*-

# 示例 1
def unique_sorted(a):
    if not a:
        return []
    out = [a[0]]
    for i in range(1, len(a)):
        if a[i] != a[i - 1]:
            out.append(a[i])
    return out


# 示例 2
def horner(coefficients, x):
    value = 0
    for coefficient in reversed(coefficients):
        value = value * x + coefficient
    return value


# 示例 3
def moving_average(a, n):
    if not 1 <= n <= len(a):
        raise ValueError('window must be between 1 and array length')
    total = sum(a[i] for i in range(n))
    result = [total / n]
    for i in range(n, len(a)):
        total += a[i] - a[i - n]
        result.append(total / n)
    return result


# 示例 4
def merge_sort(a):
    if len(a) <= 1:
        return list(a)
    middle = len(a) // 2
    left, right = merge_sort(a[:middle]), merge_sort(a[middle:])
    out, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            out.append(left[i]); i += 1
        else:
            out.append(right[j]); j += 1
    return out + left[i:] + right[j:]


# 示例 5
import random

def shuffle_uniform(a, rng=None):
    rng = random if rng is None else rng
    for i in range(len(a)):
        j = rng.randrange(i, len(a))
        a[i], a[j] = a[j], a[i]
    return a


# 示例 6
import random

def sample_one(stream, rng=None):
    rng = random if rng is None else rng
    selected = None
    count = 0
    for count, item in enumerate(stream, 1):
        if rng.randrange(count) == 0:
            selected = item
    if count == 0:
        raise ValueError('empty stream')
    return selected


# 示例 7
def minmax(a):
    if not a:
        raise ValueError('empty array')
    if len(a) % 2:
        low = high = a[0]
        start = 1
    else:
        low, high = (a[0], a[1]) if a[0] <= a[1] else (a[1], a[0])
        start = 2
    for i in range(start, len(a), 2):
        small, large = (a[i], a[i + 1]) if a[i] <= a[i + 1] else (a[i + 1], a[i])
        if small < low:
            low = small
        if large > high:
            high = large
    return low, high


# 示例 8
def first_nonzero(get):
    def boundary(i):
        try:
            return get(i) != 0
        except IndexError:
            return True

    if boundary(0):
        try:
            return 0 if get(0) != 0 else None
        except IndexError:
            return None
    high = 1
    while not boundary(high):
        high *= 2
    low = high // 2 + 1
    while low < high:
        middle = (low + high) // 2
        if boundary(middle):
            high = middle
        else:
            low = middle + 1
    try:
        return low if get(low) != 0 else None
    except IndexError:
        return None


# 示例 9
def search_matrix(a, target):
    if not a or not a[0]:
        return None
    row, col = 0, len(a[0]) - 1
    while row < len(a) and col >= 0:
        if a[row][col] == target:
            return row, col
        if a[row][col] > target:
            col -= 1
        else:
            row += 1
    return None


# 示例 10
def fibonacci(n):
    if n < 0:
        raise ValueError('n must be nonnegative')
    def pair(k):
        if k == 0:
            return 0, 1
        a, b = pair(k // 2)
        c, e = a * (2 * b - a), a * a + b * b
        return (e, c + e) if k % 2 else (c, e)
    return pair(n)[0]


# 示例 11
def maximum_subarray(a):
    if not a:
        raise ValueError('empty array')
    current = best = a[0]
    start = left = right = 0
    for i in range(1, len(a)):
        if current + a[i] < a[i]:
            current, start = a[i], i
        else:
            current += a[i]
        if current > best:
            best, left, right = current, start, i
    return best, left, right

