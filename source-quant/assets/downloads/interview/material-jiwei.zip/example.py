# -*- coding: utf-8 -*-

# 示例 1
import numpy as np
def coordinate_lasso(X,y,lam,cycles=10):
    X=np.asarray(X,float); y=np.asarray(y,float)
    if lam<0: raise ValueError('lambda非负')
    beta=np.zeros(X.shape[1])
    for _ in range(cycles):
        for j in range(X.shape[1]):
            residual=y-X@beta+X[:,j]*beta[j]
            norm=X[:,j]@X[:,j]
            v=X[:,j]@residual
            beta[j]=np.sign(v)*max(abs(v)-lam,0)/norm if norm else 0
    return beta
assert np.allclose(coordinate_lasso(np.eye(2),[3,-1],1),[2,0])


# 示例 2
from collections import deque
def fifo_duration(signals):
    opened=deque(); duration=closed=0
    for t,s in enumerate(signals):
        if s not in (-1,1): raise ValueError('信号须为±1')
        if opened and opened[0][1]!=s:
            old,_=opened.popleft(); duration+=t-old; closed+=1
        else: opened.append((t,s))
    for old,_ in opened:
        duration+=len(signals)-old; closed+=1
    return duration/closed if closed else 0
assert fifo_duration([1,1,-1])==2

