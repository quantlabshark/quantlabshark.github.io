# -*- coding: utf-8 -*-

# 示例 1
from collections import deque
from math import isnan, isfinite

def rolling_var(data, window):
    if not isinstance(window, int) or window < 1:
        raise ValueError("window must be a positive integer")
    q, out = deque(), []
    n, mean, m2 = 0, 0.0, 0.0
    for i, raw in enumerate(data):
        x = float(raw)
        if not isnan(x) and not isfinite(x):
            raise ValueError("infinite observations are not supported")
        q.append(x)
        if not isnan(x):
            n += 1
            delta = x - mean
            mean += delta / n
            m2 += delta * (x - mean)
        if len(q) > window:
            old = q.popleft()
            if not isnan(old):
                if n == 1:
                    n, mean, m2 = 0, 0.0, 0.0
                else:
                    new_mean = mean - (old - mean) / (n - 1)
                    m2 -= (old - mean) * (old - new_mean)
                    n -= 1
                    mean = new_mean
                    if n == 1:
                        m2 = 0.0
        out.append(max(m2, 0.0) / (n - 1)
                   if i >= window - 1 and n >= 2 else float("nan"))
    return out

a = rolling_var([1, float("nan"), 3, 5, 7], 3)
assert isnan(a[0]) and isnan(a[1])
assert a[2:] == [2.0, 2.0, 4.0]
assert all(isnan(v) for v in rolling_var([1, 2], 1))


# 示例 2
import numpy as np
import pandas as pd

def rolling_all_normalize(df):
    x = df.copy()
    x['date'] = pd.to_datetime(x['date'])
    if x.duplicated(['date','ticker']).any():
        raise ValueError('日期与股票组合重复')
    x = x.sort_values(['date','ticker'])
    good = x['factor'].dropna()
    origin = float(good.iloc[0]) if len(good) else 0.0
    x['_z'] = x['factor']-origin
    x['_z2'] = x['_z']**2
    daily = x.groupby('date').agg(n=('_z','count'), s=('_z','sum'), q=('_z2','sum'))
    hist = daily.shift(1).rolling(5, min_periods=5).sum()
    mean_z = hist['s']/hist['n'].replace(0,np.nan)
    var = (hist['q']/hist['n'].replace(0,np.nan)-mean_z**2).clip(lower=0)
    stats = pd.DataFrame({'_mean':mean_z+origin,'_std':np.sqrt(var).replace(0,np.nan)})
    x = x.join(stats,on='date')
    x['normalized'] = (x['factor']-x['_mean'])/x['_std']
    return x.drop(columns=['_z','_z2','_mean','_std'])

test = pd.DataFrame({'date':pd.date_range('2020-01-01',periods=6),'ticker':['A']*6,'factor':range(1,7)})
out = rolling_all_normalize(test)
assert out['normalized'].iloc[:5].isna().all()
assert np.isclose(out['normalized'].iloc[5],3/np.sqrt(2))


# 示例 3
import numpy as np
import pandas as pd

def robust_standardize(df):
    x = df.copy()
    x['date'] = pd.to_datetime(x['date'])
    if x.duplicated(['date','ticker']).any():
        raise ValueError('日期与股票组合重复')
    g = x.groupby('date')['factor']
    lo = g.transform(lambda v:v.quantile(.01))
    hi = g.transform(lambda v:v.quantile(.99))
    core = x['factor'].where(x['factor'].between(lo,hi))
    cg = core.groupby(x['date'])
    mean = cg.transform('mean')
    std = cg.transform(lambda v:v.std(ddof=0)).replace(0,np.nan)
    x['z'] = ((x['factor']-mean)/std).clip(-3,3)
    return x

def factor_outputs(a,b):
    aa,bb = robust_standardize(a),robust_standardize(b)
    m = aa[['date','ticker','z']].rename(columns={'z':'A'}).merge(
        bb[['date','ticker','z']].rename(columns={'z':'B'}),on=['date','ticker'],how='left',validate='one_to_one')
    valid = m['A'].notna() & m['B'].notna()
    av,bv = m['A'].where(valid),m['B'].where(valid)
    da = av-av.groupby(m['date']).transform('mean')
    db = bv-bv.groupby(m['date']).transform('mean')
    cov = (da*db).groupby(m['date']).sum(min_count=1)
    va = (da*da).groupby(m['date']).sum(min_count=1)
    vb = (db*db).groupby(m['date']).sum(min_count=1)
    daily = cov/np.sqrt(va*vb).replace(0,np.nan)
    monthly = daily.groupby([daily.index.year,daily.index.month]).mean().unstack().reindex(columns=range(1,13))
    beta = (cov/vb.replace(0,np.nan)).where(vb!=0,0)
    m['C'] = da-db*m['date'].map(beta)
    return aa,bb,daily,monthly,m[['date','ticker','C']]

a = pd.DataFrame({'date':['2020-01-01']*5,'ticker':list('ABCDE'),'factor':[1.,2.,3.,4.,5.]})
b = a.copy(); b['factor'] = [2.,4.,6.,8.,10.]
_,_,daily,monthly,c = factor_outputs(a,b)
assert len(c)==len(a) and np.allclose(c['C'],0,atol=1e-12)
assert np.isclose(daily.iloc[0],1)

