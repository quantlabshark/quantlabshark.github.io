# -*- coding: utf-8 -*-

# 示例 1
def stone_game(a,b):
    if len(a)!=len(b): raise ValueError('长度不一致')
    order=sorted(range(len(a)),key=lambda i:a[i]+b[i],reverse=True)
    diff=sum(a[i] if t%2==0 else -b[i] for t,i in enumerate(order))
    return (diff>0)-(diff<0)
assert stone_game([1,3],[2,1])==1


# 示例 2
def matrix_sum(n,queries):
    rows,cols=set(),set(); total=0
    for typ,idx,value in reversed(queries):
        if not 0<=idx<n: raise ValueError('索引越界')
        if typ==0 and idx not in rows:
            total+=value*(n-len(cols)); rows.add(idx)
        elif typ==1 and idx not in cols:
            total+=value*(n-len(rows)); cols.add(idx)
        elif typ not in (0,1): raise ValueError('未知操作')
    return total
assert matrix_sum(2,[(0,0,3),(1,1,5)])==13

