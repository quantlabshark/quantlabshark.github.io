# -*- coding: utf-8 -*-

# 示例 1
def maximum_grid_weight(weights):
    if not weights or not weights[0]:
        return 0
    width = len(weights[0])
    if any(len(row) != width for row in weights):
        raise ValueError("各行长度必须一致")
    states = range(1 << width)
    legal = {q: [p for p in states
                 if all(((p >> j) & 3).bit_count()
                        + ((q >> j) & 3).bit_count() <= 2
                        for j in range(width - 1))] for q in states}
    dp = {q: sum(x for j, x in enumerate(weights[0]) if q >> j & 1)
          for q in states}
    for row in weights[1:]:
        dp = {q: sum(x for j, x in enumerate(row) if q >> j & 1)
                 + max(dp[p] for p in legal[q]) for q in states}
    return max(dp.values())

assert maximum_grid_weight([[1, 2], [3, 4]]) == 7
assert maximum_grid_weight([[-1, -2], [-3, -4]]) == 0

