# -*- coding: utf-8 -*-

# 示例 1
def count_smaller_right(a):
    rank = {v: i+1 for i, v in enumerate(sorted(set(a)))}
    tree = [0] * (len(rank)+1)
    ans = [0] * len(a)

    def prefix(i):
        total = 0
        while i:
            total += tree[i]
            i -= i & -i
        return total

    def add(i):
        while i < len(tree):
            tree[i] += 1
            i += i & -i

    for i in range(len(a)-1, -1, -1):
        r = rank[a[i]]
        ans[i] = prefix(r-1)
        add(r)
    return ans

assert count_smaller_right([5, 2, 6, 1]) == [2, 1, 1, 0]
assert count_smaller_right([2, 2, 1]) == [1, 1, 0]
assert count_smaller_right([]) == []
assert count_smaller_right([-1, -2, -1]) == [1, 0, 0]

