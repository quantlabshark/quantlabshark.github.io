# -*- coding: utf-8 -*-

# 示例 1
def graph_count(n):
    if n < 0:
        raise ValueError("顶点数不能为负")
    return pow(2, n * (n - 1) // 2, 10**9 + 7)

assert graph_count(4) == 64
assert graph_count(0) == 1


# 示例 2
def maximum_sum(arr):
    if not arr:
        raise ValueError("数组不能为空")
    ending = best = arr[0]
    for i in range(1, len(arr)):
        value = arr[i]
        ending = max(value, ending + value)
        best = max(best, ending)
    return best

assert maximum_sum([-1, 3, 4, -2, 5, -7]) == 10
assert maximum_sum([-5, -2, -7]) == -2


# 示例 3
def compute_parameter_value(sources):
    merged = {}
    for source in sources:
        for key, value in source:
            merged[key] = value
    return list(merged.values())

sources = [[("rating", "buy"), ("risk", "low")],
           [("rating", "sell"), ("size", "small")],
           [("rating", "hold")]]
assert compute_parameter_value(sources) == ["hold", "low", "small"]

