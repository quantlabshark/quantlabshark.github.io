# -*- coding: utf-8 -*-

# 示例 1
import pandas as pd
import numpy as np

index = pd.MultiIndex.from_tuples(
    [('2026-01-05', 'A'), ('2026-01-05', 'B'), ('2026-01-06', 'A')],
    names=['date', 'ticker'])
df = pd.DataFrame([[0.2, 0.6, 1.0], [0.1, 0.2, 0.3], [0.8, 0.9, np.nan]], index=index)
stock_a = df.xs('A', level='ticker')
row_median = df.median(axis=1)
conditional_std = df.where(df > 0.5).std(axis=1, ddof=1)
assert len(stock_a) == 2
assert np.isclose(row_median.iloc[0], 0.6)
assert np.isclose(conditional_std.iloc[0], np.sqrt(0.08))
assert np.isnan(conditional_std.iloc[1])


# 示例 2
from math import isfinite, sqrt, fsum, isnan

def pearson(x, y):
    if len(x) != len(y):
        raise ValueError('序列长度必须相同')
    pairs = []
    for a, b in zip(x, y):
        if a is None or b is None:
            continue
        a, b = float(a), float(b)
        if isfinite(a) and isfinite(b):
            pairs.append((a, b))
    if len(pairs) < 2:
        return float('nan')
    mx = fsum(a for a, _ in pairs) / len(pairs)
    my = fsum(b for _, b in pairs) / len(pairs)
    xx = fsum((a-mx)**2 for a, _ in pairs)
    yy = fsum((b-my)**2 for _, b in pairs)
    if xx == 0 or yy == 0:
        return float('nan')
    xy = fsum((a-mx)*(b-my) for a, b in pairs)
    return xy / sqrt(xx*yy)

assert abs(pearson([1, 2, float('nan'), 4], [2, 4, 9, 8])-1) < 1e-12
assert isnan(pearson([1, 1], [2, 3]))
assert abs(pearson([1e12, 1e12+1, 1e12+2], [2, 4, 6])-1) < 1e-12


# 示例 3
def max_profit(prices, k):
    if k <= 0 or len(prices) < 2:
        return 0
    if k >= len(prices)//2:
        return sum(max(b-a, 0) for a, b in zip(prices, prices[1:]))
    buy = [float('-inf')] * (k+1)
    sell = [0] * (k+1)
    for p in prices:
        old_buy, old_sell = buy[:], sell[:]
        for j in range(1, k+1):
            buy[j] = max(old_buy[j], old_sell[j-1]-p)
            sell[j] = max(old_sell[j], old_buy[j]+p)
    return sell[k]

assert max_profit([3, 2, 6, 5, 0, 3], 2) == 7
assert max_profit([7, 6, 4, 1], 2) == 0
assert max_profit([], 2) == 0
assert max_profit([1, 2, 3, 4], 20) == 3

