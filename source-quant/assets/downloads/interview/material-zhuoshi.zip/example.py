# -*- coding: utf-8 -*-

# 示例 1
from itertools import groupby
from math import isfinite

def efficient_frontier(points):
    if any(not (isfinite(p) and isfinite(d) and d >= 0) for p, d in points):
        raise ValueError("收益须有限，回撤须为有限非负幅度")
    ordered = sorted(enumerate(points), key=lambda x: -x[1][0])
    keep, best_drawdown = [], float("inf")
    for _, group in groupby(ordered, key=lambda x: x[1][0]):
        group = list(group)
        keep.extend(i for i, (_, d) in group if d <= best_drawdown)
        best_drawdown = min(best_drawdown, min(x[1][1] for x in group))
    return [points[i] for i in sorted(keep)]

assert efficient_frontier([(3, 2), (3, 4), (2, 3), (1, 2)]) == [(3, 2), (3, 4), (1, 2)]


# 示例 2
def minimum_pnl_interval(pnl):
    if not pnl:
        raise ValueError("损益序列不能为空")
    ending = best = pnl[0]
    for i in range(1, len(pnl)):
        x = pnl[i]
        ending = min(x, ending + x)
        best = min(best, ending)
    return best

assert minimum_pnl_interval([3, -4, 2, -5, 6]) == -7
assert minimum_pnl_interval([2, 4]) == 2


# 示例 3
import itertools
import numpy as np

def pattern_win(a, b):
    states = sorted({''} | {p[:k] for p in (a,b) for k in (1,2)}, key=lambda x:(len(x),x))
    index = {s:i for i,s in enumerate(states)}
    matrix = np.eye(len(states))
    rhs = np.zeros(len(states))
    for s,i in index.items():
        for coin in 'HT':
            suffix = s+coin
            if suffix.endswith(b):
                rhs[i] += .5
            elif not suffix.endswith(a):
                nxt = max((v for v in states if suffix.endswith(v)), key=len)
                matrix[i,index[nxt]] -= .5
    return float(np.linalg.solve(matrix,rhs)[index['']])

probabilities = {''.join(p):pattern_win('HTH',''.join(p))
                 for p in itertools.product('HT',repeat=3) if ''.join(p)!='HTH'}
assert np.isclose(probabilities['HHT'],2/3)
assert max(probabilities.values()) <= 2/3+1e-12
print(probabilities)


# 示例 4
from math import lgamma, log, exp
probability = exp(lgamma(10001) - 2 * lgamma(5001) - 10000 * log(2))
assert abs(probability - 0.00797864614) < 1e-10

