# -*- coding: utf-8 -*-

# 示例 1
from copy import deepcopy

cfg = {"windows": [5, 20], "cost": 0.001}
shallow = cfg.copy()
shallow["windows"][0] = 10
shallow["cost"] = 0.002
assert cfg == {"windows": [10, 20], "cost": 0.001}

independent = deepcopy(cfg)
independent["windows"][0] = 3
assert cfg["windows"][0] == 10


# 示例 2
from collections import Counter, defaultdict
pairs = [(x,y) for x in range(2,101) for y in range(x+1,101)]
pc = Counter(x*y for x,y in pairs)
by_sum = defaultdict(list)
for x,y in pairs:
    by_sum[x+y].append((x,y))
good_sums = {s for s, ps in by_sum.items() if len(ps)>1 and all(pc[x*y]>1 for x,y in ps)}
a = [(x,y) for x,y in pairs if x+y in good_sums]
ac = Counter(x*y for x,y in a)
b = [(x,y) for x,y in a if ac[x*y]==1]
bc = Counter(x+y for x,y in b)
answer = [(x,y) for x,y in b if bc[x+y]==1]
assert answer == [(4,13)]


# 示例 3
def largest_white_region(white, edges):
    n = len(white)
    if not n:
        return 0
    parent, size = list(range(n)), [1]*n
    neighbors = [[] for _ in range(n)]
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a,b):
        a,b = find(a),find(b)
        if a==b: return
        if size[a]<size[b]: a,b=b,a
        parent[b]=a
        size[a]+=size[b]
    for a,b in edges:
        neighbors[a].append(b); neighbors[b].append(a)
        if white[a] and white[b]: union(a,b)
    best = max((size[find(i)] for i in range(n) if white[i]),default=0)
    for i in range(n):
        if not white[i]:
            components={find(j) for j in neighbors[i] if white[j]}
            best=max(best,1+sum(size[j] for j in components))
    return best

assert largest_white_region([1,1,0,1,0],[(0,1),(1,2),(2,3),(3,4)])==4
assert largest_white_region([1,1],[(0,1)])==2
assert largest_white_region([0,0],[(0,1)])==1

