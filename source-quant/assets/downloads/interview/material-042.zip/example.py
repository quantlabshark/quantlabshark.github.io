# -*- coding: utf-8 -*-

# 示例 1
def median_sorted(a, b):
    if len(a) > len(b):
        a, b = b, a
    if not a and not b:
        raise ValueError('两个数组均为空')
    m, n = len(a), len(b)
    lo, hi = 0, m
    while lo <= hi:
        i = (lo + hi)//2
        j = (m+n+1)//2-i
        al = a[i-1] if i else -float('inf')
        ar = a[i] if i < m else float('inf')
        bl = b[j-1] if j else -float('inf')
        br = b[j] if j < n else float('inf')
        if al > br:
            hi = i-1
        elif bl > ar:
            lo = i+1
        else:
            left = max(al, bl)
            return left if (m+n)%2 else (left+min(ar, br))/2
    raise ValueError('输入须已排序')

assert median_sorted([1,3], [2]) == 2
assert median_sorted([], [1,2]) == 1.5


# 示例 2
cards='D10 CJ CQ S3 H4 H5 D6 SJ DJ SQ S4 H6 CK SA C2 C3 HK C4 H7 S5 S6 DQ CA D7 C5 HA H8 S7 C6 DK SK H9 DA C7 C8 C9 H10 S8 C10 D8 H2 D5 HJ D2 D3 HQ D4 S9 H3 S2 D9 S10'.split()
base=[s+r for s in 'CDHS' for r in '2 3 4 5 6 7 8 9 10 J Q K A'.split()]
rank={card:i for i,card in enumerate(base)}
order=[rank[x] for x in cards]
assert len(set(order))==52

def chains(p):
    pos={v:i for i,v in enumerate(p)}
    return sum(pos[(j+1)%52]<pos[j] for j in range(52))

candidates=[]
for i in range(1,52):
    restored=[order[i]]+order[:i]+order[i+1:]
    if chains(restored)<=8:candidates.append(cards[i])
assert chains(order)==9 and candidates==['D5']

