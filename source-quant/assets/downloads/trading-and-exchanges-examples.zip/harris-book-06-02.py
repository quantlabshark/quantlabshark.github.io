# -*- coding: utf-8 -*-
# 6.2 集合竞价的供需曲线与交易剩余
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
buys = [(101, 3), (100, 4)]
sells = [(99, 2), (100, 5)]
rows = []
for price in sorted({p for p, q in buys + sells}):
    demand = sum(q for p, q in buys if p >= price)
    supply = sum(q for p, q in sells if p <= price)
    rows.append((price, demand, supply, min(demand, supply)))
for row in rows:
    print("价格、需求、供给、成交量：", row)
best = max(row[3] for row in rows)
winners = [row[0] for row in rows if row[3] == best]
assert winners == [100] and best == 7
