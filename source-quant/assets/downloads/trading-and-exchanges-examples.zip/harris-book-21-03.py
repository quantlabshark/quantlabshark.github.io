# -*- coding: utf-8 -*-
# 21.3 成本估计的偏差与订单流模型
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟市场：有效价格固定，半价差为 0.02，随机买卖方向
import random
from statistics import mean
random.seed(2103)
price = [100 + 0.02 * random.choice([-1, 1]) for _ in range(50001)]
change = [b - a for a, b in zip(price, price[1:])]
x, y = change[:-1], change[1:]
mx, my = mean(x), mean(y)
cov = mean((a - mx) * (b - my) for a, b in zip(x, y))
estimate = 2 * (-cov) ** 0.5 if cov < 0 else None
print('真实价差:', 0.04, '估计价差:', round(estimate, 5))
assert abs(estimate - 0.04) < 0.002
