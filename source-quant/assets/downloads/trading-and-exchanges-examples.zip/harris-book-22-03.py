# -*- coding: utf-8 -*-
# 22.3 冠军筛选、幸存者偏差与均值回归
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
import random
from statistics import mean
random.seed(2203)
selected_past, selected_future = [], []
for _ in range(400):
    past = [mean(random.gauss(0, 0.07) for _ in range(5))
            for _ in range(2000)]
    winner = max(range(len(past)), key=past.__getitem__)
    selected_past.append(past[winner])
    selected_future.append(mean(random.gauss(0, 0.07) for _ in range(5)))
print('冠军过去平均年超额收益:', round(mean(selected_past), 4))
print('冠军后续平均年超额收益:', round(mean(selected_future), 4))
assert mean(selected_past) > 0.08
assert abs(mean(selected_future)) < 0.01
