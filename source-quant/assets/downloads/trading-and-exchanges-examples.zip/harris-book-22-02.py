# -*- coding: utf-8 -*-
# 22.2 用统计检验区分能力与运气
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 正态近似演示，参数为教学设定，不是某基金的实测业绩
from statistics import NormalDist
from math import sqrt
normal = NormalDist()
mu, sigma = 0.02, 0.07
critical = normal.inv_cdf(0.95)
for years in [1, 5, 10, 20]:
    power = 1 - normal.cdf(critical - mu * sqrt(years) / sigma)
    print(years, '年，功效', round(power, 4))
required = ((critical + normal.inv_cdf(0.75)) * sigma / mu) ** 2
print('达到 75% 功效所需年数:', round(required, 1))
assert 65 < required < 67
