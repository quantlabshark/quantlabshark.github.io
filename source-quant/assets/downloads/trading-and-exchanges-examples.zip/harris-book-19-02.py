# -*- coding: utf-8 -*-
# 19.2 即时性、价差、深度与恢复能力
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
asks = [(100.05, 100), (100.10, 200), (100.20, 500)]
def execute(quantity):
    remaining, cost = quantity, 0.0
    for price, available in asks:
        take = min(remaining, available)
        cost += price * take
        remaining -= take
        if remaining == 0:
            return cost / quantity
    raise ValueError('显示深度不足，不能假设剩余数量已成交')
for quantity in (100, 300, 600):
    average = execute(quantity)
    print(quantity, round(average, 4),
          round((average / 100 - 1) * 10000, 2))
