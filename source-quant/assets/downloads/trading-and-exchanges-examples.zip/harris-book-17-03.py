# -*- coding: utf-8 -*-
# 17.3 套利的执行、融资与模型风险
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
cash_available = 150_000
long_gain = 200_000
short_cash_call = 200_000
print('组合账面变化:', long_gain - short_cash_call)
print('立即需要的外部现金:', max(0, short_cash_call - cash_available))
assert long_gain - short_cash_call == 0
assert max(0, short_cash_call - cash_available) == 50_000
