# -*- coding: utf-8 -*-
# 14.4 Glosten–Milgrom 模型的价差推导
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
value, error = 100.0, 4.0
for informed in (0.0, 0.25, 0.5):
    bid = value - informed * error
    ask = value + informed * error
    half_spread = (ask - bid) / 2
    profit = ((1 - informed) * half_spread
              + informed * (half_spread - error))
    print(informed, bid, ask, round(profit, 10))
    assert abs(profit) < 1e-9
