# -*- coding: utf-8 -*-
# 2.3 现货、期货、期权与场外协商
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
inventory = 120_000
contract_size = 1_000
contracts = inventory // contract_size
spot_change = -0.18
futures_change = -0.20
spot_pnl = inventory * spot_change
futures_pnl = -contracts * contract_size * futures_change
print("现货损益：", spot_pnl)
print("期货损益：", futures_pnl)
print("合并损益：", round(spot_pnl + futures_pnl, 2))
assert contracts == 120
assert round(spot_pnl + futures_pnl, 2) == 2400
