# -*- coding: utf-8 -*-
# 12.2 交易冲击模型的往返一致性
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
p0, impact, total, fee = 100.0, 0.002, 100, 0.01
def round_trip(parts):
    quantity = total / parts
    inventory = 0.0
    cash = 0.0
    for direction in (1, -1):
        for _ in range(parts):
            change = direction * quantity
            price = p0 + impact * (inventory + change / 2)
            cash -= change * price
            cash -= abs(change) * fee
            inventory += change
    return cash, inventory
for parts in (1, 5, 20):
    pnl, inventory = round_trip(parts)
    print(parts, round(pnl, 6), round(inventory, 6))
    assert abs(pnl + 2 * fee * total) < 1e-8
    assert abs(inventory) < 1e-8
