# -*- coding: utf-8 -*-
# 6.1 优先规则与连续撮合
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
asks = [
    {"id": "A", "price": 1002, "time": 1, "qty": 100},
    {"id": "B", "price": 1002, "time": 2, "qty": 200},
    {"id": "C", "price": 1004, "time": 3, "qty": 500},
]
asks.sort(key=lambda x: (x["price"], x["time"]))
remaining, limit = 450, 1003
fills = []
for order in asks:
    if order["price"] > limit or not remaining:
        break
    qty = min(remaining, order["qty"])
    fills.append((order["id"], order["price"] / 100, qty))
    order["qty"] -= qty
    remaining -= qty
print("成交：", fills, "未成交：", remaining)
assert remaining == 150
assert [x[0] for x in fills] == ["A", "B"]
