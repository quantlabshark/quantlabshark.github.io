# -*- coding: utf-8 -*-
# 18.1 市价与限价的执行权衡
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
immediate = 100.10
fill_probability, limit_price = 0.60, 100.00
for fallback_price in (100.20, 100.40):
    expected = (fill_probability * limit_price
                + (1 - fill_probability) * fallback_price)
    print(fallback_price, round(expected, 4),
          round(expected - immediate, 4))
