# -*- coding: utf-8 -*-
# 10.4 信息成本、交易冲击与市场效率
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
a, b, c = 0.20, 0.001, 5.0
def profit(q):
    return a * q - b * q * q - c
q_star = a / (2 * b)
for q in (0, 50, 100, 150, 200):
    print(q, round(profit(q), 2))
print("模型最优数量：", q_star)
assert q_star == 100 and abs(profit(q_star) - 5) < 1e-10
