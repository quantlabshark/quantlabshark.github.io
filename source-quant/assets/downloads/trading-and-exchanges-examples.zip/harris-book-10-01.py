# -*- coding: utf-8 -*-
# 10.1 基本价值、信息汇集与价格发现
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
variance, n = 9.0, 10
for correlation in (0.0, 0.5, 1.0):
    mean_error_variance = variance * (correlation + (1 - correlation) / n)
    print(correlation, round(mean_error_variance, 4))
assert abs(variance / n - 0.9) < 1e-10
