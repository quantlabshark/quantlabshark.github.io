# -*- coding: utf-8 -*-
# 23.1 指数怎样计算，基金怎样复制
# 教学数据在代码中给定；按正文顺序运行全部例子。

# 示例 1
# 自拟两股价格加权指数，验证拆股时财富和指数连续
prices = [100.0, 10.0]
old_divisor = 2.0
old_index = sum(prices) / old_divisor
after_split = [prices[0] / 2, prices[1]]
new_divisor = sum(after_split) / old_index
new_index = sum(after_split) / new_divisor
print('拆股前指数:', old_index)
print('新除数:', round(new_divisor, 6))
print('拆股后指数:', new_index)
assert abs(new_index - old_index) < 1e-12
shares_before = [1, 1]
shares_after = [2, 1]
assert sum(p*q for p,q in zip(prices,shares_before)) == sum(p*q for p,q in zip(after_split,shares_after))
