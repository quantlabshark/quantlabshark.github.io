# -*- coding: utf-8 -*-
from scipy.integrate import quad
def convolution(s):
    lo=max(0,s-1);hi=min(1,s)
    return max(0,hi-lo)
for s in [.25,.75,1,1.5,2]:
    print(s,convolution(s))
assert abs(quad(convolution,0,2)[0]-1)<1e-10

from scipy.integrate import quad
from math import log
product_probability=quad(lambda z:-log(z),0,.25)[0]
ratio_tail=quad(lambda z:1/(2*z*z),2,float('inf'))[0]
assert abs(product_probability-.25*(1-log(.25)))<1e-10
assert abs(ratio_tail-.25)<1e-10
print('product <= 1/4',product_probability,'ratio > 2',ratio_tail)
